"use client";

import React, { useEffect, useRef, useState, useCallback } from "react";
import { FaceLandmarker, FilesetResolver, FaceLandmarkerResult } from "@mediapipe/tasks-vision";

// ==================== 0. 模块顶层拦截 WASM INFO 日志 ====================
if (typeof window !== "undefined" && !(window as unknown as { __mpErrFiltered?: boolean }).__mpErrFiltered) {
  (window as unknown as { __mpErrFiltered?: boolean }).__mpErrFiltered = true;
  const origError = window.console.error.bind(window.console);
  window.console.error = (...args: unknown[]) => {
    const msg = args.map((a) => (typeof a === "string" ? a : "")).join(" ");
    if (
      msg.includes("INFO:") ||
      msg.includes("WARNING:") ||
      msg.includes("XNNPACK") ||
      msg.includes("Created TensorFlow Lite") ||
      msg.includes("gl_context")
    ) {
      return;
    }
    origError(...args);
  };
}

// ==================== 1. 信号滤波、岭回归与热力图 LUT ====================

class OneEuroFilter {
  private xPrev: number | null = null;
  private dxPrev = 0;
  private tPrev: number | null = null;

  constructor(private minCutoff = 0.8, private beta = 0.015, private dCutoff = 1.0) {}

  private alpha(cutoff: number, dt: number): number {
    const tau = 1.0 / (2 * Math.PI * cutoff);
    return 1.0 / (1.0 + tau / dt);
  }

  filter(x: number, tMs: number): number {
    if (this.tPrev === null || this.xPrev === null) {
      this.xPrev = x;
      this.tPrev = tMs;
      return x;
    }
    const dt = Math.max((tMs - this.tPrev) / 1000, 1e-4);
    this.tPrev = tMs;

    const dx = (x - this.xPrev) / dt;
    const edx = this.dxPrev + this.alpha(this.dCutoff, dt) * (dx - this.dxPrev);
    this.dxPrev = edx;

    const cutoff = this.minCutoff + this.beta * Math.abs(edx);
    const filtered = this.xPrev + this.alpha(cutoff, dt) * (x - this.xPrev);
    this.xPrev = filtered;
    return filtered;
  }
}

function solveRidgeRegression(X: number[][], Y: number[][], lambda = 0.05): number[][] {
  const n = X.length;
  const d = X[0].length;
  const outDim = Y[0].length;

  const A = Array.from({ length: d }, (_, i) =>
    Array.from({ length: d }, (_, j) => {
      let sum = 0;
      for (let k = 0; k < n; k++) sum += X[k][i] * X[k][j];
      if (i === j) sum += i === 0 ? 1e-7 : lambda;
      return sum;
    })
  );

  const B = Array.from({ length: d }, (_, i) =>
    Array.from({ length: outDim }, (_, j) => {
      let sum = 0;
      for (let k = 0; k < n; k++) sum += X[k][i] * Y[k][j];
      return sum;
    })
  );

  const aug = A.map((row, i) => [...row, ...B[i]]);
  for (let col = 0; col < d; col++) {
    let pivot = col;
    for (let row = col + 1; row < d; row++) {
      if (Math.abs(aug[row][col]) > Math.abs(aug[pivot][col])) pivot = row;
    }
    [aug[col], aug[pivot]] = [aug[pivot], aug[col]];

    const div = aug[col][col] || 1e-8;
    for (let j = col; j < d + outDim; j++) aug[col][j] /= div;

    for (let row = 0; row < d; row++) {
      if (row !== col) {
        const factor = aug[row][col];
        for (let j = col; j < d + outDim; j++) aug[row][j] -= factor * aug[col][j];
      }
    }
  }
  return aug.map((row) => row.slice(d));
}

const HEAT_W = 240;
const HEAT_H = 135;
const HEATMAP_LUT = (() => {
  const lut = new Uint32Array(256);
  for (let v = 0; v < 256; v++) {
    if (v < 3) {
      lut[v] = 0;
      continue;
    }
    let r = 0, g = 0, b = 0;
    if (v < 64) {
      b = 255;
      g = v * 4;
    } else if (v < 128) {
      g = 255;
      b = 255 - (v - 64) * 4;
    } else if (v < 192) {
      g = 255;
      r = (v - 128) * 4;
    } else {
      r = 255;
      g = Math.max(0, 255 - (v - 192) * 4);
    }
    const a = Math.min(215, Math.round(v * 0.92));
    lut[v] = (a << 24) | (b << 16) | (g << 8) | r;
  }
  return lut;
})();

// ==================== 2. 眼动+面部3D姿态提取与点线拓扑绘制 ====================

function projectEyeLocal(lm: { x: number; y: number }[], outer: number, inner: number, iris: number) {
  const dx = lm[inner].x - lm[outer].x;
  const dy = lm[inner].y - lm[outer].y;
  const len = Math.hypot(dx, dy) || 1e-5;
  const ux = dx / len;
  const uy = dy / len;
  const ix = lm[iris].x - lm[outer].x;
  const iy = lm[iris].y - lm[outer].y;
  return {
    u: (ix * ux + iy * uy) / len,
    v: (-ix * uy + iy * ux) / len,
  };
}

interface GazeTelemetry {
  features: number[];
  yawDeg: number;
  pitchDeg: number;
  rollDeg: number;
  blink: number;
  rU: number;
  rV: number;
  lU: number;
  lV: number;
  lookH: number;
  lookV: number;
}

function extractGazeTelemetry(res: FaceLandmarkerResult): GazeTelemetry | null {
  const lm = res.faceLandmarks?.[0];
  const bs = res.faceBlendshapes?.[0]?.categories;
  const mat = res.facialTransformationMatrixes?.[0]?.data;
  if (!lm || lm.length < 478 || !bs || !mat) return null;

  const getBs = (name: string) => bs.find((c) => c.categoryName === name)?.score ?? 0;
  const blink = Math.max(getBs("eyeBlinkLeft"), getBs("eyeBlinkRight"));

  const rEye = projectEyeLocal(lm, 33, 133, 468);
  const lEye = projectEyeLocal(lm, 362, 263, 473);

  const lookHoriz =
    getBs("eyeLookOutLeft") - getBs("eyeLookInLeft") +
    (getBs("eyeLookInRight") - getBs("eyeLookOutRight"));
  const lookVert =
    getBs("eyeLookDownLeft") + getBs("eyeLookDownRight") -
    (getBs("eyeLookUpLeft") + getBs("eyeLookUpRight"));

  const pitch = Math.asin(Math.max(-1, Math.min(1, -mat[6])));
  const yaw = Math.atan2(mat[2], mat[10]);
  const roll = Math.atan2(mat[4], mat[5]);
  const tx = mat[12] * 0.05;
  const ty = mat[13] * 0.05;
  const tz = (mat[14] + 50) * 0.02;

  const uMean = (rEye.u + lEye.u) * 0.5;
  return {
    features: [
      1,
      rEye.u, rEye.v,
      lEye.u, lEye.v,
      lookHoriz, lookVert,
      yaw, pitch, roll,
      tx, ty, tz,
      uMean * yaw,
    ],
    yawDeg: Math.round((yaw * 180) / Math.PI),
    pitchDeg: Math.round((pitch * 180) / Math.PI),
    rollDeg: Math.round((roll * 180) / Math.PI),
    blink,
    rU: rEye.u,
    rV: rEye.v,
    lU: lEye.u,
    lV: lEye.v,
    lookH: lookHoriz,
    lookV: lookVert,
  };
}

const FACE_OVAL = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109, 10];
const RIGHT_EYE_LOOP = [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246, 33];
const LEFT_EYE_LOOP = [362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398, 362];
const RIGHT_EYEBROW = [46, 53, 52, 65, 55, 70, 63, 105, 66, 107];
const LEFT_EYEBROW = [276, 283, 282, 295, 285, 300, 293, 334, 296, 336];
const NOSE_BRIDGE = [168, 6, 197, 195, 5, 4, 1];
const LIPS_OUTER = [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185, 61];

function drawFaceAndEyeMesh(
  canvas: HTMLCanvasElement,
  res: FaceLandmarkerResult,
  tel: GazeTelemetry | null,
  video: HTMLVideoElement,
  showVideoBg: boolean
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const W = canvas.width;
  const H = canvas.height;
  ctx.clearRect(0, 0, W, H);

  if (showVideoBg) {
    ctx.save();
    ctx.translate(W, 0);
    ctx.scale(-1, 1);
    ctx.globalAlpha = 0.35;
    ctx.drawImage(video, 0, 0, W, H);
    ctx.restore();
  } else {
    ctx.strokeStyle = "rgba(30, 41, 59, 0.55)";
    ctx.lineWidth = 1;
    for (let x = 0; x < W; x += 24) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
    for (let y = 0; y < H; y += 24) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }
  }

  const lm = res.faceLandmarks?.[0];
  if (!lm) {
    ctx.fillStyle = "#f43f5e";
    ctx.font = "12px monospace";
    ctx.fillText("未检测到面部特征点", 12, 22);
    return;
  }

  const px = (idx: number) => (1 - lm[idx].x) * W;
  const py = (idx: number) => lm[idx].y * H;

  const strokePath = (indices: number[], color: string, width = 1.2) => {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.beginPath();
    indices.forEach((id, i) => {
      if (i === 0) ctx.moveTo(px(id), py(id));
      else ctx.lineTo(px(id), py(id));
    });
    ctx.stroke();
  };

  ctx.fillStyle = "rgba(148, 163, 184, 0.35)";
  for (let i = 0; i < 468; i += 2) {
    ctx.fillRect(px(i) - 0.7, py(i) - 0.7, 1.4, 1.4);
  }

  strokePath(FACE_OVAL, "rgba(99, 102, 241, 0.55)", 1.2);
  strokePath(RIGHT_EYEBROW, "rgba(148, 163, 184, 0.6)", 1.2);
  strokePath(LEFT_EYEBROW, "rgba(148, 163, 184, 0.6)", 1.2);
  strokePath(NOSE_BRIDGE, "rgba(56, 189, 248, 0.65)", 1.3);
  strokePath(LIPS_OUTER, "rgba(148, 163, 184, 0.5)", 1.1);

  strokePath(RIGHT_EYE_LOOP, "#38bdf8", 1.4);
  strokePath(LEFT_EYE_LOOP, "#38bdf8", 1.4);
  strokePath([33, 133], "rgba(34, 211, 238, 0.85)", 1.5);
  strokePath([362, 263], "rgba(34, 211, 238, 0.85)", 1.5);

  strokePath([469, 470, 471, 472, 469], "#f59e0b", 1.6);
  strokePath([474, 475, 476, 477, 474], "#f59e0b", 1.6);

  [468, 473].forEach((irisIdx) => {
    const cx = px(irisIdx);
    const cy = py(irisIdx);
    ctx.fillStyle = "#fbbf24";
    ctx.beginPath();
    ctx.arc(cx, cy, 2.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#fde047";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx - 6, cy); ctx.lineTo(cx + 6, cy);
    ctx.moveTo(cx, cy - 6); ctx.lineTo(cx, cy + 6);
    ctx.stroke();
  });

  if (tel) {
    const noseX = px(168);
    const noseY = py(168);
    const headEndX = noseX - Math.sin((tel.yawDeg * Math.PI) / 180) * 55;
    const headEndY = noseY + Math.sin((tel.pitchDeg * Math.PI) / 180) * 55;
    ctx.strokeStyle = "#f43f5e";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(noseX, noseY);
    ctx.lineTo(headEndX, headEndY);
    ctx.stroke();

    const rayDx = -tel.lookH * 42 - Math.sin((tel.yawDeg * Math.PI) / 180) * 35;
    const rayDy = tel.lookV * 48 + Math.sin((tel.pitchDeg * Math.PI) / 180) * 35;
    ctx.strokeStyle = "#10b981";
    ctx.lineWidth = 2;
    [468, 473].forEach((id) => {
      ctx.beginPath();
      ctx.moveTo(px(id), py(id));
      ctx.lineTo(px(id) + rayDx, py(id) + rayDy);
      ctx.stroke();
    });

    ctx.fillStyle = "rgba(2, 6, 23, 0.78)";
    ctx.fillRect(6, 6, 206, 52);
    ctx.fillStyle = "#e2e8f0";
    ctx.font = "11px monospace";
    ctx.fillText(`Head Y/P/R: ${tel.yawDeg}° / ${tel.pitchDeg}° / ${tel.rollDeg}°`, 12, 22);
    ctx.fillStyle = "#38bdf8";
    ctx.fillText(`Iris U/V  : ${tel.rU.toFixed(2)}, ${tel.rV.toFixed(2)}`, 12, 37);
    ctx.fillStyle = tel.blink > 0.5 ? "#f43f5e" : "#10b981";
    ctx.fillText(`Blink Score: ${tel.blink.toFixed(2)} ${tel.blink > 0.5 ? "[眨眼拦截]" : "[正常]"}`, 12, 52);
  }
}

// ==================== 3. 通用可自由拖拽与缩放浮动小窗组件 ====================

interface WinState {
  visible: boolean;
  x: number;
  y: number;
  w: number;
  h: number;
}

function FloatingWindow({
  title,
  winState,
  setWinState,
  minW = 200,
  minH = 150,
  headerExtra,
  children,
}: {
  title: string;
  winState: WinState;
  setWinState: React.Dispatch<React.SetStateAction<WinState>>;
  minW?: number;
  minH?: number;
  headerExtra?: React.ReactNode;
  children: React.ReactNode;
}) {
  const startDrag = (e: React.PointerEvent) => {
    e.preventDefault();
    const startX = e.clientX - winState.x;
    const startY = e.clientY - winState.y;
    const onMove = (ev: PointerEvent) => {
      setWinState((prev) => ({
        ...prev,
        x: Math.max(0, Math.min(window.innerWidth - 80, ev.clientX - startX)),
        y: Math.max(0, Math.min(window.innerHeight - 40, ev.clientY - startY)),
      }));
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };

  const startResize = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startY = e.clientY;
    const origW = winState.w;
    const origH = winState.h;
    const onMove = (ev: PointerEvent) => {
      setWinState((prev) => ({
        ...prev,
        w: Math.max(minW, origW + (ev.clientX - startX)),
        h: Math.max(minH, origH + (ev.clientY - startY)),
      }));
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };

  return (
    <div
      style={
        winState.visible
          ? { left: winState.x, top: winState.y, width: winState.w, height: winState.h }
          : { left: -9999, top: -9999, width: 1, height: 1, opacity: 0, pointerEvents: "none" }
      }
      className="fixed z-40 bg-slate-900/95 border border-slate-700/90 rounded-lg shadow-2xl flex flex-col overflow-hidden backdrop-blur"
    >
      <div
        onPointerDown={startDrag}
        className="h-7 px-2.5 bg-slate-800/90 border-b border-slate-700/80 flex items-center justify-between cursor-move select-none shrink-0"
      >
        <span className="text-xs font-medium text-slate-200 truncate">{title}</span>
        <div className="flex items-center gap-1.5" onPointerDown={(e) => e.stopPropagation()}>
          {headerExtra}
          <button
            onClick={() => setWinState((p) => ({ ...p, visible: false }))}
            className="text-slate-400 hover:text-rose-400 px-1 text-xs"
            title="隐藏小窗"
          >
            ✕
          </button>
        </div>
      </div>

      <div className="flex-1 relative min-h-0 overflow-hidden">{children}</div>

      <div
        onPointerDown={startResize}
        className="w-4 h-4 absolute right-0 bottom-0 cursor-nwse-resize z-20 flex items-end justify-end p-0.5 text-slate-400 hover:text-indigo-400"
        title="拖拽自由缩放大小"
      >
        <svg viewBox="0 0 10 10" className="w-2.5 h-2.5 fill-current">
          <path d="M9 1v8H1L9 1z" />
        </svg>
      </div>
    </div>
  );
}

// ==================== 4. 完整语义短句切分 + 跨行同 ID 连续折行引擎 ====================

export interface ClauseSegment {
  text: string;
  clauseId: number;     // 同一短句跨行时共享相同 clauseId，实现跨行同步高光
  startX: number;
  endX: number;
  isClauseEnd: boolean; // 仅在完整语义短句结束处为 true
}

export interface VisualLine {
  segments: ClauseSegment[];
  clauseCount: number;
  wordCount: number;    // 本排有效词数（用于估算 WPM 与本排预期阅读耗时）
  charCount: number;    // 本排有效字符数（用于估算 CPM）
  widthRatio: number;
  isParaStart: boolean;
  isParaEnd: boolean;
}

const FONT_SIZE_PX = 14;
const FONT_SPEC = `${FONT_SIZE_PX}px system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`;
const ROWS_PER_PAGE = 15;
const LINE_HEIGHT_PX = 40;
const CLAUSE_GAP_PX = 8;

const CALIBRATION_POINTS = [
  [0.12, 0.14], [0.5, 0.14], [0.88, 0.14],
  [0.12, 0.50], [0.5, 0.50], [0.88, 0.50],
  [0.12, 0.86], [0.5, 0.86], [0.88, 0.86],
];

function countEffectiveWordsAndChars(text: string): { words: number; chars: number } {
  const cjkMatches = text.match(/[\u4e00-\u9fa5]/g) || [];
  const engMatches =
    text
      .replace(/[\u4e00-\u9fa5]/g, " ")
      .match(/[A-Za-z0-9]+(?:['’-][A-Za-z0-9]+)*/g) || [];
  const words = engMatches.length + cjkMatches.length / 1.8;
  const chars = text.replace(/\s+/g, "").length;
  return { words: Math.max(1, Number(words.toFixed(1))), chars: Math.max(1, chars) };
}

function joinTokens(a: string, b: string): string {
  if (!a) return b;
  if (!b) return a;
  if (/[—-]$/.test(a) || /^[—-]/.test(b)) return `${a}${b}`;
  const needSpace =
    /[A-Za-z0-9.,;:!?'"”’)\]]$/.test(a) && /^[A-Za-z0-9"“'‘(\[]/.test(b);
  return needSpace ? `${a} ${b}` : `${a}${b}`;
}

// Step 1: 原子级词法扫描器（保护 “葬送者”芙莉莲、the "Mem Sahib"、Mrs. Lennox 不被拆散）
function tokenizeWithAtomicProtection(para: string): string[] {
  const ATOMIC_SCAN_REGEX =
    /([\u4e00-\u9fa5A-Za-z0-9]{0,4}(?:“[^”\r\n]{1,16}”|「[^」\r\n]{1,16}」|『[^』\r\n]{1,16}』)[\u4e00-\u9fa5A-Za-z0-9]{0,6}[，。！？；：、,.!?;:—]*|\b(?:Mr|Mrs|Ms|Dr|Capt|St|Rev|Gov)\.\s+[A-Z][A-Za-z'-]+[,.;:!?—]*|(?:\b(?:the|a|an)\s+)?"[A-Z][A-Za-z\s-]{1,18}"[,.;:!?—]*|["“'‘(\[]*[A-Za-z0-9]+(?:\.[A-Za-z0-9]+)*['’-]?[A-Za-z0-9]*[,.;:!?'"”’)\]]*(?:—|--)?|[\u4e00-\u9fa5][，。！？；：、”’）》】—…]*|[^\s])/g;

  return para.match(ATOMIC_SCAN_REGEX) || [para];
}

interface SemanticClause {
  tokens: string[];
  text: string;
  isHardStop: boolean;
}

const ENG_VERB_SET = new Set([
  "is", "are", "was", "were", "be", "been", "am", "have", "has", "had", "do", "does", "did",
  "can", "could", "will", "would", "shall", "should", "may", "might", "must",
  "said", "came", "went", "looked", "stood", "saw", "heard", "knew", "stared", "began",
  "threw", "handed", "cared", "disliked", "awakened", "became", "seemed", "wandered",
  "pretended", "stuck", "called", "obeyed", "gave", "made", "kept", "held", "born", "died",
  "lived", "learned", "chosen", "stammered", "repeated", "left", "used", "wore", "told",
]);

function hasPredicateVerb(tokens: string[]): boolean {
  for (const t of tokens) {
    if (/[\u4e00-\u9fa5]/.test(t)) return tokens.length >= 4;
    const clean = t.toLowerCase().replace(/[^a-z]/g, "");
    if (ENG_VERB_SET.has(clean) || (clean.length > 4 && /(ed|ing|en|ize|ate)$/.test(clean))) {
      return true;
    }
  }
  return false;
}

// Step 2: 纯阅读逻辑短句切分（保护 sickly, fretful, ugly 等并列形容词，绝不按行宽截断）
function buildSemanticClauses(tokens: string[]): SemanticClause[] {
  const isCommaToken = (t: string) => /[,，、]['"”’)\]]*$/.test(t);
  const rawClauses: SemanticClause[] = [];
  let curTokens: string[] = [];
  let curText = "";
  let lastCommaOffset = -99;

  for (let i = 0; i < tokens.length; i++) {
    const tok = tokens[i];
    curTokens.push(tok);
    curText = joinTokens(curText, tok);

    const isAbbr = /\b(Mr|Mrs|Ms|Dr|Capt|St|Rev|Gov)\.$/i.test(tok);
    const isHard = !isAbbr && /([.!?。！？…]+['"”’)\]]*)$/.test(tok);
    const isSemiOrDash = /([;:—；：]+['"”’)\]]*|--)$/.test(tok);
    const isComma = isCommaToken(tok);

    if (isHard || isSemiOrDash) {
      rawClauses.push({ tokens: curTokens, text: curText, isHardStop: isHard });
      curTokens = [];
      curText = "";
      lastCommaOffset = -99;
      continue;
    }

    if (isComma) {
      const lookaheadComma =
        (i + 1 < tokens.length && isCommaToken(tokens[i + 1])) ||
        (i + 2 < tokens.length && isCommaToken(tokens[i + 2]));
      const isRecentComma = curTokens.length - lastCommaOffset <= 3;
      lastCommaOffset = curTokens.length;

      if (lookaheadComma || isRecentComma) {
        continue;
      }

      const nextSlice = tokens.slice(i + 1, Math.min(tokens.length, i + 8));
      const curHasVerb = hasPredicateVerb(curTokens);
      const nextHasVerb = hasPredicateVerb(nextSlice);
      const isCjkClause = /[\u4e00-\u9fa5]/.test(curText) && curText.length >= 6;

      if ((isCjkClause || (curTokens.length >= 5 && curHasVerb)) && (nextSlice.length >= 4 || nextHasVerb)) {
        rawClauses.push({ tokens: curTokens, text: curText, isHardStop: false });
        curTokens = [];
        curText = "";
        lastCommaOffset = -99;
      }
    }
  }

  if (curTokens.length > 0) {
    rawClauses.push({ tokens: curTokens, text: curText, isHardStop: true });
  }

  const merged: SemanticClause[] = [];
  for (let i = 0; i < rawClauses.length; i++) {
    const cur = rawClauses[i];
    const isTooShort = cur.tokens.length < 4 && cur.text.length < 18;

    if (isTooShort && !cur.isHardStop && i < rawClauses.length - 1) {
      const next = rawClauses[i + 1];
      rawClauses[i + 1] = {
        tokens: [...cur.tokens, ...next.tokens],
        text: joinTokens(cur.text, next.text),
        isHardStop: next.isHardStop,
      };
      continue;
    }

    if (isTooShort && merged.length > 0 && !merged[merged.length - 1].isHardStop) {
      const prev = merged[merged.length - 1];
      merged[merged.length - 1] = {
        tokens: [...prev.tokens, ...cur.tokens],
        text: joinTokens(prev.text, cur.text),
        isHardStop: cur.isHardStop,
      };
      continue;
    }

    merged.push(cur);
  }

  return merged;
}

// Step 3: 将完整短句流式排入视觉排，超出阅读框自动换行，同一短句保持相同 clauseId 跨行同步高光
function flowClausesIntoContinuousRows(
  clauses: SemanticClause[],
  indentStr: string,
  measure: (s: string) => number,
  maxTextWidth: number,
  startClauseId: number
): { lines: VisualLine[]; nextClauseId: number } {
  const lines: VisualLine[] = [];
  let curSegments: ClauseSegment[] = [];
  let curX = 0;
  let isFirstLineOfPara = true;
  let clauseIdCounter = startClauseId;

  const flushLine = (isParaEnd: boolean) => {
    if (curSegments.length === 0) return;
    const totalW = curSegments[curSegments.length - 1].endX;
    const uniqueClauses = new Set(curSegments.map((s) => s.clauseId)).size;
    const fullRowText = curSegments.map((s) => s.text).join(" ");
    const { words, chars } = countEffectiveWordsAndChars(fullRowText);
    lines.push({
      segments: curSegments,
      clauseCount: uniqueClauses,
      wordCount: words,
      charCount: chars,
      widthRatio: Math.min(1, Math.max(0.12, totalW / maxTextWidth)),
      isParaStart: isFirstLineOfPara,
      isParaEnd,
    });
    curSegments = [];
    curX = 0;
    isFirstLineOfPara = false;
  };

  for (let cIdx = 0; cIdx < clauses.length; cIdx++) {
    const clause = clauses[cIdx];
    const thisClauseId = clauseIdCounter++;
    const tokens = [...clause.tokens];
    if (cIdx === 0 && tokens.length > 0) {
      tokens[0] = indentStr + tokens[0];
    }

    let segText = "";
    let segStartX = curSegments.length > 0 ? curX + CLAUSE_GAP_PX : 0;

    for (let tIdx = 0; tIdx < tokens.length; tIdx++) {
      const tok = tokens[tIdx];
      const candidate = segText ? joinTokens(segText, tok) : tok;
      const candidateW = measure(candidate);

      if (segStartX + candidateW > maxTextWidth) {
        if (segText) {
          const w = measure(segText);
          curSegments.push({
            text: segText,
            clauseId: thisClauseId,
            startX: segStartX,
            endX: segStartX + w,
            isClauseEnd: false,
          });
          curX = segStartX + w;
          flushLine(false);
          segText = tok;
          segStartX = 0;
        } else if (curSegments.length > 0) {
          flushLine(false);
          segText = tok;
          segStartX = 0;
        } else {
          const w = Math.min(maxTextWidth, candidateW);
          curSegments.push({
            text: tok,
            clauseId: thisClauseId,
            startX: 0,
            endX: w,
            isClauseEnd: tIdx === tokens.length - 1,
          });
          curX = w;
          if (tIdx < tokens.length - 1) flushLine(false);
          segText = "";
          segStartX = 0;
        }
      } else {
        segText = candidate;
      }
    }

    if (segText) {
      const w = measure(segText);
      curSegments.push({
        text: segText,
        clauseId: thisClauseId,
        startX: segStartX,
        endX: segStartX + w,
        isClauseEnd: true,
      });
      curX = segStartX + w;
    }
  }

  flushLine(true);
  return { lines, nextClauseId: clauseIdCounter };
}

// Step 4: 组装入口 —— 把单个自然段打包成视觉排 (VisualLine[])
function packParagraphIntoVisualLines(
  para: string,
  ctx: CanvasRenderingContext2D,
  maxTextWidth: number,
  startClauseId = 0
): { lines: VisualLine[]; nextClauseId: number } {
  ctx.font = FONT_SPEC;
  const measure = (s: string) => ctx.measureText(s).width;
  const indentStr = /^[\u4e00-\u9fa5“「『]/.test(para) ? "  " : "    ";
  const tokens = tokenizeWithAtomicProtection(para);
  const clauses = buildSemanticClauses(tokens);
  return flowClausesIntoContinuousRows(clauses, indentStr, measure, maxTextWidth, startClauseId);
}

// ==================== 5. 预设文本：英文版《秘密花园》第一章 & 语义粘合测试 ====================

const SECRET_GARDEN_CH1 = `CHAPTER I — THERE IS NO ONE LEFT
When Mary Lennox was sent to Misselthwaite Manor to live with her uncle, everybody said she was the most disagreeable-looking child ever seen. It was true, too. She had a little thin face and a little thin body, thin light hair and a sour expression. Her hair was yellow, and her face was yellow because she had been born in India and had always been ill in one way or another. Her father had held a position under the English Government and had always been busy and ill himself, and her mother had been a great beauty who cared only to go to parties and amuse herself with gay people. She had not wanted a little daughter at all, and when Mary was born she handed her over to the care of an Ayah, who was made to understand that if she wished to please the "Mem Sahib" she must keep the child out of sight as much as possible. So when she was a sickly, fretful, ugly little baby she was kept out of the way, and when she became a sickly, fretful, toddling thing she was kept out of the way also. She never remembered seeing familiarly anything but the dark faces of her Ayah and the other native servants, and as they always obeyed her and gave her her own way in everything, because the "Mem Sahib" would be angry if she was disturbed by her crying, by the time she was six years old she was as tyrannical and selfish a little pig as ever lived. The young English governess who came to teach her to read and write disliked her so much that she gave up her place in three months, and when other governesses came to try to fill it they always went away in a shorter time than the first one. So if Mary had not chosen to really want to know how to read books she would never have learned her letters at all.
One frightfully hot morning, when she was about nine years old, she awakened feeling very cross, and she became crosser still when she saw that the servant who stood by her bedside was not her own Ayah.
"Why did you come?" she said to the strange woman. "I will not let you stay. Send my Ayah to me."
The woman looked frightened, but she only stammered that the Ayah could not come and when Mary threw herself into a passion and beat and kicked her, she looked only more frightened and repeated that it was not possible for the Ayah to come to the "Missie Sahib."
There was something mysterious in the air that morning. Nothing was done in its regular order and several of the native servants seemed missing, while those whom Mary saw slunk or hurried about with ashy and terrified faces. But no one would tell her anything and her Ayah did not come. She was actually left alone as the morning went on, and at last she wandered out into the garden and began to play by herself under a tree near the veranda. She pretended that she was making a flower-bed, and she stuck big scarlet hibiscus blossoms into little heaps of earth, all the time growing more and more angry and muttering to herself the things she would say and the names she would call Saidie when she returned.
"Pig! Pig! Daughter of Pigs!" she said, because to call a native a pig is the worst insult of all.
She was grinding her teeth and saying this over and over again when she heard her mother come out on the veranda with some one. She was with a fair young man and they stood talking together in low strange voices. Mary knew the fair young man who looked like a boy. She had heard that he was a young officer who had just come from England. The child stared at him, but she stared most at her mother. She always did this when she had a chance to see her, because the "Mem Sahib"—Mary used to call her that oftener than anything else—was such a tall, slim, pretty person and wore such lovely clothes.`;

const EDGE_CASE_TEST_TXT = `So when she was a sickly, fretful, ugly little baby she was kept out of the way, and when she became a sickly, fretful, toddling thing she was kept out of the way also.
“葬送者”芙莉莲在漫长的旅途中，逐渐理解了人类短暂却耀眼的生命。哪怕“葬送者”芙莉莲平日里显得冷淡，她依然记得辛美尔说的每一句话。虽然旅途漫长，但是“葬送者”芙莉莲从未停下脚步，她与菲伦、休塔尔克一同走过了曾经的北方诸国，所有的短句都在保持原有自然段不打断的前提下连续铺开，当一个长短句跨越多行时整句会同时高光，且没有任何整行背景高光。`;

const DEFAULT_TXT = SECRET_GARDEN_CH1;

// ==================== 6. Next.js 主页面组件 ====================

export default function GazeTxtReaderPage() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const readerBoxRef = useRef<HTMLDivElement | null>(null);
  const meshCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const miniHeatmapCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const fullHeatmapCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [modelReady, setModelReady] = useState(false);
  const [fps, setFps] = useState(0);
  const [rawText, setRawText] = useState(DEFAULT_TXT);
  const [pages, setPages] = useState<VisualLine[][]>([]);
  const [pageIdx, setPageIdx] = useState(0);
  const [activeClauseId, setActiveClauseId] = useState(0);
  const [showRowMeta, setShowRowMeta] = useState(true);

  // 阅读速度与换行锁存遥测状态
  const [readingStats, setReadingStats] = useState({
    wpm: 190,
    cpm: 950,
    lineProgressPct: 0,
    rightZoneLatched: false,
    currentLineIdx: 0,
  });

  const [isCalibrating, setIsCalibrating] = useState(false);
  const [calibStep, setCalibStep] = useState(0);
  const [isCalibrated, setIsCalibrated] = useState(false);
  const [gazePoint, setGazePoint] = useState({ x: 0, y: 0, rawY: 0, biasY: 0 });

  const [winVideo, setWinVideo] = useState<WinState>({ visible: true, x: 18, y: 70, w: 250, h: 195 });
  const [winMesh, setWinMesh] = useState<WinState>({ visible: true, x: 18, y: 280, w: 280, h: 225 });
  const [winHeatmap, setWinHeatmap] = useState<WinState>({ visible: true, x: 18, y: 520, w: 280, h: 215 });

  const [meshShowVideoBg, setMeshShowVideoBg] = useState(false);
  const [showPageHeatmap, setShowPageHeatmap] = useState(true);
  const [heatmapDecayMode, setHeatmapDecayMode] = useState(true);
  const [heatmapUseRawY, setHeatmapUseRawY] = useState(false);

  const uiConfigRef = useRef({ meshShowVideoBg: false, heatmapDecayMode: true, heatmapUseRawY: false });
  useEffect(() => {
    uiConfigRef.current = { meshShowVideoBg, heatmapDecayMode, heatmapUseRawY };
  }, [meshShowVideoBg, heatmapDecayMode, heatmapUseRawY]);

  const layoutRef = useRef<{ pages: VisualLine[][]; pageIdx: number }>({ pages: [], pageIdx: 0 });
  useEffect(() => {
    layoutRef.current = { pages, pageIdx };
  }, [pages, pageIdx]);

  const heatGridRef = useRef<Float32Array>(new Float32Array(HEAT_W * HEAT_H));
  const offscreenHeatCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const weightsRef = useRef<number[][] | null>(null);
  const calibSamplesRef = useRef<{ X: number[][]; Y: number[][] }>({ X: [], Y: [] });
  const collectingPointRef = useRef<{ targetX: number; targetY: number; remaining: number } | null>(null);

  const filterXRef = useRef(new OneEuroFilter(0.85, 0.015, 1.0));
  const filterYRef = useRef(new OneEuroFilter(0.55, 0.008, 1.0));

  const stateRef = useRef({
    currentLine: 0,
    currentClauseId: 0,
    biasY: 0,
    recentX: [] as number[],
    maxLineX: 0,
    reachedRightZone: false,
    lastSweepTime: 0,
    lineEnterTime: 0,
    forwardCandidateId: -1,
    forwardStartTime: 0,
    backwardCandidateId: -1,
    backwardStartTime: 0,
    verticalJumpStartTime: 0,
    wpmEma: 190,
    cpmEma: 950,
  });

  // 1. 保持自然段连续，完整短句切分并在跨行时赋予相同 clauseId
  const paginateText = useCallback((text: string, containerWidth: number) => {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.font = FONT_SPEC;

    const maxTextWidth = Math.max(containerWidth - 112, 320);
    const visualLines: VisualLine[] = [];
    let globalClauseId = 0;

    for (const para of text.split(/\r?\n/)) {
      const trimmed = para.trim();
      if (!trimmed) continue;
      const { lines, nextClauseId } = packParagraphIntoVisualLines(
        trimmed,
        ctx,
        maxTextWidth,
        globalClauseId
      );
      globalClauseId = nextClauseId;
      visualLines.push(...lines);
    }

    // 分页保护：若当页最后一排末尾短句尚未结束（跨行到了下一排），将该短句所在下一排一并纳入本页
    const paged: VisualLine[][] = [];
    let i = 0;
    while (i < visualLines.length) {
      let end = Math.min(i + ROWS_PER_PAGE, visualLines.length);
      while (end < visualLines.length) {
        const lastRowSegs = visualLines[end - 1].segments;
        const lastSeg = lastRowSegs[lastRowSegs.length - 1];
        if (lastSeg && !lastSeg.isClauseEnd && end - i < ROWS_PER_PAGE + 2) {
          end += 1;
        } else {
          break;
        }
      }
      paged.push(visualLines.slice(i, end));
      i = end;
    }

    const finalPages = paged.length
      ? paged
      : [
          [
            {
              segments: [{ text: "(Empty Document)", clauseId: 0, startX: 0, endX: 120, isClauseEnd: true }],
              clauseCount: 1,
              wordCount: 2,
              charCount: 14,
              widthRatio: 0.2,
              isParaStart: true,
              isParaEnd: true,
            },
          ],
        ];

    const firstClause = finalPages[0]?.[0]?.segments?.[0]?.clauseId ?? 0;
    setPages(finalPages);
    setPageIdx(0);
    setActiveClauseId(firstClause);
    stateRef.current.currentLine = 0;
    stateRef.current.currentClauseId = firstClause;
    stateRef.current.reachedRightZone = false;
    stateRef.current.maxLineX = 0;
  }, []);

  useEffect(() => {
    const updateLayout = () => {
      const w = readerBoxRef.current?.clientWidth ?? 860;
      paginateText(rawText, w);
    };
    updateLayout();
    window.addEventListener("resize", updateLayout);
    return () => window.removeEventListener("resize", updateLayout);
  }, [rawText, paginateText]);

  // 2. 更新浮点热力场并同步渲染至「全页叠加层」与「热力监控小窗」
  const updateAndRenderHeatmaps = useCallback((gx: number, gy: number, rect: DOMRect, curLine: number, lineCount: number) => {
    const grid = heatGridRef.current;
    const { heatmapDecayMode: decayMode } = uiConfigRef.current;

    const decay = decayMode ? 0.965 : 0.999;
    for (let i = 0; i < grid.length; i++) {
      grid[i] *= decay;
    }

    const cx = Math.round((gx / Math.max(1, window.innerWidth)) * (HEAT_W - 1));
    const cy = Math.round((gy / Math.max(1, window.innerHeight)) * (HEAT_H - 1));
    const radius = 13;
    const r2 = radius * radius;

    const yMin = Math.max(0, cy - radius);
    const yMax = Math.min(HEAT_H - 1, cy + radius);
    const xMin = Math.max(0, cx - radius);
    const xMax = Math.min(HEAT_W - 1, cx + radius);

    for (let y = yMin; y <= yMax; y++) {
      const dy2 = (y - cy) * (y - cy);
      const rowOffset = y * HEAT_W;
      for (let x = xMin; x <= xMax; x++) {
        const d2 = (x - cx) * (x - cx) + dy2;
        if (d2 <= r2) {
          const boost = Math.exp(-d2 / (2 * 30)) * 22;
          grid[rowOffset + x] = Math.min(255, grid[rowOffset + x] + boost);
        }
      }
    }

    if (!offscreenHeatCanvasRef.current) {
      const c = document.createElement("canvas");
      c.width = HEAT_W;
      c.height = HEAT_H;
      offscreenHeatCanvasRef.current = c;
    }
    const offCtx = offscreenHeatCanvasRef.current.getContext("2d");
    if (!offCtx) return;

    const imgData = offCtx.createImageData(HEAT_W, HEAT_H);
    const buf32 = new Uint32Array(imgData.data.buffer);
    for (let i = 0; i < grid.length; i++) {
      buf32[i] = HEATMAP_LUT[Math.min(255, grid[i] | 0)];
    }
    offCtx.putImageData(imgData, 0, 0);

    if (fullHeatmapCanvasRef.current) {
      const fCtx = fullHeatmapCanvasRef.current.getContext("2d");
      if (fCtx) {
        fCtx.clearRect(0, 0, HEAT_W, HEAT_H);
        fCtx.drawImage(offscreenHeatCanvasRef.current, 0, 0, HEAT_W, HEAT_H);
      }
    }

    if (miniHeatmapCanvasRef.current) {
      const mCanvas = miniHeatmapCanvasRef.current;
      const mCtx = mCanvas.getContext("2d");
      if (mCtx) {
        const mw = mCanvas.width;
        const mh = mCanvas.height;
        mCtx.clearRect(0, 0, mw, mh);

        const scaleX = mw / Math.max(1, window.innerWidth);
        const scaleY = mh / Math.max(1, window.innerHeight);
        mCtx.strokeStyle = "rgba(71, 85, 105, 0.5)";
        mCtx.strokeRect(rect.left * scaleX, rect.top * scaleY, rect.width * scaleX, rect.height * scaleY);

        for (let i = 0; i < lineCount; i++) {
          const ly = (rect.top + 24 + i * LINE_HEIGHT_PX) * scaleY;
          const lh = (LINE_HEIGHT_PX - 5) * scaleY;
          mCtx.fillStyle = i === curLine ? "rgba(99, 102, 241, 0.22)" : "rgba(30, 41, 59, 0.45)";
          mCtx.fillRect((rect.left + 24) * scaleX, ly, (rect.width - 48) * scaleX, lh);
        }

        mCtx.drawImage(offscreenHeatCanvasRef.current, 0, 0, mw, mh);

        const mx = gx * scaleX;
        const my = gy * scaleY;
        mCtx.strokeStyle = "#ffffff";
        mCtx.lineWidth = 1.2;
        mCtx.beginPath();
        mCtx.arc(mx, my, 4, 0, Math.PI * 2);
        mCtx.stroke();
      }
    }
  }, []);

  // 3. 初始化摄像头与 MediaPipe FaceLandmarker + 30FPS 追踪循环
  useEffect(() => {
    let landmarker: FaceLandmarker | null = null;
    let rafId = 0;
    let lastInferMs = -1;
    let frameCounter = 0;
    let fpsTimer = performance.now();
    let active = true;

    async function setup() {
      const vision = await FilesetResolver.forVisionTasks(
        "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm"
      );
      if (!active) return;
      landmarker = await FaceLandmarker.createFromOptions(vision, {
        baseOptions: {
          modelAssetPath:
            "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task",
          delegate: "GPU",
        },
        outputFaceBlendshapes: true,
        outputFacialTransformationMatrixes: true,
        runningMode: "VIDEO",
        numFaces: 1,
      });

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, frameRate: { ideal: 30 } },
      });
      if (!active) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setModelReady(true);
      }

      const loop = () => {
        if (!active) return;
        rafId = requestAnimationFrame(loop);

        const video = videoRef.current;
        if (!video || video.readyState < 2 || video.videoWidth === 0 || !landmarker) return;

        const now = performance.now();
        if (now - lastInferMs < 32) return;
        const timestampMs = Math.max(Math.floor(now), lastInferMs + 1);
        lastInferMs = timestampMs;

        frameCounter++;
        if (now - fpsTimer >= 1000) {
          setFps(frameCounter);
          frameCounter = 0;
          fpsTimer = now;
        }

        const res = landmarker.detectForVideo(video, timestampMs);
        const tel = extractGazeTelemetry(res);

        if (meshCanvasRef.current) {
          drawFaceAndEyeMesh(
            meshCanvasRef.current,
            res,
            tel,
            video,
            uiConfigRef.current.meshShowVideoBg
          );
        }

        if (!tel || tel.blink > 0.5) return;
        const feat = tel.features;

        if (collectingPointRef.current && collectingPointRef.current.remaining > 0) {
          calibSamplesRef.current.X.push(feat);
          calibSamplesRef.current.Y.push([
            collectingPointRef.current.targetX,
            collectingPointRef.current.targetY,
          ]);
          collectingPointRef.current.remaining -= 1;
          return;
        }

        const W = weightsRef.current;
        if (!W || !readerBoxRef.current) return;

        let rawX = 0;
        let rawY = 0;
        for (let i = 0; i < feat.length; i++) {
          rawX += feat[i] * W[i][0];
          rawY += feat[i] * W[i][1];
        }

        const filtX = filterXRef.current.filter(rawX, timestampMs);
        const filtY = filterYRef.current.filter(rawY, timestampMs) + stateRef.current.biasY;

        const rect = readerBoxRef.current.getBoundingClientRect();
        const { pages: curPages, pageIdx: curPageIdx } = layoutRef.current;
        const lineCount = curPages[curPageIdx]?.length ?? 1;
        const st = stateRef.current;
        if (st.lineEnterTime === 0) st.lineEnterTime = timestampMs;

        const getLineCenterY = (idx: number) => rect.top + 24 + (idx + 0.5) * LINE_HEIGHT_PX;
        const currentLineObj = curPages[curPageIdx]?.[st.currentLine] ?? {
          segments: [],
          clauseCount: 1,
          wordCount: 8,
          charCount: 45,
          widthRatio: 1,
          isParaStart: true,
          isParaEnd: false,
        };

        st.recentX.push(filtX);
        if (st.recentX.length > 3) st.recentX.shift();
        const smoothX = st.recentX.reduce((a, b) => a + b, 0) / st.recentX.length;

        const textWidthPx = rect.width - 112;
        const lineStartX = rect.left + 68;
        const localX = Math.max(0, smoothX - lineStartX);
        const lineDwellMs = timestampMs - st.lineEnterTime;

        // 基于实时 WPM 估算本排合理阅读耗时
        const expectedLineMs = Math.max(
          550,
          ((currentLineObj.wordCount || 8) / Math.max(80, st.wpmEma)) * 60000
        );
        const timeProgress = Math.min(1.6, lineDwellMs / expectedLineMs);

        // 1. 顺畅正常换行：右端到达锁存器 (进入新排满 260ms 后开始记录，永不过期)
        if (lineDwellMs > 260) {
          if (smoothX > st.maxLineX) st.maxLineX = smoothX;
          const rightTriggerRatio = Math.max(0.20, currentLineObj.widthRatio * 0.45);
          if (localX >= textWidthPx * rightTriggerRatio || timeProgress >= 0.85) {
            st.reachedRightZone = true;
          }
        }

        // 当右端已锁存后，视线向左回撤即可低阻力顺畅换入下一排
        const leftLandingRatio = timeProgress >= 0.65 ? 0.50 : 0.44;
        const leftReturnX =
          lineStartX +
          textWidthPx * Math.min(leftLandingRatio, Math.max(0.25, currentLineObj.widthRatio * 0.72));
        const minSweepDropPx = textWidthPx * Math.max(0.14, currentLineObj.widthRatio * 0.22);

        const canNormalWrap =
          st.reachedRightZone &&
          lineDwellMs >= Math.min(480, expectedLineMs * 0.38) &&
          timestampMs - st.lastSweepTime > 520 &&
          smoothX <= leftReturnX &&
          st.maxLineX - smoothX >= minSweepDropPx;

        // 自然段末尾短尾排（宽度 < 32%）在读满预期时间后的顺畅推进
        const canShortTailWrap =
          currentLineObj.widthRatio < 0.32 &&
          lineDwellMs >= expectedLineMs * 0.95 &&
          timestampMs - st.lastSweepTime > 650 &&
          filtY > getLineCenterY(st.currentLine) + LINE_HEIGHT_PX * 0.35;

        if (canNormalWrap || canShortTailWrap) {
          // 更新实时阅读速度 EMA (过滤掉 <400ms 或 >20s 的异常停顿)
          if (lineDwellMs >= 400 && lineDwellMs <= 20000 && currentLineObj.wordCount >= 2) {
            const instWpm = (currentLineObj.wordCount / lineDwellMs) * 60000;
            const instCpm = (currentLineObj.charCount / lineDwellMs) * 60000;
            st.wpmEma = Math.round(st.wpmEma * 0.72 + Math.min(550, Math.max(60, instWpm)) * 0.28);
            st.cpmEma = Math.round(st.cpmEma * 0.72 + Math.min(2200, Math.max(150, instCpm)) * 0.28);
          }

          st.lastSweepTime = timestampMs;
          st.reachedRightZone = false;
          st.maxLineX = lineStartX;
          st.backwardCandidateId = -1;
          st.verticalJumpStartTime = 0;

          if (st.currentLine < lineCount - 1) {
            st.currentLine += 1;
            st.lineEnterTime = timestampMs;
            const nextRowSegs = curPages[curPageIdx]?.[st.currentLine]?.segments ?? [];
            if (nextRowSegs.length > 0) {
              st.currentClauseId = nextRowSegs[0].clauseId;
              setActiveClauseId(nextRowSegs[0].clauseId);
            }

            const trueY = getLineCenterY(st.currentLine);
            const residualY = trueY - filtY;
            if (Math.abs(residualY) < LINE_HEIGHT_PX * 3.5) {
              st.biasY += 0.08 * residualY;
            }
          } else if (curPageIdx < curPages.length - 1) {
            st.currentLine = 0;
            st.lineEnterTime = timestampMs;
            const nextFirstClause = curPages[curPageIdx + 1]?.[0]?.segments?.[0]?.clauseId ?? 0;
            st.currentClauseId = nextFirstClause;
            setActiveClauseId(nextFirstClause);
            setPageIdx(curPageIdx + 1);
          }
        } else {
          // 2. 高阻力跨行/回退上一行门限：必须连续 1500ms 偏离超过 2.1 倍行高才允许跳行或回上一行
          const diffY = filtY - getLineCenterY(st.currentLine);
          const isTryingPrevLine = diffY < -LINE_HEIGHT_PX * 2.1;
          const isTryingSkipLine = diffY > LINE_HEIGHT_PX * 2.4;

          if (isTryingPrevLine || isTryingSkipLine) {
            if (st.verticalJumpStartTime === 0) {
              st.verticalJumpStartTime = timestampMs;
            } else if (timestampMs - st.verticalJumpStartTime > 1500) {
              let bestIdx = st.currentLine;
              let minDiff = Infinity;
              for (let i = 0; i < lineCount; i++) {
                const d = Math.abs(filtY - getLineCenterY(i));
                if (d < minDiff) {
                  minDiff = d;
                  bestIdx = i;
                }
              }
              if (bestIdx !== st.currentLine) {
                st.currentLine = bestIdx;
                st.lineEnterTime = timestampMs;
                st.reachedRightZone = false;
                st.maxLineX = lineStartX;
                const targetSegs = curPages[curPageIdx]?.[bestIdx]?.segments ?? [];
                if (targetSegs.length > 0) {
                  st.currentClauseId = targetSegs[0].clauseId;
                  setActiveClauseId(targetSegs[0].clauseId);
                }
              }
              st.verticalJumpStartTime = 0;
            }
          } else {
            st.verticalJumpStartTime = 0;
          }
        }

        // 3. 排内短句匹配：向前推进低阻力 (120ms)，向后回退极高阻力 (950ms 持续注视，且回扫途中冻结逆向切换)
        const activeLineSegments = curPages[curPageIdx]?.[st.currentLine]?.segments ?? [];
        if (activeLineSegments.length > 0) {
          let rawMatchedId = st.currentClauseId;
          for (let s = 0; s < activeLineSegments.length; s++) {
            const seg = activeLineSegments[s];
            if (localX >= seg.startX - 8 && localX <= seg.endX + 8) {
              rawMatchedId = seg.clauseId;
              break;
            }
          }

          if (rawMatchedId > st.currentClauseId) {
            if (st.forwardCandidateId !== rawMatchedId) {
              st.forwardCandidateId = rawMatchedId;
              st.forwardStartTime = timestampMs;
            } else if (timestampMs - st.forwardStartTime >= 120) {
              st.currentClauseId = rawMatchedId;
              setActiveClauseId(rawMatchedId);
            }
            st.backwardCandidateId = -1;
          } else if (rawMatchedId < st.currentClauseId) {
            const isSweepingLeft = st.reachedRightZone && smoothX < st.maxLineX - 35;
            if (!isSweepingLeft) {
              if (st.backwardCandidateId !== rawMatchedId) {
                st.backwardCandidateId = rawMatchedId;
                st.backwardStartTime = timestampMs;
              } else if (timestampMs - st.backwardStartTime >= 950) {
                st.currentClauseId = rawMatchedId;
                setActiveClauseId(rawMatchedId);
                st.backwardCandidateId = -1;
              }
            }
            st.forwardCandidateId = -1;
          } else {
            st.forwardCandidateId = -1;
            st.backwardCandidateId = -1;
          }
        }

        setReadingStats({
          wpm: st.wpmEma,
          cpm: st.cpmEma,
          lineProgressPct: Math.min(100, Math.round(timeProgress * 100)),
          rightZoneLatched: st.reachedRightZone,
          currentLineIdx: st.currentLine,
        });

        const snappedY = getLineCenterY(st.currentLine);
        const clampedX = Math.max(lineStartX, Math.min(rect.right - 36, smoothX));
        setGazePoint({ x: clampedX, y: snappedY, rawY: filtY, biasY: Math.round(st.biasY) });

        const targetHeatY = uiConfigRef.current.heatmapUseRawY ? filtY : snappedY;
        updateAndRenderHeatmaps(clampedX, targetHeatY, rect, st.currentLine, lineCount);
      };

      rafId = requestAnimationFrame(loop);
    }

    setup();
    return () => {
      active = false;
      cancelAnimationFrame(rafId);
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach((t) => t.stop());
      }
      landmarker?.close();
    };
  }, [updateAndRenderHeatmaps]);

  // 4. 触发 9 点校准采样
  const startCalibration = () => {
    calibSamplesRef.current = { X: [], Y: [] };
    setCalibStep(0);
    setIsCalibrating(true);
  };

  const handleCalibPointClick = (tx: number, ty: number) => {
    if (collectingPointRef.current && collectingPointRef.current.remaining > 0) return;
    collectingPointRef.current = { targetX: tx, targetY: ty, remaining: 22 };

    const checkTimer = setInterval(() => {
      if (collectingPointRef.current && collectingPointRef.current.remaining <= 0) {
        clearInterval(checkTimer);
        if (calibStep < CALIBRATION_POINTS.length - 1) {
          setCalibStep((s) => s + 1);
        } else {
          const { X, Y } = calibSamplesRef.current;
          weightsRef.current = solveRidgeRegression(X, Y, 0.05);
          const firstClause = pages[pageIdx]?.[0]?.segments?.[0]?.clauseId ?? 0;
          stateRef.current.biasY = 0;
          stateRef.current.currentLine = 0;
          stateRef.current.currentClauseId = firstClause;
          stateRef.current.lineEnterTime = performance.now();
          stateRef.current.reachedRightZone = false;
          stateRef.current.maxLineX = 0;
          heatGridRef.current.fill(0);
          setActiveClauseId(firstClause);
          setIsCalibrating(false);
          setIsCalibrated(true);
        }
      }
    }, 30);
  };

  // 5. 本地 TXT 文件导入
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const buffer = await file.arrayBuffer();
    let decoded = new TextDecoder("utf-8", { fatal: false }).decode(buffer);
    if (decoded.includes("\uFFFD")) {
      decoded = new TextDecoder("gbk").decode(buffer);
    }
    setRawText(decoded);
  };

  const currentLines = pages[pageIdx] ?? [];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col select-none">
      {/* 全页面实时视线热力叠加层 */}
      <canvas
        ref={fullHeatmapCanvasRef}
        width={HEAT_W}
        height={HEAT_H}
        className={`pointer-events-none fixed inset-0 w-full h-full z-30 transition-opacity duration-200 ${
          showPageHeatmap && isCalibrated && !isCalibrating ? "opacity-80" : "opacity-0"
        }`}
      />

      {/* ==================== 三个可自由拖拽与缩放的浮动小窗 ==================== */}

      {/* 小窗 1：原始摄像头视频流 */}
      <FloatingWindow title="1. 摄像头实时画面" winState={winVideo} setWinState={setWinVideo}>
        <div className="relative w-full h-full bg-black overflow-hidden">
          <video
            ref={videoRef}
            playsInline
            muted
            className="w-full h-full object-cover -scale-x-100"
          />
          <div className="absolute bottom-1.5 left-2 text-[11px] font-mono bg-slate-950/75 px-1.5 py-0.5 rounded text-emerald-400 border border-slate-800">
            {fps} FPS | 640×480
          </div>
        </div>
      </FloatingWindow>

      {/* 小窗 2：眼动与面部识别点线叠加 */}
      <FloatingWindow
        title="2. 眼动与面部点线拓扑"
        winState={winMesh}
        setWinState={setWinMesh}
        headerExtra={
          <button
            onClick={() => setMeshShowVideoBg((v) => !v)}
            className="px-1.5 py-0.5 text-[10px] rounded bg-slate-700 hover:bg-slate-600 text-slate-200"
          >
            {meshShowVideoBg ? "纯网格底" : "叠视频底"}
          </button>
        }
      >
        <canvas
          ref={meshCanvasRef}
          width={320}
          height={240}
          className="w-full h-full bg-slate-950 block object-contain"
        />
      </FloatingWindow>

      {/* 小窗 3：全页面视线热力鸟瞰与控制小窗 */}
      <FloatingWindow
        title="3. 视线热力监控"
        winState={winHeatmap}
        setWinState={setWinHeatmap}
        minW={240}
        minH={185}
        headerExtra={
          <button
            onClick={() => heatGridRef.current.fill(0)}
            className="px-1.5 py-0.5 text-[10px] rounded bg-slate-700 hover:bg-rose-600 text-slate-200 transition"
          >
            清空热力
          </button>
        }
      >
        <div className="w-full h-full flex flex-col bg-slate-950">
          <div className="flex-1 relative min-h-0">
            <canvas
              ref={miniHeatmapCanvasRef}
              width={280}
              height={160}
              className="w-full h-full block"
            />
            {!isCalibrated && (
              <div className="absolute inset-0 flex items-center justify-center text-xs text-slate-500">
                完成 9 点校准后显示实时热力轨迹
              </div>
            )}
          </div>
          <div className="h-8 px-2 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-[11px] shrink-0">
            <label className="flex items-center gap-1 cursor-pointer text-slate-300">
              <input
                type="checkbox"
                checked={showPageHeatmap}
                onChange={(e) => setShowPageHeatmap(e.target.checked)}
                className="accent-indigo-500"
              />
              全页热力叠加
            </label>
            <button
              onClick={() => setHeatmapDecayMode((m) => !m)}
              className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-indigo-300"
            >
              {heatmapDecayMode ? "模式: 实时消散" : "模式: 持久累积"}
            </button>
            <button
              onClick={() => setHeatmapUseRawY((r) => !r)}
              className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
            >
              {heatmapUseRawY ? "源: 原始Y" : "源: 行吸附Y"}
            </button>
          </div>
        </div>
      </FloatingWindow>

      {/* ==================== 顶部主导航栏 ==================== */}
      <header className="h-14 border-b border-slate-800 px-5 flex items-center justify-between bg-slate-900/80 backdrop-blur z-30">
        <div className="flex items-center gap-3">
          <span className="font-semibold tracking-wide text-slate-200">
            WebEye 跨行短句高光阅读器 (14px)
          </span>
          <span className="text-xs px-2.5 py-1 rounded bg-slate-800 text-slate-400">
            {!modelReady
              ? "正在加载 MediaPipe GPU 模型..."
              : isCalibrated
              ? `第 ${readingStats.currentLineIdx + 1} 排 | ${
                  readingStats.rightZoneLatched ? "✓ 右端已就绪(左扫即换行)" : "正在向右阅读..."
                } | 漂移补偿: ${gazePoint.biasY > 0 ? `+${gazePoint.biasY}` : gazePoint.biasY}px`
              : "模型就绪，请先执行 9 点校准"}
          </span>

          {/* 实时阅读速度估算徽章 */}
          <div className="flex items-center gap-2 px-2.5 py-1 rounded bg-indigo-950/70 border border-indigo-500/30 text-xs font-mono">
            <span className="text-indigo-300">
              语速: <strong>{readingStats.wpm}</strong> WPM
            </span>
            <span className="text-slate-500">|</span>
            <span className="text-emerald-300">{readingStats.cpm} CPM</span>
            <span className="text-slate-500">|</span>
            <span className="text-amber-300" title="当前排驻留时间占预期阅读耗时比例">
              本排进度: {readingStats.lineProgressPct}%
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <button
            onClick={() => setRawText(SECRET_GARDEN_CH1)}
            className={`px-2 py-1 rounded border transition ${
              rawText === SECRET_GARDEN_CH1
                ? "bg-emerald-600/25 border-emerald-500 text-emerald-200"
                : "bg-slate-800 border-slate-700 text-slate-400"
            }`}
          >
            Secret Garden Ch.1
          </button>
          <button
            onClick={() => setRawText(EDGE_CASE_TEST_TXT)}
            className={`px-2 py-1 rounded border transition ${
              rawText === EDGE_CASE_TEST_TXT
                ? "bg-emerald-600/25 border-emerald-500 text-emerald-200"
                : "bg-slate-800 border-slate-700 text-slate-400"
            }`}
          >
            形容词与芙莉莲测试
          </button>

          <button
            onClick={() => setShowRowMeta((v) => !v)}
            className={`px-2 py-1 rounded border transition ${
              showRowMeta
                ? "bg-sky-600/25 border-sky-500 text-sky-200"
                : "bg-slate-800 border-slate-700 text-slate-400"
            }`}
            title="显示或隐藏阅读框外右侧的 x短句 | y% 标签"
          >
            框外指标: {showRowMeta ? "显" : "隐"}
          </button>

          <div className="h-4 w-[1px] bg-slate-800 mx-0.5" />

          <button
            onClick={() => setWinVideo((p) => ({ ...p, visible: !p.visible }))}
            className={`px-2 py-1 rounded border transition ${
              winVideo.visible
                ? "bg-indigo-600/25 border-indigo-500 text-indigo-200"
                : "bg-slate-800 border-slate-700 text-slate-400"
            }`}
          >
            视频窗
          </button>
          <button
            onClick={() => setWinMesh((p) => ({ ...p, visible: !p.visible }))}
            className={`px-2 py-1 rounded border transition ${
              winMesh.visible
                ? "bg-indigo-600/25 border-indigo-500 text-indigo-200"
                : "bg-slate-800 border-slate-700 text-slate-400"
            }`}
          >
            拓扑窗
          </button>
          <button
            onClick={() => setWinHeatmap((p) => ({ ...p, visible: !p.visible }))}
            className={`px-2 py-1 rounded border transition ${
              winHeatmap.visible
                ? "bg-indigo-600/25 border-indigo-500 text-indigo-200"
                : "bg-slate-800 border-slate-700 text-slate-400"
            }`}
          >
            热力窗
          </button>

          <label className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 cursor-pointer transition text-slate-200">
            导入 TXT
            <input type="file" accept=".txt" onChange={handleFileUpload} className="hidden" />
          </label>
          <button
            disabled={!modelReady}
            onClick={startCalibration}
            className="px-3 py-1.5 rounded bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 font-medium text-white transition"
          >
            {isCalibrated ? "重新 9 点校准" : "开始 9 点校准"}
          </button>

          <div className="flex items-center gap-1 ml-1">
            <button
              onClick={() => {
                const nextP = Math.max(0, pageIdx - 1);
                const firstCid = pages[nextP]?.[0]?.segments?.[0]?.clauseId ?? 0;
                setPageIdx(nextP);
                stateRef.current.currentLine = 0;
                stateRef.current.currentClauseId = firstCid;
                stateRef.current.reachedRightZone = false;
                stateRef.current.maxLineX = 0;
                setActiveClauseId(firstCid);
              }}
              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700"
            >
              上一页
            </button>
            <span className="px-1.5 text-slate-400 font-mono">
              {pageIdx + 1}/{Math.max(1, pages.length)}
            </span>
            <button
              onClick={() => {
                const nextP = Math.min(pages.length - 1, pageIdx + 1);
                const firstCid = pages[nextP]?.[0]?.segments?.[0]?.clauseId ?? 0;
                setPageIdx(nextP);
                stateRef.current.currentLine = 0;
                stateRef.current.currentClauseId = firstCid;
                stateRef.current.reachedRightZone = false;
                stateRef.current.maxLineX = 0;
                setActiveClauseId(firstCid);
              }}
              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700"
            >
              下一页
            </button>
          </div>
        </div>
      </header>

      {/* ==================== 阅读器主视口 (无行高光，跨行短句整体联动高光) ==================== */}
      <main className="flex-1 flex flex-col items-center justify-center px-24 py-4">
        <div
          ref={readerBoxRef}
          className="w-full max-w-4xl bg-slate-900/70 border border-slate-800/90 rounded-xl py-6 px-8 relative shadow-2xl"
          style={{ minHeight: ROWS_PER_PAGE * LINE_HEIGHT_PX + 48 }}
        >
          {currentLines.map((line, idx) => {
            return (
              <div
                key={idx}
                style={{ height: LINE_HEIGHT_PX }}
                className="relative flex items-center px-3"
              >
                <div className="flex items-center min-w-0 overflow-hidden w-full">
                  <span className="w-7 text-xs font-mono text-slate-600 select-none shrink-0">
                    {String(idx + 1).padStart(2, "0")}
                  </span>
                  <div className="flex items-center whitespace-pre" style={{ font: FONT_SPEC }}>
                    {line.segments.map((seg, sIdx) => {
                      const isClauseHighlighted = seg.clauseId === activeClauseId;
                      return (
                        <React.Fragment key={sIdx}>
                          <span
                            onClick={() => {
                              stateRef.current.currentLine = idx;
                              stateRef.current.currentClauseId = seg.clauseId;
                              stateRef.current.lineEnterTime = performance.now();
                              stateRef.current.reachedRightZone = false;
                              stateRef.current.maxLineX = 0;
                              setActiveClauseId(seg.clauseId);
                            }}
                            className={`transition-colors duration-100 rounded px-0.5 py-0.5 border-b cursor-pointer ${
                              isClauseHighlighted
                                ? "bg-indigo-500/30 text-white border-indigo-400 shadow-[0_0_10px_rgba(99,102,241,0.25)]"
                                : "bg-transparent text-slate-400 border-transparent hover:text-slate-300"
                            }`}
                          >
                            {seg.text}
                          </span>
                          {seg.isClauseEnd && (
                            <span
                              style={{ width: CLAUSE_GAP_PX }}
                              className="inline-flex items-center justify-center text-[11px] text-indigo-400/50 select-none"
                              title="完整语义短句边界"
                            >
                              ·
                            </span>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </div>
                </div>

                {/* 框外右侧可隐藏的「x短句 | y词 | z%」状态指示标签 */}
                {showRowMeta && (
                  <span
                    className={`absolute left-full ml-3 whitespace-nowrap text-[10px] font-mono px-2 py-0.5 rounded border pointer-events-none ${
                      line.isParaEnd
                        ? "bg-slate-900/90 border-amber-500/30 text-amber-400/90"
                        : "bg-slate-900/70 border-slate-800 text-sky-400/80"
                    }`}
                  >
                    {line.clauseCount}短句 · {line.wordCount}词 | {Math.round(line.widthRatio * 100)}%
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </main>

      {/* 实时眼动平滑跟随光标 & 原始垂直预测参考点 */}
      {isCalibrated && !isCalibrating && (
        <div className="pointer-events-none fixed inset-0 z-30">
          <div
            className="w-5 h-5 -ml-2.5 -mt-2.5 rounded-full bg-indigo-400/80 shadow-[0_0_16px_rgba(99,102,241,0.9)] transition-transform duration-75"
            style={{ transform: `translate3d(${gazePoint.x}px, ${gazePoint.y}px, 0)` }}
          />
          <div
            className="w-2 h-2 -ml-1 -mt-1 rounded-full bg-rose-400/60"
            style={{ transform: `translate3d(${gazePoint.x}px, ${gazePoint.rawY}px, 0)` }}
          />
        </div>
      )}

      {/* 9点全屏校准遮罩 */}
      {isCalibrating && (
        <div className="fixed inset-0 z-50 bg-slate-950/95 flex flex-col items-center justify-center">
          <p className="text-slate-300 text-lg mb-2">
            请保持自然阅读坐姿，<strong>注视并点击</strong>高亮圆点（{calibStep + 1} / 9）
          </p>
          <p className="text-slate-500 text-sm">
            点击后请保持视线停留在该点约 0.5 秒以采集头眼耦合特征
          </p>
          {CALIBRATION_POINTS.map(([rx, ry], idx) => {
            if (idx !== calibStep) return null;
            const px = typeof window !== "undefined" ? Math.round(rx * window.innerWidth) : 0;
            const py = typeof window !== "undefined" ? Math.round(ry * window.innerHeight) : 0;
            return (
              <button
                key={idx}
                onClick={() => handleCalibPointClick(px, py)}
                style={{ left: `${rx * 100}%`, top: `${ry * 100}%` }}
                className="fixed -ml-6 -mt-6 w-12 h-12 rounded-full bg-indigo-500/30 border-2 border-indigo-400 flex items-center justify-center animate-pulse cursor-crosshair"
              >
                <span className="w-3.5 h-3.5 rounded-full bg-amber-400" />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}