"use client";

import React, { useEffect, useRef, useState, useCallback } from "react";
import { FaceLandmarker, FilesetResolver, FaceLandmarkerResult } from "@mediapipe/tasks-vision";

// ==================== 0. Intercept WASM INFO Logs ====================
if (typeof window !== "undefined" && !(window as unknown as { __mpErrFiltered?: boolean }).__mpErrFiltered) {
  (window as unknown as { __mpErrFiltered?: boolean }).__mpErrFiltered = true;
  const origError = window.console.error.bind(window.console);
  window.console.error = (...args: unknown[]) => {
    const msg = args.map((a) => (typeof a === "string" ? a : "")).join(" ");
    if (
      msg.includes("INFO:") ||
      msg.includes("WARNING:") ||
      msg.includes("XNNPACK") ||
      msg.includes("Created TensorFlow Lite") ||
      msg.includes("gl_context")
    ) {
      return;
    }
    origError(...args);
  };
}

// ==================== 1. OneEuroFilter, Standardized Ridge Regression & Heatmap LUT ====================

class OneEuroFilter {
  private xPrev: number | null = null;
  private dxPrev = 0;
  private tPrev: number | null = null;

  constructor(private minCutoff = 1.05, private beta = 0.022, private dCutoff = 1.0) {}

  private alpha(cutoff: number, dt: number): number {
    const tau = 1.0 / (2 * Math.PI * cutoff);
    return 1.0 / (1.0 + tau / dt);
  }

  filter(x: number, tMs: number): number {
    if (!Number.isFinite(x)) return this.xPrev ?? 0;
    if (this.tPrev === null || this.xPrev === null) {
      this.xPrev = x;
      this.tPrev = tMs;
      return x;
    }
    const rawDt = (tMs - this.tPrev) / 1000;
    this.tPrev = tMs;

    // Suppress derivative spike after a blink or pause gap (>85ms)
    if (rawDt > 0.085) {
      const alphaRecovery = this.alpha(this.minCutoff, 0.033);
      const filtered = this.xPrev + alphaRecovery * (x - this.xPrev);
      this.dxPrev = 0;
      this.xPrev = filtered;
      return filtered;
    }

    const dt = Math.max(rawDt, 1e-4);
    const dx = (x - this.xPrev) / dt;
    const edx = this.dxPrev + this.alpha(this.dCutoff, dt) * (dx - this.dxPrev);
    this.dxPrev = edx;

    const cutoff = this.minCutoff + this.beta * Math.abs(edx);
    const filtered = this.xPrev + this.alpha(cutoff, dt) * (x - this.xPrev);
    this.xPrev = filtered;
    return filtered;
  }
}

// Z-score standardized Ridge Regression with NaN/singularity defense
function solveRidgeRegression(X: number[][], Y: number[][], lambda = 0.6): number[][] {
  const n = X.length;
  const d = X[0]?.length ?? 15;
  const outDim = Y[0]?.length ?? 2;

  if (n < 3) {
    return Array.from({ length: d }, (_, i) =>
      i === 0 ? [window.innerWidth / 2, window.innerHeight / 2] : [0, 0]
    );
  }

  const mean = new Array(d).fill(0);
  const std = new Array(d).fill(1);

  for (let j = 1; j < d; j++) {
    let sum = 0;
    for (let k = 0; k < n; k++) sum += X[k][j];
    mean[j] = sum / n;

    let varSum = 0;
    for (let k = 0; k < n; k++) {
      const diff = X[k][j] - mean[j];
      varSum += diff * diff;
    }
    std[j] = Math.sqrt(varSum / n + 1e-8);
  }

  const Xn = X.map((row) =>
    row.map((val, j) => (j === 0 ? 1 : (val - mean[j]) / std[j]))
  );

  const A = Array.from({ length: d }, (_, i) =>
    Array.from({ length: d }, (_, j) => {
      let sum = 0;
      for (let k = 0; k < n; k++) sum += Xn[k][i] * Xn[k][j];
      if (i === j) sum += i === 0 ? 1e-7 : lambda;
      return sum;
    })
  );

  const B = Array.from({ length: d }, (_, i) =>
    Array.from({ length: outDim }, (_, j) => {
      let sum = 0;
      for (let k = 0; k < n; k++) sum += Xn[k][i] * Y[k][j];
      return sum;
    })
  );

  const aug = A.map((row, i) => [...row, ...B[i]]);
  for (let col = 0; col < d; col++) {
    let pivot = col;
    for (let row = col + 1; row < d; row++) {
      if (Math.abs(aug[row][col]) > Math.abs(aug[pivot][col])) pivot = row;
    }
    [aug[col], aug[pivot]] = [aug[pivot], aug[col]];

    const div = aug[col][col] || 1e-8;
    for (let j = col; j < d + outDim; j++) aug[col][j] /= div;

    for (let row = 0; row < d; row++) {
      if (row !== col) {
        const factor = aug[row][col];
        for (let j = col; j < d + outDim; j++) aug[row][j] -= factor * aug[col][j];
      }
    }
  }

  const Wn = aug.map((row) => row.slice(d));
  const W = Array.from({ length: d }, () => new Array(outDim).fill(0));

  for (let m = 0; m < outDim; m++) {
    let interceptShift = 0;
    for (let j = 1; j < d; j++) {
      const wVal = Wn[j][m] / std[j];
      W[j][m] = Number.isFinite(wVal) ? wVal : 0;
      interceptShift += W[j][m] * mean[j];
    }
    const w0 = Wn[0][m] - interceptShift;
    W[0][m] = Number.isFinite(w0) ? w0 : m === 0 ? window.innerWidth / 2 : window.innerHeight / 2;
  }

  return W;
}

const HEAT_W = 240;
const HEAT_H = 135;
const HEATMAP_LUT = (() => {
  const lut = new Uint32Array(256);
  for (let v = 0; v < 256; v++) {
    if (v < 3) {
      lut[v] = 0;
      continue;
    }
    let r = 0,
      g = 0,
      b = 0;
    if (v < 64) {
      b = 255;
      g = v * 4;
    } else if (v < 128) {
      g = 255;
      b = 255 - (v - 64) * 4;
    } else if (v < 192) {
      g = 255;
      r = (v - 128) * 4;
    } else {
      r = 255;
      g = Math.max(0, 255 - (v - 192) * 4);
    }
    const a = Math.min(215, Math.round(v * 0.92));
    lut[v] = (a << 24) | (b << 16) | (g << 8) | r;
  }
  return lut;
})();

// ==================== 2. Gaze & 3D Head Pose Extraction + Topology Mesh ====================

function projectEyeLocal(lm: { x: number; y: number }[], outer: number, inner: number, iris: number) {
  const dx = lm[inner].x - lm[outer].x;
  const dy = lm[inner].y - lm[outer].y;
  const len = Math.hypot(dx, dy) || 1e-5;
  const ux = dx / len;
  const uy = dy / len;
  const ix = lm[iris].x - lm[outer].x;
  const iy = lm[iris].y - lm[outer].y;
  return {
    u: (ix * ux + iy * uy) / len,
    v: (-ix * uy + iy * ux) / len,
  };
}

interface GazeTelemetry {
  features: number[];
  yawDeg: number;
  pitchDeg: number;
  rollDeg: number;
  blink: number;
  jawOpen: number;
  browDown: number;
  rU: number;
  rV: number;
  lU: number;
  lV: number;
  lookH: number;
  lookV: number;
}

function extractGazeTelemetry(res: FaceLandmarkerResult): GazeTelemetry | null {
  const lm = res.faceLandmarks?.[0];
  const bs = res.faceBlendshapes?.[0]?.categories;
  const mat = res.facialTransformationMatrixes?.[0]?.data;
  if (!lm || lm.length < 478 || !bs || !mat) return null;

  const getBs = (name: string) => bs.find((c) => c.categoryName === name)?.score ?? 0;
  const blink = Math.max(getBs("eyeBlinkLeft"), getBs("eyeBlinkRight"));
  const jawOpen = getBs("jawOpen");
  const browDown = Math.max(getBs("browDownLeft"), getBs("browDownRight"));

  const rEye = projectEyeLocal(lm, 33, 133, 468);
  const lEye = projectEyeLocal(lm, 362, 263, 473);

  const lookHoriz =
    getBs("eyeLookOutLeft") -
    getBs("eyeLookInLeft") +
    (getBs("eyeLookInRight") - getBs("eyeLookOutRight"));
  const lookVert =
    getBs("eyeLookDownLeft") +
    getBs("eyeLookDownRight") -
    (getBs("eyeLookUpLeft") + getBs("eyeLookUpRight"));

  const pitch = Math.asin(Math.max(-1, Math.min(1, -mat[6])));
  const yaw = Math.atan2(mat[2], mat[10]);
  const roll = Math.atan2(mat[4], mat[5]);
  const tx = mat[12] * 0.05;
  const ty = mat[13] * 0.05;
  const tz = (mat[14] + 50) * 0.02;

  const uMean = (rEye.u + lEye.u) * 0.5;
  const vMean = (rEye.v + lEye.v) * 0.5;
  return {
    features: [
      1,
      rEye.u,
      rEye.v,
      lEye.u,
      lEye.v,
      lookHoriz,
      lookVert,
      yaw,
      pitch,
      roll,
      tx,
      ty,
      tz,
      uMean * yaw,
      vMean * pitch,
    ],
    yawDeg: Math.round((yaw * 180) / Math.PI),
    pitchDeg: Math.round((pitch * 180) / Math.PI),
    rollDeg: Math.round((roll * 180) / Math.PI),
    blink,
    jawOpen,
    browDown,
    rU: rEye.u,
    rV: rEye.v,
    lU: lEye.u,
    lV: lEye.v,
    lookH: lookHoriz,
    lookV: lookVert,
  };
}

const FACE_OVAL = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109, 10];
const RIGHT_EYE_LOOP = [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246, 33];
const LEFT_EYE_LOOP = [362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398, 362];
const RIGHT_EYEBROW = [46, 53, 52, 65, 55, 70, 63, 105, 66, 107];
const LEFT_EYEBROW = [276, 283, 282, 295, 285, 300, 293, 334, 296, 336];
const NOSE_BRIDGE = [168, 6, 197, 195, 5, 4, 1];
const LIPS_OUTER = [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185, 61];

function drawFaceAndEyeMesh(
  canvas: HTMLCanvasElement,
  res: FaceLandmarkerResult,
  tel: GazeTelemetry | null,
  video: HTMLVideoElement,
  showVideoBg: boolean,
  isNight: boolean
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const W = canvas.width;
  const H = canvas.height;
  ctx.clearRect(0, 0, W, H);

  ctx.fillStyle = isNight ? "#181a1e" : "#f5f3ef";
  ctx.fillRect(0, 0, W, H);

  if (showVideoBg) {
    ctx.save();
    ctx.translate(W, 0);
    ctx.scale(-1, 1);
    ctx.globalAlpha = isNight ? 0.35 : 0.28;
    ctx.drawImage(video, 0, 0, W, H);
    ctx.restore();
  } else {
    ctx.strokeStyle = isNight ? "rgba(120, 113, 108, 0.16)" : "rgba(168, 162, 158, 0.25)";
    ctx.lineWidth = 1;
    for (let x = 0; x < W; x += 24) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, H);
      ctx.stroke();
    }
    for (let y = 0; y < H; y += 24) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(W, y);
      ctx.stroke();
    }
  }

  const lm = res.faceLandmarks?.[0];
  if (!lm) {
    ctx.fillStyle = isNight ? "rgba(28, 25, 23, 0.85)" : "rgba(255, 255, 255, 0.88)";
    ctx.fillRect(10, 10, W - 20, 34);
    ctx.strokeStyle = isNight ? "rgba(87, 83, 78, 0.6)" : "rgba(214, 211, 209, 0.9)";
    ctx.strokeRect(10, 10, W - 20, 34);
    ctx.fillStyle = "#e11d48";
    ctx.font = "11px system-ui, sans-serif";
    ctx.fillText("No face detected - please face camera", 18, 31);
    return;
  }

  const px = (idx: number) => (1 - lm[idx].x) * W;
  const py = (idx: number) => lm[idx].y * H;

  const strokePath = (indices: number[], color: string, width = 1.2) => {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.beginPath();
    indices.forEach((id, i) => {
      if (i === 0) ctx.moveTo(px(id), py(id));
      else ctx.lineTo(px(id), py(id));
    });
    ctx.stroke();
  };

  ctx.fillStyle = isNight ? "rgba(168, 162, 158, 0.35)" : "rgba(120, 113, 108, 0.4)";
  for (let i = 0; i < 468; i += 2) {
    ctx.fillRect(px(i) - 0.7, py(i) - 0.7, 1.4, 1.4);
  }

  strokePath(FACE_OVAL, isNight ? "rgba(168, 162, 158, 0.6)" : "rgba(87, 83, 78, 0.55)", 1.2);
  strokePath(RIGHT_EYEBROW, isNight ? "rgba(214, 211, 209, 0.65)" : "rgba(68, 64, 60, 0.65)", 1.2);
  strokePath(LEFT_EYEBROW, isNight ? "rgba(214, 211, 209, 0.65)" : "rgba(68, 64, 60, 0.65)", 1.2);
  strokePath(NOSE_BRIDGE, "rgba(14, 116, 144, 0.65)", 1.3);
  strokePath(
    LIPS_OUTER,
    tel && tel.jawOpen > 0.32
      ? "#d97706"
      : isNight
      ? "rgba(168, 162, 158, 0.55)"
      : "rgba(120, 113, 108, 0.6)",
    1.3
  );

  strokePath(RIGHT_EYE_LOOP, "#0284c7", 1.4);
  strokePath(LEFT_EYE_LOOP, "#0284c7", 1.4);
  strokePath([33, 133], "rgba(14, 116, 144, 0.85)", 1.4);
  strokePath([362, 263], "rgba(14, 116, 144, 0.85)", 1.4);

  strokePath([469, 470, 471, 472, 469], "#d97706", 1.6);
  strokePath([474, 475, 476, 477, 474], "#d97706", 1.6);

  [468, 473].forEach((irisIdx) => {
    const cx = px(irisIdx);
    const cy = py(irisIdx);
    ctx.fillStyle = "#d97706";
    ctx.beginPath();
    ctx.arc(cx, cy, 2.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx - 6, cy);
    ctx.lineTo(cx + 6, cy);
    ctx.moveTo(cx, cy - 6);
    ctx.lineTo(cx, cy + 6);
    ctx.stroke();
  });

  if (tel) {
    const noseX = px(168);
    const noseY = py(168);
    const headEndX = noseX - Math.sin((tel.yawDeg * Math.PI) / 180) * 55;
    const headEndY = noseY + Math.sin((tel.pitchDeg * Math.PI) / 180) * 55;
    ctx.strokeStyle = "#e11d48";
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(noseX, noseY);
    ctx.lineTo(headEndX, headEndY);
    ctx.stroke();

    const rayDx = -tel.lookH * 42 - Math.sin((tel.yawDeg * Math.PI) / 180) * 35;
    const rayDy = tel.lookV * 48 + Math.sin((tel.pitchDeg * Math.PI) / 180) * 35;
    ctx.strokeStyle = "#059669";
    ctx.lineWidth = 1.8;
    [468, 473].forEach((id) => {
      ctx.beginPath();
      ctx.moveTo(px(id), py(id));
      ctx.lineTo(px(id) + rayDx, py(id) + rayDy);
      ctx.stroke();
    });

    ctx.fillStyle = isNight ? "rgba(28, 25, 23, 0.84)" : "rgba(255, 255, 255, 0.86)";
    ctx.fillRect(8, 8, 218, 66);
    ctx.strokeStyle = isNight ? "rgba(87, 83, 78, 0.65)" : "rgba(214, 211, 209, 0.9)";
    ctx.lineWidth = 1;
    ctx.strokeRect(8, 8, 218, 66);

    ctx.fillStyle = isNight ? "#e7e5e4" : "#292524";
    ctx.font = "11px monospace";
    ctx.fillText(`Head Y/P/R: ${tel.yawDeg}° / ${tel.pitchDeg}° / ${tel.rollDeg}°`, 14, 23);
    ctx.fillStyle = isNight ? "#38bdf8" : "#0369a1";
    ctx.fillText(`Iris U/V  : ${tel.rU.toFixed(2)}, ${tel.rV.toFixed(2)}`, 14, 37);
    ctx.fillStyle = tel.blink > 0.45 ? "#e11d48" : "#059669";
    ctx.fillText(`Blink     : ${tel.blink.toFixed(2)} ${tel.blink > 0.45 ? "[Filtered]" : "[Stable]"}`, 14, 51);
    ctx.fillStyle = tel.jawOpen > 0.32 ? "#d97706" : isNight ? "#a8a29e" : "#78716c";
    ctx.fillText(`Jaw Open  : ${tel.jawOpen.toFixed(2)} ${tel.jawOpen > 0.32 ? "[Menu Open]" : ""}`, 14, 65);
  }
}

// ==================== 3. Unified Toggle Switch & Floating Window ====================

function ToggleSwitch({
  checked,
  onChange,
  title,
}: {
  checked: boolean;
  onChange: () => void;
  title?: string;
}) {
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onChange();
      }}
      aria-pressed={checked}
      title={title}
      className={`w-9 h-5 rounded-full p-0.5 flex items-center shrink-0 transition-colors ${
        checked ? "bg-stone-900 justify-end" : "bg-stone-300 justify-start"
      }`}
    >
      <span className="w-4 h-4 rounded-full bg-white shadow" />
    </button>
  );
}

interface WinState {
  visible: boolean;
  x: number;
  y: number;
  w: number;
  h: number;
}

function FloatingWindow({
  title,
  winState,
  setWinState,
  isNight,
  minW = 240,
  minH = 160,
  headerExtra,
  children,
}: {
  title: string;
  winState: WinState;
  setWinState: React.Dispatch<React.SetStateAction<WinState>>;
  isNight: boolean;
  minW?: number;
  minH?: number;
  headerExtra?: React.ReactNode;
  children: React.ReactNode;
}) {
  const startDrag = (e: React.PointerEvent) => {
    e.preventDefault();
    const startX = e.clientX - winState.x;
    const startY = e.clientY - winState.y;
    const onMove = (ev: PointerEvent) => {
      setWinState((prev) => ({
        ...prev,
        x: Math.max(0, Math.min(window.innerWidth - 80, ev.clientX - startX)),
        y: Math.max(0, Math.min(window.innerHeight - 40, ev.clientY - startY)),
      }));
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };

  const startResize = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startY = e.clientY;
    const origW = winState.w;
    const origH = winState.h;
    const onMove = (ev: PointerEvent) => {
      setWinState((prev) => ({
        ...prev,
        w: Math.max(minW, origW + (ev.clientX - startX)),
        h: Math.max(minH, origH + (ev.clientY - startY)),
      }));
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };

  const shellTheme = isNight
    ? "bg-[#1c1e22]/95 border-stone-700/80 text-stone-100 shadow-2xl"
    : "bg-white/95 border-stone-300/85 text-stone-800 shadow-xl";

  const headerTheme = isNight
    ? "bg-stone-900/90 border-stone-800 text-stone-200"
    : "bg-[#f5f3ef]/90 border-stone-200/90 text-stone-800";

  return (
    <div
      style={
        winState.visible
          ? { left: winState.x, top: winState.y, width: winState.w, height: winState.h }
          : { left: -9999, top: -9999, width: 1, height: 1, opacity: 0, pointerEvents: "none" }
      }
      className={`fixed z-40 border rounded-2xl flex flex-col overflow-hidden backdrop-blur-md transition-colors ${shellTheme}`}
    >
      <div
        onPointerDown={startDrag}
        className={`h-8 px-3 border-b flex items-center justify-between cursor-move select-none shrink-0 ${headerTheme}`}
      >
        <span className="text-xs font-serif font-medium truncate">{title}</span>
        <div className="flex items-center gap-1.5" onPointerDown={(e) => e.stopPropagation()}>
          {headerExtra}
          <button
            type="button"
            onClick={() => setWinState((p) => ({ ...p, visible: false }))}
            className="text-stone-400 hover:text-rose-500 px-1 text-xs transition"
            title="Close Window"
          >
            ✕
          </button>
        </div>
      </div>

      <div className="flex-1 relative min-h-0 overflow-hidden p-1.5">{children}</div>

      <div
        onPointerDown={startResize}
        className="w-4 h-4 absolute right-0.5 bottom-0.5 cursor-nwse-resize z-20 flex items-end justify-end p-0.5 text-stone-400 hover:text-stone-700"
        title="Resize Window"
      >
        <svg viewBox="0 0 10 10" className="w-2.5 h-2.5 fill-current">
          <path d="M9 1v8H1L9 1z" />
        </svg>
      </div>
    </div>
  );
}

// ==================== 4. Single-Row Full-Sentence Segmentation Engine (No Cross-Row Split Selection) ====================

export interface ClauseSegment {
  text: string;
  clauseId: number;     // Strictly scoped within a single row so upper & lower rows are never selected simultaneously
  startX: number;
  endX: number;
  isClauseEnd: boolean;
}

export interface VisualLine {
  segments: ClauseSegment[];
  clauseCount: number;
  wordCount: number;
  charCount: number;
  widthRatio: number;
  isParaStart: boolean;
  isParaEnd: boolean;
}

const ROWS_PER_PAGE = 15;
const CLAUSE_GAP_PX = 6;

const CALIBRATION_POINTS = [
  [0.12, 0.14],
  [0.5, 0.14],
  [0.88, 0.14],
  [0.12, 0.5],
  [0.5, 0.5],
  [0.88, 0.5],
  [0.12, 0.86],
  [0.5, 0.86],
  [0.88, 0.86],
];

function countEffectiveWordsAndChars(text: string): { words: number; chars: number } {
  const cjkMatches = text.match(/[\u4e00-\u9fa5]/g) || [];
  const engMatches =
    text
      .replace(/[\u4e00-\u9fa5]/g, " ")
      .match(/[A-Za-z0-9]+(?:['’-][A-Za-z0-9]+)*/g) || [];
  const words = engMatches.length + cjkMatches.length / 1.8;
  const chars = text.replace(/\s+/g, "").length;
  return { words: Math.max(1, Number(words.toFixed(1))), chars: Math.max(1, chars) };
}

function joinTokens(a: string, b: string): string {
  if (!a) return b;
  if (!b) return a;
  if (/[—-]$/.test(a) || /^[—-]/.test(b)) return `${a}${b}`;
  const needSpace =
    /[A-Za-z0-9.,;:!?'"”’)\]]$/.test(a) && /^[A-Za-z0-9"“'‘(\[]/.test(b);
  return needSpace ? `${a} ${b}` : `${a}${b}`;
}

function tokenizeWithAtomicProtection(para: string): string[] {
  const ATOMIC_SCAN_REGEX =
    /([\u4e00-\u9fa5A-Za-z0-9]{0,4}(?:“[^”\r\n]{1,16}”|「[^」\r\n]{1,16}」|『[^』\r\n]{1,16}』)[\u4e00-\u9fa5A-Za-z0-9]{0,6}[，。！？；：、,.!?;:—]*|\b(?:Mr|Mrs|Ms|Dr|Capt|St|Rev|Gov)\.\s+[A-Z][A-Za-z'-]+[,.;:!?—]*|(?:\b(?:the|a|an)\s+)?"[A-Z][A-Za-z\s-]{1,18}"[,.;:!?—]*|["“'‘(\[]*[A-Za-z0-9]+(?:\.[A-Za-z0-9]+)*['’-]?[A-Za-z0-9]*[,.;:!?'"”’)\]]*(?:—|--)?|[\u4e00-\u9fa5][，。！？；：、”’）》】—…]*|[^\s])/g;

  return para.match(ATOMIC_SCAN_REGEX) || [para];
}

interface SemanticClause {
  tokens: string[];
  text: string;
  isHardStop: boolean;
}

// Split only on full sentence stops (.!?。！？…) so sentences are never chopped into short comma phrases
function buildFullSentences(tokens: string[]): SemanticClause[] {
  const sentences: SemanticClause[] = [];
  let curTokens: string[] = [];
  let curText = "";

  for (let i = 0; i < tokens.length; i++) {
    const tok = tokens[i];
    curTokens.push(tok);
    curText = joinTokens(curText, tok);

    const isAbbr = /\b(Mr|Mrs|Ms|Dr|Capt|St|Rev|Gov)\.$/i.test(tok);
    const isSentenceEnd = !isAbbr && /([.!?。！？…]+['"”’)\]]*)$/.test(tok);

    if (isSentenceEnd) {
      sentences.push({ tokens: curTokens, text: curText, isHardStop: true });
      curTokens = [];
      curText = "";
    }
  }

  if (curTokens.length > 0) {
    sentences.push({ tokens: curTokens, text: curText, isHardStop: true });
  }

  return sentences;
}

// Flow into continuous full rows while keeping each selectable sentence unit strictly inside a single row
function flowSentencesIntoSingleRowUnits(
  sentences: SemanticClause[],
  indentStr: string,
  measure: (s: string) => number,
  maxTextWidth: number,
  startClauseId: number
): { lines: VisualLine[]; nextClauseId: number } {
  interface TaggedToken {
    text: string;
    isSentenceEnd: boolean;
  }

  const stream: TaggedToken[] = [];
  sentences.forEach((s, sIdx) => {
    s.tokens.forEach((tok, tIdx) => {
      const text = sIdx === 0 && tIdx === 0 ? indentStr + tok : tok;
      const isLast = tIdx === s.tokens.length - 1;
      stream.push({ text, isSentenceEnd: isLast });
    });
  });

  const rawRows: TaggedToken[][] = [];
  let curRow: TaggedToken[] = [];
  let curRowText = "";

  for (let i = 0; i < stream.length; i++) {
    const item = stream[i];
    const candidate = curRowText ? joinTokens(curRowText, item.text) : item.text;
    if (curRow.length > 0 && measure(candidate) > maxTextWidth) {
      rawRows.push(curRow);
      const cleanStart = item.text.trimStart();
      curRow = [{ ...item, text: cleanStart }];
      curRowText = cleanStart;
    } else {
      curRow.push(item);
      curRowText = candidate;
    }
  }
  if (curRow.length > 0) rawRows.push(curRow);

  const lines: VisualLine[] = [];
  let clauseIdCounter = startClauseId;
  const minFragPx = Math.min(110, maxTextWidth * 0.18);

  rawRows.forEach((rowTokens, rIdx) => {
    const groups: string[][] = [];
    let buf: string[] = [];
    rowTokens.forEach((t, idx) => {
      buf.push(t.text);
      if (t.isSentenceEnd || idx === rowTokens.length - 1) {
        groups.push(buf);
        buf = [];
      }
    });

    // Merge short wrapped row-start/row-end fragments (<3 words) into adjacent sentence on the same row
    const mergedGroups: string[] = [];
    for (let g = 0; g < groups.length; g++) {
      const gTokens = groups[g];
      const gText = gTokens.reduce((acc, tk) => joinTokens(acc, tk), "");
      const isCjk = /[\u4e00-\u9fa5]/.test(gText);
      const isShortFrag =
        (isCjk ? gText.length < 5 : gTokens.length < 3) || measure(gText) < minFragPx;

      if (isShortFrag && g < groups.length - 1) {
        groups[g + 1] = [...gTokens, ...groups[g + 1]];
      } else if (isShortFrag && mergedGroups.length > 0) {
        mergedGroups[mergedGroups.length - 1] = joinTokens(
          mergedGroups[mergedGroups.length - 1],
          gText
        );
      } else {
        mergedGroups.push(gText);
      }
    }

    let curX = 0;
    const segments: ClauseSegment[] = mergedGroups.map((segText, sIdx) => {
      const startX = sIdx === 0 ? 0 : curX + CLAUSE_GAP_PX;
      const w = measure(segText);
      curX = startX + w;
      return {
        text: segText,
        clauseId: clauseIdCounter++,
        startX,
        endX: curX,
        isClauseEnd: sIdx < mergedGroups.length - 1,
      };
    });

    const fullRowText = segments.map((s) => s.text).join(" ");
    const { words, chars } = countEffectiveWordsAndChars(fullRowText);
    lines.push({
      segments,
      clauseCount: segments.length,
      wordCount: words,
      charCount: chars,
      widthRatio: Math.min(1, Math.max(0.12, curX / maxTextWidth)),
      isParaStart: rIdx === 0,
      isParaEnd: rIdx === rawRows.length - 1,
    });
  });

  return { lines, nextClauseId: clauseIdCounter };
}

function packParagraphIntoVisualLines(
  para: string,
  ctx: CanvasRenderingContext2D,
  fontSpec: string,
  maxTextWidth: number,
  startClauseId = 0
): { lines: VisualLine[]; nextClauseId: number } {
  ctx.font = fontSpec;
  const measure = (s: string) => ctx.measureText(s).width;
  const indentStr = /^[\u4e00-\u9fa5“「『]/.test(para) ? "  " : "";
  const tokens = tokenizeWithAtomicProtection(para);
  const sentences = buildFullSentences(tokens);
  return flowSentencesIntoSingleRowUnits(sentences, indentStr, measure, maxTextWidth, startClauseId);
}

// ==================== 5. Preset English Book Chapters ====================

interface ChapterDoc {
  title: string;
  content: string;
}

const BOOK_CHAPTERS: ChapterDoc[] = [
  {
    title: "Why not chase each word",
    content: `Following each word chops the page into scraps. You end up watching the box as well as the sentence, while the thought you wanted to follow quietly slips into the background of the page. The region of interest is larger than a word on purpose. A little room around the sentence allows the eyes to wander naturally while the meaning stays connected to the paragraph around it. If the gaze stays on the same clause, the page adds a quiet edge. The marker remains gentle enough to notice without asking the reader to choose between the sentence and the guide. A softer margin gives the eye a place to pause before the next sentence. Small moments of rest can make a long passage feel less crowded without changing a single word of the original text. When attention drifts, the guide waits instead of pulling the page away. Returning to the passage should feel like finding a familiar place rather than starting the entire paragraph again. A small change in contrast can make a familiar paragraph easier to enter. The surrounding words remain visible so that the reader can move backward or forward without losing the thread. The reading window follows the rhythm of a thought rather than the length of a line. Some ideas arrive quickly, while others need a little more room before the next sentence begins to unfold. Longer pauses leave more space around a passage without hiding its context. The page remains steady while the reader takes time to connect a detail with something mentioned several lines earlier. A quiet marker returns to the last sentence that held your attention. It offers a useful starting point without pretending that every change in direction means the reader has lost their place. The guide stays still while you look back at a detail in the previous paragraph. Reading often moves in small loops, and the layout should leave enough room for those loops to happen naturally. A wider focus area makes room for peripheral words and natural eye movement. The current sentence can stand apart while the rest of the paragraph continues to provide a useful sense of scale. Subtle cues help the current passage stand out without turning it into a spotlight. The best guide is sometimes the one that becomes almost invisible once the words begin to hold your attention. The page keeps its original shape even when the reading guide changes position. Familiar spacing and stable edges help the reader remember where an idea appeared before they began to look for it. A steady reading pace matters more than moving through every word at the same speed. The guide makes space for quick observations, careful explanations, and the occasional sentence that asks to be read twice. When a paragraph ends, the guide leaves a little space before the next beginning. This small pause separates one thought from another without adding a new instruction or interrupting the flow.`,
  },
  {
    title: "When you look back (Secret Garden Ch.1)",
    content: `When Mary Lennox was sent to Misselthwaite Manor to live with her uncle, everybody said she was the most disagreeable-looking child ever seen. It was true, too. She had a little thin face and a little thin body, thin light hair and a sour expression. Her hair was yellow, and her face was yellow because she had been born in India and had always been ill in one way or another. Her father had held a position under the English Government and had always been busy and ill himself, and her mother had been a great beauty who cared only to go to parties and amuse herself with gay people. She had not wanted a little daughter at all, and when Mary was born she handed her over to the care of an Ayah, who was made to understand that if she wished to please the "Mem Sahib" she must keep the child out of sight as much as possible. So when she was a sickly, fretful, ugly little baby she was kept out of the way, and when she became a sickly, fretful, toddling thing she was kept out of the way also. She never remembered seeing familiarly anything but the dark faces of her Ayah and the other native servants, and as they always obeyed her and gave her her own way in everything, because the "Mem Sahib" would be angry if she was disturbed by her crying, by the time she was six years old she was as tyrannical and selfish a little pig as ever lived. The young English governess who came to teach her to read and write disliked her so much that she gave up her place in three months, and when other governesses came to try to fill it they always went away in a shorter time than the first one. So if Mary had not chosen to really want to know how to read books she would never have learned her letters at all.
One frightfully hot morning, when she was about nine years old, she awakened feeling very cross, and she became crosser still when she saw that the servant who stood by her bedside was not her own Ayah. "Why did you come?" she said to the strange woman. "I will not let you stay. Send my Ayah to me." The woman looked frightened, but she only stammered that the Ayah could not come and when Mary threw herself into a passion and beat and kicked her, she looked only more frightened and repeated that it was not possible for the Ayah to come to the "Missie Sahib."
There was something mysterious in the air that morning. Nothing was done in its regular order and several of the native servants seemed missing, while those whom Mary saw slunk or hurried about with ashy and terrified faces. But no one would tell her anything and her Ayah did not come. She was actually left alone as the morning went on, and at last she wandered out into the garden and began to play by herself under a tree near the veranda. She pretended that she was making a flower-bed, and she stuck big scarlet hibiscus blossoms into little heaps of earth, all the time growing more and more angry and muttering to herself the things she would say and the names she would call Saidie when she returned. "Pig! Pig! Daughter of Pigs!" she said, because to call a native a pig is the worst insult of all. She was grinding her teeth and saying this over and over again when she heard her mother come out on the veranda with some one. She was with a fair young man and they stood talking together in low strange voices. Mary knew the fair young man who looked like a boy. She had heard that he was a young officer who had just come from England. The child stared at him, but she stared most at her mother. She always did this when she had a chance to see her, because the "Mem Sahib"—Mary used to call her that oftener than anything else—was such a tall, slim, pretty person and wore such lovely clothes.`,
  },
  {
    title: "A quiet edge (Single-Row Sentence Focus)",
    content: `So when she was a sickly, fretful, ugly little baby she was kept out of the way, and when she became a sickly, fretful, toddling thing she was kept out of the way also. Every sentence flows naturally across the page without artificial line breaks, while gaze tracking highlights one contiguous sentence unit on a single row at a time so upper and lower rows never split into disconnected selection blocks.`,
  },
];

interface ToastNotification {
  title: string;
  detail?: string;
}

type RightCardId = "speed" | "sensing" | "settings" | "gesture" | "voice";

// ==================== 6. Next.js Main Page Component ====================

export default function SingleBookReadingInterface() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const rowsContainerRef = useRef<HTMLDivElement | null>(null);
  const meshCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const miniHeatmapCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const fullHeatmapCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [modelReady, setModelReady] = useState(false);
  const [cameraStatus, setCameraStatus] = useState<"Active" | "Initializing" | "Permission Denied" | "No-Camera Mode">("Initializing");
  const [noCameraMode, setNoCameraMode] = useState(false);
  const [fps, setFps] = useState(0);

  // Chapter, pagination & sentence focus state
  const [chapterIdx, setChapterIdx] = useState(0);
  const [customTitle, setCustomTitle] = useState<string | null>(null);
  const [rawText, setRawText] = useState(BOOK_CHAPTERS[0].content);
  const [pages, setPages] = useState<VisualLine[][]>([]);
  const [pageIdx, setPageIdx] = useState(0);
  const [activeLineIdx, setActiveLineIdx] = useState(0);
  const [activeClauseId, setActiveClauseId] = useState(0);

  // Mouth-open trigger state: controls selection box + quick action bar
  const [clauseMenuOpen, setClauseMenuOpen] = useState(false);
  const [mouthScore, setMouthScore] = useState(0);

  // Audio book (TTS) & Purchase state
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPurchased, setIsPurchased] = useState(false);
  const [buyModalOpen, setBuyModalOpen] = useState(false);

  // Bookmarks, persistent highlights (empty by default), underlines & notes
  const [highlightedClauses, setHighlightedClauses] = useState<Set<number>>(new Set());
  const [underlinedClauses, setUnderlinedClauses] = useState<Set<number>>(new Set());
  const [bookmarks, setBookmarks] = useState<{ id: number; text: string; page: number; line: number }[]>([
    { id: 5, text: "The surrounding words remain......", page: 0, line: 5 },
    { id: 13, text: "A steady reading pace matters......", page: 0, line: 12 },
  ]);
  const [notesList, setNotesList] = useState<string[]>([
    "[System] Gaze highlights contiguous sentence units on the active row; open your mouth (or double-click) at any time to summon the selection box and quick action bar.",
  ]);
  const [noteInputText, setNoteInputText] = useState("");
  const [notesModalOpen, setNotesModalOpen] = useState(false);

  // Bottom toast & dismissible banner
  const [statusToast, setStatusToast] = useState<ToastNotification | null>(null);
  const [dismissGuideBanner, setDismissGuideBanner] = useState(false);

  // Left & Right sidebars + Right sidebar draggable card order
  const [leftSidebarOpen, setLeftSidebarOpen] = useState(false);
  const [rightSidebarOpen, setRightSidebarOpen] = useState(false);
  const [rightCardOrder, setRightCardOrder] = useState<RightCardId[]>([
    "speed",
    "sensing",
    "settings",
    "gesture",
    "voice",
  ]);
  const [draggingCardId, setDraggingCardId] = useState<RightCardId | null>(null);
  const [dragCardOffsetY, setDragCardOffsetY] = useState(0);
  const rightCardsRefs = useRef<Record<RightCardId, HTMLDivElement | null>>({
    speed: null,
    sensing: null,
    settings: null,
    gesture: null,
    voice: null,
  });

  // Reading Settings: default 60% reading width, default hidden row stats badge
  const [fontFamily, setFontFamily] = useState<"Georgia" | "Inter" | "Literata">("Georgia");
  const [bgTheme, setBgTheme] = useState<"Paper" | "White" | "Night">("Paper");
  const [textColor, setTextColor] = useState<"Black" | "Gray" | "Soft">("Black");
  const [fontSize, setFontSize] = useState<number>(15);
  const [readingWidthPct, setReadingWidthPct] = useState<number>(60);
  const [lineSpacingRatio, setLineSpacingRatio] = useState<number>(2.35);
  const [showRowMeta, setShowRowMeta] = useState<boolean>(false);

  // 4 Unified Switches under Row Stats Badge
  const [menuShowBookmark, setMenuShowBookmark] = useState<boolean>(true);
  const [menuShowHighlight, setMenuShowHighlight] = useState<boolean>(true);
  const [menuShowNotes, setMenuShowNotes] = useState<boolean>(true);
  const [showBottomLeftBar, setShowBottomLeftBar] = useState<boolean>(true);

  // Bottom-left expandable vertical difficulty bar
  const [bottomLeftExpanded, setBottomLeftExpanded] = useState<boolean>(false);
  const [nextLineSlider, setNextLineSlider] = useState(65);
  const [prevLineSlider, setPrevLineSlider] = useState(30);
  const [skipLinesSlider, setSkipLinesSlider] = useState(30);

  // 3 Floating monitor windows: uniform initial width (w: 280)
  const [winVideo, setWinVideo] = useState<WinState>({ visible: false, x: 20, y: 68, w: 280, h: 210 });
  const [winMesh, setWinMesh] = useState<WinState>({ visible: false, x: 20, y: 290, w: 280, h: 225 });
  const [winHeatmap, setWinHeatmap] = useState<WinState>({ visible: false, x: 20, y: 527, w: 280, h: 215 });

  const [meshShowVideoBg, setMeshShowVideoBg] = useState(false);
  const [showPageHeatmap, setShowPageHeatmap] = useState(false);
  const [heatmapDecayMode, setHeatmapDecayMode] = useState(true);
  const [heatmapUseRawY, setHeatmapUseRawY] = useState(false);

  // Face assist, tracking quality, personal baseline, off-screen pause & resume confirmation
  const [faceAssist, setFaceAssist] = useState(true);
  const [trackingQuality, setTrackingQuality] = useState<"Good" | "Limited" | "Unavailable">("Unavailable");
  const [faceBaseline, setFaceBaseline] = useState<{ yaw: number; pitch: number; roll: number; jaw: number } | null>(null);
  const [continuousFaceState, setContinuousFaceState] = useState<string>("Stable");
  const [multimodalTriggerState, setMultimodalTriggerState] = useState<string>("Idle");
  const [readingSeconds, setReadingSeconds] = useState(0);
  const [isOffScreenPaused, setIsOffScreenPaused] = useState(false);
  const [showReturnConfirm, setShowReturnConfirm] = useState(false);

  // Gesture, spatial reticle, gaze cursor & Gestalt blur
  const [gestureControl, setGestureControl] = useState(true);
  const [showReticle, setShowReticle] = useState(true);
  const [showGazeCursor, setShowGazeCursor] = useState(true);
  const [bgBlur, setBgBlur] = useState(false);
  const [gestureBadgeText, setGestureBadgeText] = useState("Standby");

  // Voice control
  const [voiceMode, setVoiceMode] = useState<"Read" | "Notes">("Read");
  const [micActive, setMicActive] = useState(false);
  const [voiceLog, setVoiceLog] = useState("Say \"next line\" or \"open menu\"");
  const [voiceError, setVoiceError] = useState(false);

  // Reading speed & line latch telemetry
  const [readingStats, setReadingStats] = useState({
    wpm: 190,
    cpm: 950,
    lineProgressPct: 0,
    rightZoneLatched: false,
    currentLineIdx: 0,
  });

  // 9-point calibration state & sample progress
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [calibStep, setCalibStep] = useState(0);
  const [calibSampleProgress, setCalibSampleProgress] = useState(0);
  const [isCalibrated, setIsCalibrated] = useState(false);
  const [gazePoint, setGazePoint] = useState({
    x: 400,
    y: 300,
    snappedX: 400,
    snappedY: 300,
    rawY: 300,
    biasY: 0,
  });

  const lineHeightPx = Math.max(30, Math.round(fontSize * lineSpacingRatio));

  // Defensive interaction locks so adjusting sliders/UI never blocks mouth-open selection or causes gaze jumps
  const uiInteractingRef = useRef(false);
  const isDraggingSliderRef = useRef(false);

  useEffect(() => {
    const clearSliderDrag = () => {
      if (isDraggingSliderRef.current) {
        isDraggingSliderRef.current = false;
        uiInteractingRef.current = false;
      }
    };
    window.addEventListener("pointerup", clearSliderDrag);
    window.addEventListener("pointercancel", clearSliderDrag);
    return () => {
      window.removeEventListener("pointerup", clearSliderDrag);
      window.removeEventListener("pointercancel", clearSliderDrag);
    };
  }, []);

  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showToast = useCallback((title: string, detail?: string) => {
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    setStatusToast({ title, detail });
    toastTimerRef.current = setTimeout(() => {
      setStatusToast(null);
    }, 2600);
  }, []);

  const latestTelemetryRef = useRef<GazeTelemetry | null>(null);
  const faceBaselineRef = useRef<{ yaw: number; pitch: number; roll: number; jaw: number } | null>(null);
  useEffect(() => {
    faceBaselineRef.current = faceBaseline;
  }, [faceBaseline]);

  const uiConfigRef = useRef({
    meshShowVideoBg: false,
    heatmapDecayMode: true,
    heatmapUseRawY: false,
    gestureControl: true,
    faceAssist: true,
    noCameraMode: false,
    isOffScreenPaused: false,
    showReturnConfirm: false,
    clauseMenuOpen: false,
    isNight: false,
    nextSens: 65,
    prevSens: 30,
    skipSens: 30,
    lineHeightPx: 35,
  });
  useEffect(() => {
    uiConfigRef.current = {
      meshShowVideoBg,
      heatmapDecayMode,
      heatmapUseRawY,
      gestureControl,
      faceAssist,
      noCameraMode,
      isOffScreenPaused,
      showReturnConfirm,
      clauseMenuOpen,
      isNight: bgTheme === "Night",
      nextSens: nextLineSlider,
      prevSens: prevLineSlider,
      skipSens: skipLinesSlider,
      lineHeightPx,
    };
  }, [
    meshShowVideoBg,
    heatmapDecayMode,
    heatmapUseRawY,
    gestureControl,
    faceAssist,
    noCameraMode,
    isOffScreenPaused,
    showReturnConfirm,
    clauseMenuOpen,
    bgTheme,
    nextLineSlider,
    prevLineSlider,
    skipLinesSlider,
    lineHeightPx,
  ]);

  const layoutRef = useRef<{ pages: VisualLine[][]; pageIdx: number }>({ pages: [], pageIdx: 0 });
  useEffect(() => {
    layoutRef.current = { pages, pageIdx };
  }, [pages, pageIdx]);

  const heatGridRef = useRef<Float32Array>(new Float32Array(HEAT_W * HEAT_H));
  const offscreenHeatCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const weightsRef = useRef<number[][] | null>(null);
  const calibSamplesRef = useRef<{ X: number[][]; Y: number[][] }>({ X: [], Y: [] });
  const collectingPointRef = useRef<{
    targetX: number;
    targetY: number;
    settle: number;
    remaining: number;
    total: number;
  } | null>(null);

  const filterXRef = useRef(new OneEuroFilter(1.05, 0.022, 1.0));
  const filterYRef = useRef(new OneEuroFilter(0.75, 0.014, 1.0));

  const stateRef = useRef({
    currentLine: 0,
    currentClauseId: 0,
    biasY: 0,
    recentX: [] as number[],
    maxLineX: 0,
    reachedRightZone: false,
    lastSweepTime: 0,
    lineEnterTime: 0,
    forwardCandidateId: -1,
    forwardStartTime: 0,
    backwardCandidateId: -1,
    backwardStartTime: 0,
    verticalJumpStartTime: 0,
    wpmEma: 190,
    cpmEma: 950,
    mouthOpenStart: 0,
    lastMouthTrigger: 0,
    faceLostStart: 0,
    prevBlink: 0,
    blinkEma: 0.1,
    blinkCooldownUntil: 0,
    telQueue: [] as GazeTelemetry[],
  });

  // Reading session timer
  useEffect(() => {
    const timer = setInterval(() => {
      if (!isOffScreenPaused && !showReturnConfirm && !isCalibrating) {
        setReadingSeconds((s) => s + 1);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [isOffScreenPaused, showReturnConfirm, isCalibrating]);

  const getFontCssString = useCallback(
    (sizePx: number) => {
      const familyMap = {
        Georgia: `Georgia, Cambria, "Times New Roman", Times, serif`,
        Inter: `Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`,
        Literata: `"Literata", "Bookerly", Georgia, serif`,
      };
      return `${sizePx}px ${familyMap[fontFamily]}`;
    },
    [fontFamily]
  );

  // 1. Single-row sentence pagination engine (prevents split selection across upper & lower rows)
  const paginateText = useCallback(
    (text: string, containerWidth: number) => {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const fontSpec = getFontCssString(fontSize);
      ctx.font = fontSpec;

      const maxTextWidth = Math.max(containerWidth - 16, 280);
      const visualLines: VisualLine[] = [];
      let globalClauseId = 0;

      for (const para of text.split(/\r?\n/)) {
        const trimmed = para.trim();
        if (!trimmed) continue;
        const { lines, nextClauseId } = packParagraphIntoVisualLines(
          trimmed,
          ctx,
          fontSpec,
          maxTextWidth,
          globalClauseId
        );
        globalClauseId = nextClauseId;
        visualLines.push(...lines);
      }

      const paged: VisualLine[][] = [];
      for (let i = 0; i < visualLines.length; i += ROWS_PER_PAGE) {
        paged.push(visualLines.slice(i, i + ROWS_PER_PAGE));
      }

      const finalPages = paged.length
        ? paged
        : [
            [
              {
                segments: [{ text: "(Empty Document)", clauseId: 0, startX: 0, endX: 120, isClauseEnd: true }],
                clauseCount: 1,
                wordCount: 2,
                charCount: 14,
                widthRatio: 0.2,
                isParaStart: true,
                isParaEnd: true,
              },
            ],
          ];

      const firstClause = finalPages[0]?.[0]?.segments?.[0]?.clauseId ?? 0;
      setPages(finalPages);
      setPageIdx(0);
      setActiveLineIdx(0);
      setActiveClauseId(firstClause);
      setClauseMenuOpen(false);
      stateRef.current.currentLine = 0;
      stateRef.current.currentClauseId = firstClause;
      stateRef.current.reachedRightZone = false;
      stateRef.current.maxLineX = 0;
    },
    [fontSize, getFontCssString]
  );

  useEffect(() => {
    const baseViewportW = typeof window !== "undefined" ? window.innerWidth : 1280;
    const targetContainerWidth = Math.round((baseViewportW * readingWidthPct) / 100);
    paginateText(rawText, targetContainerWidth);
  }, [rawText, readingWidthPct, fontSize, fontFamily, paginateText]);

  // Defensive self-healing: ensure activeClauseId always belongs to activeLineIdx
  useEffect(() => {
    const row = pages[pageIdx]?.[activeLineIdx];
    if (!row || row.segments.length === 0) return;
    const existsInRow = row.segments.some((s) => s.clauseId === activeClauseId);
    if (!existsInRow) {
      const fallbackCid = row.segments[0].clauseId;
      stateRef.current.currentClauseId = fallbackCid;
      setActiveClauseId(fallbackCid);
    }
  }, [pages, pageIdx, activeLineIdx, activeClauseId]);

  // 2. Float heatmap accumulator & dual canvas renderer
  const updateAndRenderHeatmaps = useCallback(
    (gx: number, gy: number, rowsRect: DOMRect, curLine: number, lineCount: number, curLineHeight: number) => {
      const grid = heatGridRef.current;
      const { heatmapDecayMode: decayMode, isNight } = uiConfigRef.current;

      const decay = decayMode ? 0.965 : 0.999;
      for (let i = 0; i < grid.length; i++) {
        grid[i] *= decay;
      }

      const cx = Math.round((gx / Math.max(1, window.innerWidth)) * (HEAT_W - 1));
      const cy = Math.round((gy / Math.max(1, window.innerHeight)) * (HEAT_H - 1));
      const radius = 13;
      const r2 = radius * radius;

      const yMin = Math.max(0, cy - radius);
      const yMax = Math.min(HEAT_H - 1, cy + radius);
      const xMin = Math.max(0, cx - radius);
      const xMax = Math.min(HEAT_W - 1, cx + radius);

      for (let y = yMin; y <= yMax; y++) {
        const dy2 = (y - cy) * (y - cy);
        const rowOffset = y * HEAT_W;
        for (let x = xMin; x <= xMax; x++) {
          const d2 = (x - cx) * (x - cx) + dy2;
          if (d2 <= r2) {
            const boost = Math.exp(-d2 / (2 * 30)) * 22;
            grid[rowOffset + x] = Math.min(255, grid[rowOffset + x] + boost);
          }
        }
      }

      if (!offscreenHeatCanvasRef.current) {
        const c = document.createElement("canvas");
        c.width = HEAT_W;
        c.height = HEAT_H;
        offscreenHeatCanvasRef.current = c;
      }
      const offCtx = offscreenHeatCanvasRef.current.getContext("2d");
      if (!offCtx) return;

      const imgData = offCtx.createImageData(HEAT_W, HEAT_H);
      const buf32 = new Uint32Array(imgData.data.buffer);
      for (let i = 0; i < grid.length; i++) {
        buf32[i] = HEATMAP_LUT[Math.min(255, grid[i] | 0)];
      }
      offCtx.putImageData(imgData, 0, 0);

      if (fullHeatmapCanvasRef.current) {
        const fCtx = fullHeatmapCanvasRef.current.getContext("2d");
        if (fCtx) {
          fCtx.clearRect(0, 0, HEAT_W, HEAT_H);
          fCtx.drawImage(offscreenHeatCanvasRef.current, 0, 0, HEAT_W, HEAT_H);
        }
      }

      if (miniHeatmapCanvasRef.current) {
        const mCanvas = miniHeatmapCanvasRef.current;
        const mCtx = mCanvas.getContext("2d");
        if (mCtx) {
          const mw = mCanvas.width;
          const mh = mCanvas.height;
          mCtx.clearRect(0, 0, mw, mh);

          mCtx.fillStyle = isNight ? "#181a1e" : "#f5f3ef";
          mCtx.fillRect(0, 0, mw, mh);

          const scaleX = mw / Math.max(1, window.innerWidth);
          const scaleY = mh / Math.max(1, window.innerHeight);
          mCtx.strokeStyle = isNight ? "rgba(120, 113, 108, 0.45)" : "rgba(168, 162, 158, 0.65)";
          mCtx.strokeRect(
            rowsRect.left * scaleX,
            rowsRect.top * scaleY,
            rowsRect.width * scaleX,
            rowsRect.height * scaleY
          );

          for (let i = 0; i < lineCount; i++) {
            const ly = (rowsRect.top + i * curLineHeight) * scaleY;
            const lh = (curLineHeight - 4) * scaleY;
            mCtx.fillStyle =
              i === curLine
                ? isNight
                  ? "rgba(99, 102, 241, 0.35)"
                  : "rgba(28, 25, 23, 0.18)"
                : isNight
                ? "rgba(41, 37, 36, 0.65)"
                : "rgba(214, 211, 209, 0.55)";
            mCtx.fillRect(rowsRect.left * scaleX, ly, rowsRect.width * scaleX, lh);
          }

          mCtx.drawImage(offscreenHeatCanvasRef.current, 0, 0, mw, mh);

          const mx = gx * scaleX;
          const my = gy * scaleY;
          mCtx.strokeStyle = isNight ? "#ffffff" : "#1c1917";
          mCtx.lineWidth = 1.4;
          mCtx.beginPath();
          mCtx.arc(mx, my, 4, 0, Math.PI * 2);
          mCtx.stroke();
        }
      }
    },
    []
  );

  // 3. Camera & MediaPipe FaceLandmarker 30FPS Tracking Loop
  useEffect(() => {
    if (noCameraMode) {
      setCameraStatus("No-Camera Mode");
      setTrackingQuality("Unavailable");
      setContinuousFaceState("No-Camera Mode");
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach((t) => t.stop());
        videoRef.current.srcObject = null;
      }
      return;
    }

    let landmarker: FaceLandmarker | null = null;
    let rafId = 0;
    let lastInferMs = -1;
    let frameCounter = 0;
    let fpsTimer = performance.now();
    let active = true;

    async function setup() {
      try {
        setCameraStatus("Initializing");
        const vision = await FilesetResolver.forVisionTasks(
          "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm"
        );
        if (!active) return;
        landmarker = await FaceLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath:
              "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task",
            delegate: "GPU",
          },
          outputFaceBlendshapes: true,
          outputFacialTransformationMatrixes: true,
          runningMode: "VIDEO",
          numFaces: 1,
        });

        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480, frameRate: { ideal: 30 } },
        });
        if (!active) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
          setModelReady(true);
          setCameraStatus("Active");
        }
      } catch {
        if (active) {
          setCameraStatus("Permission Denied");
          setTrackingQuality("Unavailable");
        }
        return;
      }

      const loop = () => {
        if (!active) return;
        rafId = requestAnimationFrame(loop);

        const video = videoRef.current;
        if (!video || video.readyState < 2 || video.videoWidth === 0 || !landmarker) return;

        const now = performance.now();
        if (now - lastInferMs < 32) return;
        const timestampMs = Math.max(Math.floor(now), lastInferMs + 1);
        lastInferMs = timestampMs;

        frameCounter++;
        if (now - fpsTimer >= 1000) {
          setFps(frameCounter);
          frameCounter = 0;
          fpsTimer = now;
        }

        let res: FaceLandmarkerResult;
        try {
          res = landmarker.detectForVideo(video, timestampMs);
        } catch {
          return;
        }

        const tel = extractGazeTelemetry(res);
        latestTelemetryRef.current = tel;
        const st = stateRef.current;

        if (meshCanvasRef.current) {
          drawFaceAndEyeMesh(
            meshCanvasRef.current,
            res,
            tel,
            video,
            uiConfigRef.current.meshShowVideoBg,
            uiConfigRef.current.isNight
          );
        }

        // Off-screen detection & quality check
        if (!tel) {
          setTrackingQuality("Unavailable");
          setContinuousFaceState("Off-Screen");
          st.telQueue = [];
          if (st.faceLostStart === 0) {
            st.faceLostStart = timestampMs;
          } else if (
            timestampMs - st.faceLostStart > 3500 &&
            !uiConfigRef.current.isOffScreenPaused
          ) {
            setIsOffScreenPaused(true);
            setMultimodalTriggerState("Paused (Off-Screen)");
          }
          return;
        }

        if (st.faceLostStart > 0) {
          st.faceLostStart = 0;
        }
        if (uiConfigRef.current.isOffScreenPaused && !uiConfigRef.current.showReturnConfirm) {
          setShowReturnConfirm(true);
          setMultimodalTriggerState("Awaiting Resume");
        }

        // Priority 1: Calibration sample collection
        if (collectingPointRef.current && collectingPointRef.current.remaining > 0) {
          if (tel.blink > 0.52) return;
          if (collectingPointRef.current.settle > 0) {
            collectingPointRef.current.settle -= 1;
            return;
          }
          calibSamplesRef.current.X.push(tel.features);
          calibSamplesRef.current.Y.push([
            collectingPointRef.current.targetX,
            collectingPointRef.current.targetY,
          ]);
          collectingPointRef.current.remaining -= 1;
          const done = collectingPointRef.current.total - collectingPointRef.current.remaining;
          setCalibSampleProgress(Math.round((done / collectingPointRef.current.total) * 100));
          return;
        }

        const base = faceBaselineRef.current;
        const relYaw = base ? tel.yawDeg - base.yaw : tel.yawDeg;
        const relPitch = base ? tel.pitchDeg - base.pitch : tel.pitchDeg;

        if (Math.abs(relYaw) > 22 || Math.abs(relPitch) > 18 || tel.blink > 0.5) {
          setTrackingQuality("Limited");
        } else {
          setTrackingQuality("Good");
        }

        setMouthScore(Math.round(tel.jawOpen * 100));

        if (tel.jawOpen > 0.32) {
          setContinuousFaceState("Jaw Open");
        } else if (tel.blink > 0.45) {
          setContinuousFaceState("Blink Guard");
        } else if (Math.abs(relYaw) > 15) {
          setContinuousFaceState(`Yaw ${relYaw > 0 ? "+" : ""}${relYaw}°`);
        } else if (Math.abs(relPitch) > 12) {
          setContinuousFaceState(`Pitch ${relPitch > 0 ? "+" : ""}${relPitch}°`);
        } else {
          setContinuousFaceState("Stable");
        }

        // Resume confirmation via head nod or jaw open
        if (uiConfigRef.current.showReturnConfirm) {
          if (tel.jawOpen > 0.35 || relPitch > 12) {
            setIsOffScreenPaused(false);
            setShowReturnConfirm(false);
            setMultimodalTriggerState("Resumed via Face");
          }
          return;
        }

        // Priority 2: Mouth-open trigger for summoning selection box + quick action bar
        // Runs BEFORE any UI interaction lock so opening mouth while adjusting sliders ALWAYS works!
        if (uiConfigRef.current.gestureControl && tel.jawOpen > 0.32) {
          if (st.mouthOpenStart === 0) {
            st.mouthOpenStart = timestampMs;
          } else if (
            timestampMs - st.mouthOpenStart >= 150 &&
            timestampMs - st.lastMouthTrigger > 800
          ) {
            st.lastMouthTrigger = timestampMs;
            st.mouthOpenStart = 0;

            const { pages: curPages, pageIdx: curPageIdx } = layoutRef.current;
            const safeLine = Math.max(
              0,
              Math.min(st.currentLine, (curPages[curPageIdx]?.length ?? 1) - 1)
            );
            st.currentLine = safeLine;
            setActiveLineIdx(safeLine);

            const rowSegs = curPages[curPageIdx]?.[safeLine]?.segments ?? [];
            if (rowSegs.length > 0 && !rowSegs.some((s) => s.clauseId === st.currentClauseId)) {
              st.currentClauseId = rowSegs[0].clauseId;
              setActiveClauseId(rowSegs[0].clauseId);
            }

            setClauseMenuOpen((prev) => {
              const next = !prev;
              setGestureBadgeText(next ? "Menu Active" : "Standby");
              setMultimodalTriggerState(next ? "Mouth Selection Active" : "Gaze Tracking");
              return next;
            });
          }
          return;
        } else {
          st.mouthOpenStart = 0;
        }

        // Dynamic Spike-Based Blink Guard
        const deltaBlink = tel.blink - st.prevBlink;
        st.prevBlink = tel.blink;
        const isBlinkSpike =
          tel.blink > 0.45 || deltaBlink > 0.11 || tel.blink - st.blinkEma > 0.18;

        if (isBlinkSpike) {
          st.telQueue = [];
          st.blinkCooldownUntil = timestampMs + 130;
          return;
        }
        st.blinkEma = st.blinkEma * 0.92 + tel.blink * 0.08;

        if (timestampMs < st.blinkCooldownUntil) {
          return;
        }

        st.telQueue.push(tel);
        if (st.telQueue.length < 3) {
          return;
        }
        const stableTel = st.telQueue.shift()!;
        const feat = stableTel.features;

        const W = weightsRef.current;
        if (!W || !rowsContainerRef.current) return;

        let rawX = 0;
        let rawY = 0;
        for (let i = 0; i < feat.length; i++) {
          rawX += feat[i] * W[i][0];
          rawY += feat[i] * W[i][1];
        }

        const filtX = filterXRef.current.filter(rawX, timestampMs);
        const filtY = filterYRef.current.filter(rawY, timestampMs) + st.biasY;

        const rowsRect = rowsContainerRef.current.getBoundingClientRect();
        const { pages: curPages, pageIdx: curPageIdx } = layoutRef.current;
        const lineCount = curPages[curPageIdx]?.length ?? 1;
        if (st.lineEnterTime === 0) st.lineEnterTime = timestampMs;

        const curLineHeight = uiConfigRef.current.lineHeightPx;
        const getLineCenterY = (idx: number) => rowsRect.top + (idx + 0.5) * curLineHeight;

        const screenX = Math.max(0, Math.min(window.innerWidth, filtX));
        const screenY = Math.max(0, Math.min(window.innerHeight, filtY));

        // Defensive Lock: If user is adjusting sliders/UI OR mouth selection menu is currently open,
        // update cursor & heatmap smoothly but DO NOT jump lines or reset selection!
        if (
          uiInteractingRef.current ||
          isDraggingSliderRef.current ||
          uiConfigRef.current.clauseMenuOpen
        ) {
          const lockedY = getLineCenterY(st.currentLine);
          setGazePoint((prev) => ({
            ...prev,
            x: screenX,
            y: screenY,
            snappedY: lockedY,
            rawY: filtY,
          }));
          const targetHeatY = uiConfigRef.current.heatmapUseRawY ? screenY : lockedY;
          updateAndRenderHeatmaps(screenX, targetHeatY, rowsRect, st.currentLine, lineCount, curLineHeight);
          return;
        }

        const currentLineObj = curPages[curPageIdx]?.[st.currentLine] ?? {
          segments: [],
          clauseCount: 1,
          wordCount: 8,
          charCount: 45,
          widthRatio: 1,
          isParaStart: true,
          isParaEnd: false,
        };

        st.recentX.push(filtX);
        if (st.recentX.length > 3) st.recentX.shift();
        const smoothX = st.recentX.reduce((a, b) => a + b, 0) / st.recentX.length;

        const textWidthPx = Math.max(280, rowsRect.width - 16);
        const lineStartX = rowsRect.left;
        const localX = Math.max(0, smoothX - lineStartX);
        const lineDwellMs = timestampMs - st.lineEnterTime;

        const expectedLineMs = Math.max(
          550,
          ((currentLineObj.wordCount || 8) / Math.max(80, st.wpmEma)) * 60000
        );
        const timeProgress = Math.min(1.6, lineDwellMs / expectedLineMs);

        const { nextSens, prevSens, skipSens } = uiConfigRef.current;
        const rightFactor = 0.45 - ((nextSens - 65) / 100) * 0.2;
        const backwardHoldMs = Math.max(450, 950 - (prevSens - 30) * 12);
        const verticalSkipHoldMs = Math.max(700, 1500 - (skipSens - 30) * 15);

        // 1. Right-zone latch for smooth return-sweep line advancement
        if (lineDwellMs > 260) {
          if (smoothX > st.maxLineX) st.maxLineX = smoothX;
          const rightTriggerRatio = Math.max(0.2, currentLineObj.widthRatio * rightFactor);
          if (localX >= textWidthPx * rightTriggerRatio || timeProgress >= 0.85) {
            st.reachedRightZone = true;
          }
        }

        const leftLandingRatio = timeProgress >= 0.65 ? 0.5 : 0.44;
        const leftReturnX =
          lineStartX +
          textWidthPx * Math.min(leftLandingRatio, Math.max(0.25, currentLineObj.widthRatio * 0.72));
        const minSweepDropPx = textWidthPx * Math.max(0.14, currentLineObj.widthRatio * 0.22);

        const canNormalWrap =
          st.reachedRightZone &&
          lineDwellMs >= Math.min(480, expectedLineMs * 0.38) &&
          timestampMs - st.lastSweepTime > 520 &&
          smoothX <= leftReturnX &&
          st.maxLineX - smoothX >= minSweepDropPx;

        const canShortTailWrap =
          currentLineObj.widthRatio < 0.32 &&
          lineDwellMs >= expectedLineMs * 0.95 &&
          timestampMs - st.lastSweepTime > 650 &&
          filtY > getLineCenterY(st.currentLine) + curLineHeight * 0.35;

        if (canNormalWrap || canShortTailWrap) {
          if (lineDwellMs >= 400 && lineDwellMs <= 20000 && currentLineObj.wordCount >= 2) {
            const instWpm = (currentLineObj.wordCount / lineDwellMs) * 60000;
            const instCpm = (currentLineObj.charCount / lineDwellMs) * 60000;
            st.wpmEma = Math.round(st.wpmEma * 0.72 + Math.min(550, Math.max(60, instWpm)) * 0.28);
            st.cpmEma = Math.round(st.cpmEma * 0.72 + Math.min(2200, Math.max(150, instCpm)) * 0.28);
          }

          st.lastSweepTime = timestampMs;
          st.reachedRightZone = false;
          st.maxLineX = lineStartX;
          st.backwardCandidateId = -1;
          st.verticalJumpStartTime = 0;

          if (st.currentLine < lineCount - 1) {
            st.currentLine += 1;
            st.lineEnterTime = timestampMs;
            setActiveLineIdx(st.currentLine);
            const nextRowSegs = curPages[curPageIdx]?.[st.currentLine]?.segments ?? [];
            if (nextRowSegs.length > 0) {
              st.currentClauseId = nextRowSegs[0].clauseId;
              setActiveClauseId(nextRowSegs[0].clauseId);
            }

            if (uiConfigRef.current.faceAssist) {
              const trueY = getLineCenterY(st.currentLine);
              const residualY = trueY - filtY;
              if (Math.abs(residualY) < curLineHeight * 3.5) {
                st.biasY += 0.08 * residualY;
              }
            }
          } else if (curPageIdx < curPages.length - 1) {
            st.currentLine = 0;
            st.lineEnterTime = timestampMs;
            setActiveLineIdx(0);
            const nextFirstClause = curPages[curPageIdx + 1]?.[0]?.segments?.[0]?.clauseId ?? 0;
            st.currentClauseId = nextFirstClause;
            setActiveClauseId(nextFirstClause);
            setPageIdx(curPageIdx + 1);
          }
        } else {
          const diffY = filtY - getLineCenterY(st.currentLine);
          const isTryingPrevLine = diffY < -curLineHeight * 1.95;
          const isTryingSkipLine = diffY > curLineHeight * 2.25;

          if (isTryingPrevLine || isTryingSkipLine) {
            if (st.verticalJumpStartTime === 0) {
              st.verticalJumpStartTime = timestampMs;
            } else if (
              timestampMs - st.verticalJumpStartTime >
              (isTryingPrevLine ? backwardHoldMs : verticalSkipHoldMs)
            ) {
              let bestIdx = st.currentLine;
              let minDiff = Infinity;
              for (let i = 0; i < lineCount; i++) {
                const d = Math.abs(filtY - getLineCenterY(i));
                if (d < minDiff) {
                  minDiff = d;
                  bestIdx = i;
                }
              }
              if (bestIdx !== st.currentLine) {
                st.currentLine = bestIdx;
                st.lineEnterTime = timestampMs;
                st.reachedRightZone = false;
                st.maxLineX = lineStartX;
                setActiveLineIdx(bestIdx);
                const targetSegs = curPages[curPageIdx]?.[bestIdx]?.segments ?? [];
                if (targetSegs.length > 0) {
                  st.currentClauseId = targetSegs[0].clauseId;
                  setActiveClauseId(targetSegs[0].clauseId);
                }
              }
              st.verticalJumpStartTime = 0;
            }
          } else {
            st.verticalJumpStartTime = 0;
          }
        }

        // 3. In-row sentence segment matching
        const activeLineSegments = curPages[curPageIdx]?.[st.currentLine]?.segments ?? [];
        if (activeLineSegments.length > 0) {
          let rawMatchedId = st.currentClauseId;
          for (let s = 0; s < activeLineSegments.length; s++) {
            const seg = activeLineSegments[s];
            if (localX >= seg.startX - 8 && localX <= seg.endX + 8) {
              rawMatchedId = seg.clauseId;
              break;
            }
          }

          if (rawMatchedId > st.currentClauseId) {
            if (st.forwardCandidateId !== rawMatchedId) {
              st.forwardCandidateId = rawMatchedId;
              st.forwardStartTime = timestampMs;
            } else if (timestampMs - st.forwardStartTime >= 110) {
              st.currentClauseId = rawMatchedId;
              setActiveClauseId(rawMatchedId);
            }
            st.backwardCandidateId = -1;
          } else if (rawMatchedId < st.currentClauseId) {
            const isSweepingLeft = st.reachedRightZone && smoothX < st.maxLineX - 35;
            if (!isSweepingLeft) {
              if (st.backwardCandidateId !== rawMatchedId) {
                st.backwardCandidateId = rawMatchedId;
                st.backwardStartTime = timestampMs;
              } else if (timestampMs - st.backwardStartTime >= backwardHoldMs) {
                st.currentClauseId = rawMatchedId;
                setActiveClauseId(rawMatchedId);
                st.backwardCandidateId = -1;
              }
            }
            st.forwardCandidateId = -1;
          } else {
            st.forwardCandidateId = -1;
            st.backwardCandidateId = -1;
          }
        }

        setReadingStats({
          wpm: st.wpmEma,
          cpm: st.cpmEma,
          lineProgressPct: Math.min(100, Math.round(timeProgress * 100)),
          rightZoneLatched: st.reachedRightZone,
          currentLineIdx: st.currentLine,
        });

        const snappedY = getLineCenterY(st.currentLine);
        const clampedX = Math.max(lineStartX, Math.min(rowsRect.right - 12, smoothX));

        setGazePoint({
          x: screenX,
          y: screenY,
          snappedX: clampedX,
          snappedY,
          rawY: filtY,
          biasY: Math.round(st.biasY),
        });

        const targetHeatY = uiConfigRef.current.heatmapUseRawY ? screenY : snappedY;
        updateAndRenderHeatmaps(screenX, targetHeatY, rowsRect, st.currentLine, lineCount, curLineHeight);
      };

      rafId = requestAnimationFrame(loop);
    }

    setup();
    return () => {
      active = false;
      cancelAnimationFrame(rafId);
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach((t) => t.stop());
      }
      landmarker?.close();
    };
  }, [noCameraMode, updateAndRenderHeatmaps]);

  // 4. 9-Point Calibration & Personal Face Baseline
  const startCalibration = () => {
    calibSamplesRef.current = { X: [], Y: [] };
    collectingPointRef.current = null;
    setCalibSampleProgress(0);
    setCalibStep(0);
    setIsCalibrating(true);
  };

  const calibratePersonalFaceBaseline = () => {
    const tel = latestTelemetryRef.current;
    if (!tel) {
      showToast("Baseline Failed", "Ensure your face is visible in the camera frame");
      return;
    }
    setFaceBaseline({
      yaw: tel.yawDeg,
      pitch: tel.pitchDeg,
      roll: tel.rollDeg,
      jaw: tel.jawOpen,
    });
    setMultimodalTriggerState("Baseline Locked");
    showToast(
      "Face Baseline Calibrated",
      `Reference pose: Yaw ${tel.yawDeg}° · Pitch ${tel.pitchDeg}° · Roll ${tel.rollDeg}°`
    );
  };

  const handleCalibPointClick = (tx: number, ty: number) => {
    if (collectingPointRef.current && collectingPointRef.current.remaining > 0) return;
    setCalibSampleProgress(0);
    collectingPointRef.current = {
      targetX: tx,
      targetY: ty,
      settle: 3,
      remaining: 20,
      total: 20,
    };

    const checkTimer = setInterval(() => {
      if (!collectingPointRef.current) {
        clearInterval(checkTimer);
        return;
      }
      if (collectingPointRef.current.remaining <= 0) {
        clearInterval(checkTimer);
        collectingPointRef.current = null;
        setCalibSampleProgress(0);

        if (calibStep < CALIBRATION_POINTS.length - 1) {
          setCalibStep((s) => s + 1);
        } else {
          const { X, Y } = calibSamplesRef.current;
          weightsRef.current = solveRidgeRegression(X, Y, 0.6);
          const firstClause = pages[pageIdx]?.[0]?.segments?.[0]?.clauseId ?? 0;
          stateRef.current.biasY = 0;
          stateRef.current.currentLine = 0;
          stateRef.current.currentClauseId = firstClause;
          stateRef.current.lineEnterTime = performance.now();
          stateRef.current.reachedRightZone = false;
          stateRef.current.maxLineX = 0;
          heatGridRef.current.fill(0);
          setActiveLineIdx(0);
          setActiveClauseId(firstClause);
          setClauseMenuOpen(false);
          setIsCalibrating(false);
          setIsCalibrated(true);
          showToast("9-Point Calibration Complete", "Gaze highlights sentences; open mouth to summon selection & menu");
        }
      }
    }, 30);
  };

  // 5. Right Sidebar Card Drag-to-Reorder Handler
  const handleStartCardDrag = (cardId: RightCardId, e: React.PointerEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest("button, input, label, select, textarea")) return;
    e.preventDefault();
    uiInteractingRef.current = true;
    setDraggingCardId(cardId);
    setDragCardOffsetY(0);

    let lastY = e.clientY;
    let accumOffset = 0;

    const onMove = (ev: PointerEvent) => {
      const dy = ev.clientY - lastY;
      lastY = ev.clientY;
      accumOffset += dy;

      setRightCardOrder((prevOrder) => {
        const curIdx = prevOrder.indexOf(cardId);
        if (curIdx === -1) return prevOrder;

        if (accumOffset > 48 && curIdx < prevOrder.length - 1) {
          const nextOrder = [...prevOrder];
          [nextOrder[curIdx], nextOrder[curIdx + 1]] = [nextOrder[curIdx + 1], nextOrder[curIdx]];
          accumOffset -= 56;
          return nextOrder;
        }
        if (accumOffset < -48 && curIdx > 0) {
          const nextOrder = [...prevOrder];
          [nextOrder[curIdx], nextOrder[curIdx - 1]] = [nextOrder[curIdx - 1], nextOrder[curIdx]];
          accumOffset += 56;
          return nextOrder;
        }
        return prevOrder;
      });

      setDragCardOffsetY(accumOffset);
    };

    const onUp = () => {
      setDraggingCardId(null);
      setDragCardOffsetY(0);
      uiInteractingRef.current = false;
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
    };

    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
  };

  // 6. Sentence text helpers & quick actions
  const currentLines = pages[pageIdx] ?? [];

  const getSentenceTextById = useCallback(
    (targetCid: number) => {
      const parts: string[] = [];
      pages.forEach((p) => {
        p.forEach((row) => {
          row.segments.forEach((seg) => {
            if (seg.clauseId === targetCid) {
              parts.push(seg.text.trim());
            }
          });
        });
      });
      return parts.join(" ").trim();
    },
    [pages]
  );

  const getActiveSentenceText = useCallback(() => {
    const activeRow = currentLines[activeLineIdx];
    const seg = activeRow?.segments.find((s) => s.clauseId === activeClauseId) ?? activeRow?.segments[0];
    return seg ? seg.text.trim() : getSentenceTextById(activeClauseId);
  }, [currentLines, activeLineIdx, activeClauseId, getSentenceTextById]);

  const toggleTtsReading = (readSingleSentence = false) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      showToast("TTS Unavailable", "Web Speech synthesis is not supported in this browser");
      return;
    }
    try {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
        showToast("Audio Stopped");
        return;
      }
      const textToRead = readSingleSentence
        ? getActiveSentenceText()
        : currentLines.map((l) => l.segments.map((s) => s.text).join(" ")).join(" ");
      if (!textToRead) return;

      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(textToRead);
      utter.lang = "en-US";
      utter.rate = 1.0;
      utter.onend = () => setIsSpeaking(false);
      utter.onerror = () => setIsSpeaking(false);
      setIsSpeaking(true);
      window.speechSynthesis.speak(utter);
      showToast(
        readSingleSentence ? "Reading Active Sentence" : "Audiobook Mode Active",
        readSingleSentence ? textToRead.slice(0, 40) + "..." : `Reading Page ${pageIdx + 1}`
      );
    } catch {
      setIsSpeaking(false);
    }
  };

  const addBookmarkForActiveClause = () => {
    const fullSentence = getActiveSentenceText() || "Selected sentence";
    const snippet = fullSentence.slice(0, 34) + (fullSentence.length > 34 ? "......" : "");
    setBookmarks((prev) => [
      ...prev.filter((b) => b.id !== activeClauseId),
      { id: activeClauseId, text: snippet, page: pageIdx, line: activeLineIdx },
    ]);
    setClauseMenuOpen(false);
    showToast("Bookmark Saved", `Page ${pageIdx + 1} · Row ${activeLineIdx + 1}`);
  };

  const copyActiveClause = () => {
    const txt = getActiveSentenceText();
    try {
      navigator.clipboard?.writeText(txt);
    } catch {
      // Ignore clipboard permission errors
    }
    setClauseMenuOpen(false);
    showToast("Sentence Copied", txt.slice(0, 42) + (txt.length > 42 ? "..." : ""));
  };

  const toggleHighlightActiveClause = () => {
    setHighlightedClauses((prev) => {
      const next = new Set(prev);
      if (next.has(activeClauseId)) {
        next.delete(activeClauseId);
        showToast("Highlight Removed", `Sentence #${activeClauseId + 1}`);
      } else {
        next.add(activeClauseId);
        showToast("Sentence Highlighted", "Saved to Highlights list");
      }
      return next;
    });
    setClauseMenuOpen(false);
  };

  const toggleUnderlineActiveClause = () => {
    setUnderlinedClauses((prev) => {
      const next = new Set(prev);
      if (next.has(activeClauseId)) {
        next.delete(activeClauseId);
        showToast("Underline Removed");
      } else {
        next.add(activeClauseId);
        showToast("Sentence Underlined");
      }
      return next;
    });
    setClauseMenuOpen(false);
  };

  const addActiveSentenceToNotes = () => {
    const txt = getActiveSentenceText();
    if (txt) {
      setNotesList((prev) => [`[Quote P${pageIdx + 1}] ${txt}`, ...prev]);
      showToast("Added to Reading Notes", "Open Notes panel from the top bar to view");
    }
    setClauseMenuOpen(false);
  };

  const toggleMicrophone = () => {
    const SpeechRec =
      typeof window !== "undefined"
        ? (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown })
            .SpeechRecognition ||
          (window as unknown as { webkitSpeechRecognition?: unknown }).webkitSpeechRecognition
        : null;

    if (!SpeechRec) {
      setVoiceError(true);
      setVoiceLog("Speech API unavailable — click Retry");
      showToast("Voice Unavailable", "Use desktop Chrome or Edge for Web Speech API");
      return;
    }

    if (micActive) {
      setMicActive(false);
      setVoiceLog("Microphone paused");
      showToast("Microphone Off");
      return;
    }

    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const recognition = new (SpeechRec as any)();
      recognition.lang = "en-US";
      recognition.continuous = false;
      recognition.interimResults = false;
      setVoiceError(false);
      setMicActive(true);
      setVoiceLog(
        voiceMode === "Read"
          ? "Listening for command (next line / open menu)..."
          : "Listening for voice note..."
      );

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recognition.onresult = (event: any) => {
        const transcript = String(event.results?.[0]?.[0]?.transcript || "")
          .toLowerCase()
          .trim();
        setVoiceLog(transcript || "No speech detected");
        setMicActive(false);

        if (voiceMode === "Notes" && transcript) {
          setNotesList((prev) => [`[Voice Note] ${transcript}`, ...prev]);
          setMultimodalTriggerState("Voice Note Saved");
          showToast("Voice Note Saved", transcript);
          return;
        }

        if (transcript.includes("next")) {
          const nextRow = Math.min(currentLines.length - 1, activeLineIdx + 1);
          const cid = currentLines[nextRow]?.segments?.[0]?.clauseId ?? activeClauseId;
          stateRef.current.currentLine = nextRow;
          stateRef.current.currentClauseId = cid;
          setActiveLineIdx(nextRow);
          setActiveClauseId(cid);
          setMultimodalTriggerState("Voice: Next Line");
        } else if (transcript.includes("menu") || transcript.includes("open") || transcript.includes("select")) {
          setClauseMenuOpen(true);
          setMultimodalTriggerState("Voice: Menu Open");
        }
      };

      recognition.onerror = () => {
        setMicActive(false);
        setVoiceError(true);
        setVoiceLog("Recognition failed — tap Retry");
      };
      recognition.onend = () => setMicActive(false);
      recognition.start();
    } catch {
      setVoiceError(true);
      setMicActive(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const buffer = await file.arrayBuffer();
    let decoded = new TextDecoder("utf-8", { fatal: false }).decode(buffer);
    if (decoded.includes("\uFFFD")) {
      decoded = new TextDecoder("gbk").decode(buffer);
    }
    const cleanTitle = file.name.replace(/\.txt$/i, "");
    setCustomTitle(cleanTitle);
    setRawText(decoded);
    setNotesModalOpen(false);
    showToast("TXT Document Imported", `Loaded "${cleanTitle}"`);
  };

  const isNight = bgTheme === "Night";

  const bgThemeStyles = {
    Paper: "bg-[#e3dfd7]",
    White: "bg-[#f8f9fa]",
    Night: "bg-[#141619]",
  }[bgTheme];

  const textColorStyles = {
    Black: isNight ? "text-stone-100" : "text-stone-900",
    Gray: isNight ? "text-stone-400" : "text-stone-600",
    Soft: isNight ? "text-amber-200/80" : "text-[#5c3d38]",
  }[textColor];

  const unifiedSurfaceClass = isNight
    ? "bg-[#1c1e22]/95 border-stone-700/80 text-stone-100 shadow-2xl"
    : "bg-white/95 border-stone-300/85 text-stone-900 shadow-xl";

  const unifiedSubtleBoxClass = isNight
    ? "bg-stone-900/75 border-stone-700/70 text-stone-300"
    : "bg-[#f5f3ef]/90 border-stone-200/90 text-stone-700";

  const rowBadgeWeakContrastClass = isNight
    ? "bg-stone-800/40 text-stone-500 border-stone-700/30"
    : bgTheme === "White"
    ? "bg-stone-200/55 text-stone-400 border-stone-300/40"
    : "bg-stone-400/15 text-stone-500/75 border-stone-400/20";

  const dimBackdropActive = leftSidebarOpen || rightSidebarOpen;
  const currentChapterTitle = customTitle || BOOK_CHAPTERS[chapterIdx]?.title || "Why not chase each word";
  const formatTime = (sec: number) => `${Math.floor(sec / 60)}m ${sec % 60}s`;

  // Render helper for draggable right sidebar cards
  const renderRightSidebarCard = (cardId: RightCardId) => {
    const isDragging = draggingCardId === cardId;
    const dragStyle: React.CSSProperties = isDragging
      ? {
          transform: `translate3d(0, ${dragCardOffsetY}px, 0)`,
          zIndex: 40,
          opacity: 0.94,
        }
      : {};

    const dragHandleBadge = (
      <span
        className="text-xs opacity-35 hover:opacity-80 cursor-grab active:cursor-grabbing px-1 select-none"
        title="Drag to reorder card"
      >
        ⋮⋮
      </span>
    );

    switch (cardId) {
      case "speed":
        return (
          <div
            key="speed"
            ref={(el) => {
              rightCardsRefs.current.speed = el;
            }}
            onPointerDown={(e) => handleStartCardDrag("speed", e)}
            style={dragStyle}
            className={`rounded-2xl p-5 border cursor-grab active:cursor-grabbing transition-shadow ${unifiedSurfaceClass}`}
          >
            <div className="flex items-center justify-between text-xs opacity-60 mb-1 whitespace-nowrap tabular-nums">
              <span>Reading Speed</span>
              <div className="flex items-center gap-1.5">
                <span>Active Time: {formatTime(readingSeconds)}</span>
                {dragHandleBadge}
              </div>
            </div>
            <div className="text-5xl font-serif tracking-tight my-1 tabular-nums">
              {readingStats.wpm}
            </div>
            <div className="text-xs opacity-60 whitespace-nowrap tabular-nums">
              words per minute ({readingStats.cpm} CPM · Row {readingStats.lineProgressPct}%)
            </div>
          </div>
        );

      case "sensing":
        return (
          <div
            key="sensing"
            ref={(el) => {
              rightCardsRefs.current.sensing = el;
            }}
            onPointerDown={(e) => handleStartCardDrag("sensing", e)}
            style={dragStyle}
            className={`rounded-2xl p-5 border space-y-2.5 cursor-grab active:cursor-grabbing transition-shadow ${unifiedSurfaceClass}`}
          >
            <div className="flex items-center justify-between whitespace-nowrap">
              <h3 className="text-base font-serif font-medium">Sensing & Face</h3>
              <div className="flex items-center gap-1.5">
                <span
                  className={`text-[10px] px-2.5 py-0.5 rounded-full font-medium border ${
                    trackingQuality === "Good"
                      ? "bg-emerald-500/15 text-emerald-700 border-emerald-500/30"
                      : trackingQuality === "Limited"
                      ? "bg-amber-500/15 text-amber-700 border-amber-500/30"
                      : "bg-stone-500/15 text-stone-500 border-stone-400/30"
                  }`}
                >
                  Quality: {trackingQuality}
                </span>
                {dragHandleBadge}
              </div>
            </div>

            <div className={`text-[11px] rounded-xl p-2.5 border space-y-1 tabular-nums ${unifiedSubtleBoxClass}`}>
              <div className="flex justify-between whitespace-nowrap">
                <span className="opacity-75">Camera Status:</span>
                <span className="font-medium">
                  {cameraStatus === "Active" ? `Active (${fps} FPS)` : cameraStatus}
                </span>
              </div>
              <div className="flex justify-between whitespace-nowrap">
                <span className="opacity-75">Face Dynamics:</span>
                <span className="font-medium">{continuousFaceState}</span>
              </div>
              <div className="flex justify-between whitespace-nowrap">
                <span className="opacity-75">Multimodal State:</span>
                <span className="font-medium">{multimodalTriggerState}</span>
              </div>
              {faceBaseline && (
                <div className="flex justify-between text-[10px] opacity-65 pt-0.5 border-t border-stone-300/40 whitespace-nowrap">
                  <span>Personal Baseline:</span>
                  <span>
                    Y{faceBaseline.yaw}° / P{faceBaseline.pitch}° / R{faceBaseline.roll}°
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between text-xs whitespace-nowrap">
              <span className="font-medium">Gaze Cursor</span>
              <ToggleSwitch checked={showGazeCursor} onChange={() => setShowGazeCursor((v) => !v)} />
            </div>

            <div className="flex items-center justify-between text-xs whitespace-nowrap">
              <span>Camera Live Window</span>
              <ToggleSwitch
                checked={winVideo.visible}
                onChange={() => setWinVideo((p) => ({ ...p, visible: !p.visible }))}
              />
            </div>

            <div className="flex items-center justify-between text-xs whitespace-nowrap">
              <span>Topology Mesh Window</span>
              <ToggleSwitch
                checked={winMesh.visible}
                onChange={() => setWinMesh((p) => ({ ...p, visible: !p.visible }))}
              />
            </div>

            <div className="flex items-center justify-between text-xs whitespace-nowrap">
              <span>Gaze Heatmap Overlay</span>
              <ToggleSwitch
                checked={showPageHeatmap}
                onChange={() => {
                  const next = !showPageHeatmap;
                  setShowPageHeatmap(next);
                  setWinHeatmap((p) => ({ ...p, visible: next }));
                }}
              />
            </div>

            <div className="flex items-center justify-between text-xs whitespace-nowrap">
              <span>Face Drift Assist</span>
              <ToggleSwitch checked={faceAssist} onChange={() => setFaceAssist((v) => !v)} />
            </div>

            <div className="flex items-center justify-between text-xs whitespace-nowrap">
              <span>No-Camera Reading Mode</span>
              <ToggleSwitch checked={noCameraMode} onChange={() => setNoCameraMode((v) => !v)} />
            </div>

            <div className="pt-2 border-t border-stone-300/40 grid grid-cols-2 gap-2">
              <button
                type="button"
                disabled={!modelReady || noCameraMode}
                onClick={() => {
                  setRightSidebarOpen(false);
                  startCalibration();
                }}
                className="py-1.5 px-2 rounded-xl bg-stone-900 hover:bg-stone-800 disabled:opacity-40 text-white text-xs font-medium transition whitespace-nowrap"
              >
                {isCalibrated ? "Recalibrate 9-Pt" : "9-Pt Calibration"}
              </button>
              <button
                type="button"
                disabled={!modelReady || noCameraMode}
                onClick={calibratePersonalFaceBaseline}
                className={`py-1.5 px-2 rounded-xl border text-xs font-medium disabled:opacity-40 transition whitespace-nowrap ${unifiedSubtleBoxClass}`}
              >
                Face Baseline
              </button>
            </div>
          </div>
        );

      case "settings":
        return (
          <div
            key="settings"
            ref={(el) => {
              rightCardsRefs.current.settings = el;
            }}
            onPointerDown={(e) => handleStartCardDrag("settings", e)}
            style={dragStyle}
            className={`rounded-2xl p-5 border space-y-3.5 cursor-grab active:cursor-grabbing transition-shadow ${unifiedSurfaceClass}`}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[11px] opacity-55">Reading</div>
                <h3 className="text-xl font-serif font-medium">Settings</h3>
              </div>
              {dragHandleBadge}
            </div>

            <div>
              <div className="text-[11px] opacity-55 mb-1.5">Font Family</div>
              <div className="flex items-center gap-2">
                {(["Georgia", "Inter", "Literata"] as const).map((f) => (
                  <button
                    type="button"
                    key={f}
                    onClick={() => setFontFamily(f)}
                    className={`px-3 py-1 rounded-full text-xs border transition ${
                      fontFamily === f
                        ? "bg-stone-900 text-white border-stone-900 font-medium"
                        : "border-stone-300/80 opacity-75 hover:opacity-100"
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="text-[11px] opacity-55 mb-1.5">Background</div>
              <div className="flex items-center gap-3 text-xs">
                {[
                  { name: "Paper" as const, dot: "bg-[#e3dfd7]" },
                  { name: "White" as const, dot: "bg-white" },
                  { name: "Night" as const, dot: "bg-stone-900" },
                ].map((b) => (
                  <button
                    type="button"
                    key={b.name}
                    onClick={() => setBgTheme(b.name)}
                    className="flex items-center gap-1.5"
                  >
                    <span
                      className={`w-4 h-4 rounded-full border ${b.dot} ${
                        bgTheme === b.name ? "ring-2 ring-stone-900 ring-offset-1" : "border-stone-400"
                      }`}
                    />
                    <span>{b.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="text-[11px] opacity-55 mb-1.5">Text Color</div>
              <div className="flex items-center gap-3 text-xs">
                {[
                  { name: "Black" as const, dot: "bg-stone-950" },
                  { name: "Gray" as const, dot: "bg-stone-500" },
                  { name: "Soft" as const, dot: "bg-[#6e3b37]" },
                ].map((c) => (
                  <button
                    type="button"
                    key={c.name}
                    onClick={() => setTextColor(c.name)}
                    className="flex items-center gap-1.5"
                  >
                    <span
                      className={`w-4 h-4 rounded-full ${c.dot} ${
                        textColor === c.name ? "ring-2 ring-stone-900 ring-offset-1" : ""
                      }`}
                    />
                    <span>{c.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-[11px] mb-1 tabular-nums whitespace-nowrap">
                <span className="opacity-60">Text Size (px)</span>
                <span className="font-semibold">{fontSize}</span>
              </div>
              <input
                type="range"
                min={12}
                max={22}
                value={fontSize}
                onChange={(e) => setFontSize(Number(e.target.value))}
                className="w-full accent-stone-900 h-1 bg-stone-300 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-[11px] mb-1 tabular-nums whitespace-nowrap">
                <span className="opacity-60">Reading Width (%)</span>
                <span className="font-semibold">{readingWidthPct}%</span>
              </div>
              <input
                type="range"
                min={50}
                max={92}
                step={2}
                value={readingWidthPct}
                onChange={(e) => setReadingWidthPct(Number(e.target.value))}
                className="w-full accent-stone-900 h-1 bg-stone-300 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-[11px] mb-1 tabular-nums whitespace-nowrap">
                <span className="opacity-60">Line Spacing</span>
                <span className="font-semibold">{lineSpacingRatio.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min={1.8}
                max={2.9}
                step={0.05}
                value={lineSpacingRatio}
                onChange={(e) => setLineSpacingRatio(Number(e.target.value))}
                className="w-full accent-stone-900 h-1 bg-stone-300 rounded-lg cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between text-xs pt-0.5 whitespace-nowrap">
              <span>Row Stats Badge</span>
              <ToggleSwitch checked={showRowMeta} onChange={() => setShowRowMeta((v) => !v)} />
            </div>

            {/* 4 Unified Switches (Same clean style without center black dot) */}
            <div className="space-y-2 pt-2 border-t border-stone-300/40">
              <div className="text-[11px] opacity-55 whitespace-nowrap">
                Mouth Menu Items & Bottom-Left Bar
              </div>
              {[
                {
                  label: "Bookmark in Mouth Menu",
                  val: menuShowBookmark,
                  set: setMenuShowBookmark,
                },
                {
                  label: "Highlight in Mouth Menu",
                  val: menuShowHighlight,
                  set: setMenuShowHighlight,
                },
                {
                  label: "Notes in Mouth Menu",
                  val: menuShowNotes,
                  set: setMenuShowNotes,
                },
                {
                  label: "Bottom-Left Difficulty Bar",
                  val: showBottomLeftBar,
                  set: setShowBottomLeftBar,
                },
              ].map((item) => (
                <div
                  key={item.label}
                  onClick={() => item.set((v) => !v)}
                  className={`w-full px-3.5 py-2 rounded-2xl border flex items-center justify-between text-xs cursor-pointer transition whitespace-nowrap ${unifiedSubtleBoxClass}`}
                >
                  <span className="font-medium pr-2">{item.label}</span>
                  <ToggleSwitch checked={item.val} onChange={() => item.set((v) => !v)} />
                </div>
              ))}
            </div>
          </div>
        );

      case "gesture":
        return (
          <div
            key="gesture"
            ref={(el) => {
              rightCardsRefs.current.gesture = el;
            }}
            onPointerDown={(e) => handleStartCardDrag("gesture", e)}
            style={dragStyle}
            className={`rounded-2xl p-5 border space-y-3 cursor-grab active:cursor-grabbing transition-shadow ${unifiedSurfaceClass}`}
          >
            <div className="flex items-center justify-between whitespace-nowrap tabular-nums">
              <h3 className="text-base font-serif font-medium">Gesture</h3>
              <div className="flex items-center gap-1.5">
                <span
                  className={`text-[10px] px-2.5 py-0.5 rounded-full font-medium border ${
                    !gestureControl
                      ? "bg-stone-500/15 text-stone-500 border-stone-400/30"
                      : clauseMenuOpen
                      ? "bg-amber-500/15 text-amber-700 border-amber-500/30"
                      : "bg-stone-500/10 text-stone-700 border-stone-300/60"
                  }`}
                >
                  {!gestureControl ? "Disabled" : `${gestureBadgeText} · Jaw ${mouthScore}%`}
                </span>
                {dragHandleBadge}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs whitespace-nowrap">
              <span>Explicit Gesture Control</span>
              <ToggleSwitch checked={gestureControl} onChange={() => setGestureControl((v) => !v)} />
            </div>

            <div className="flex items-center justify-between text-xs whitespace-nowrap">
              <span>Spatial Visual Reticle</span>
              <ToggleSwitch checked={showReticle} onChange={() => setShowReticle((v) => !v)} />
            </div>

            <div className="flex items-center justify-between text-xs whitespace-nowrap">
              <span>Gestalt Background Blur</span>
              <ToggleSwitch checked={bgBlur} onChange={() => setBgBlur((v) => !v)} />
            </div>
          </div>
        );

      case "voice":
        return (
          <div
            key="voice"
            ref={(el) => {
              rightCardsRefs.current.voice = el;
            }}
            onPointerDown={(e) => handleStartCardDrag("voice", e)}
            style={dragStyle}
            className={`rounded-2xl p-5 border space-y-3 cursor-grab active:cursor-grabbing transition-shadow ${unifiedSurfaceClass}`}
          >
            <div className="flex items-center justify-between whitespace-nowrap">
              <h3 className="text-base font-serif font-medium">Voice</h3>
              <div className="flex items-center gap-2">
                {voiceError && (
                  <button
                    type="button"
                    onClick={toggleMicrophone}
                    className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-600 border border-rose-400/30 hover:bg-rose-500/25"
                  >
                    Failed · Retry
                  </button>
                )}
                <ToggleSwitch
                  checked={micActive}
                  onChange={toggleMicrophone}
                  title="Microphone Toggle"
                />
                {dragHandleBadge}
              </div>
            </div>

            <div className="flex items-center gap-2">
              {(["Read", "Notes"] as const).map((m) => (
                <button
                  type="button"
                  key={m}
                  onClick={() => setVoiceMode(m)}
                  className={`px-3.5 py-1 rounded-full text-xs border transition whitespace-nowrap ${
                    voiceMode === m
                      ? "bg-stone-900 text-white border-stone-900 font-medium"
                      : "border-stone-300/80 opacity-75"
                  }`}
                >
                  {m === "Read" ? "Read Mode" : "Notes Mode"}
                </button>
              ))}
            </div>

            <div className={`text-xs px-3 py-2 rounded-xl border font-mono truncate ${unifiedSubtleBoxClass}`}>
              {voiceLog}
            </div>
          </div>
        );
    }
  };

  return (
    <div
      className={`min-h-screen w-full flex flex-col justify-between select-none transition-colors duration-300 relative overflow-x-hidden ${bgThemeStyles} ${textColorStyles}`}
    >
      {/* Full-page real-time gaze heatmap canvas */}
      <canvas
        ref={fullHeatmapCanvasRef}
        width={HEAT_W}
        height={HEAT_H}
        className={`pointer-events-none fixed inset-0 w-full h-full z-30 transition-opacity duration-200 ${
          showPageHeatmap && isCalibrated && !isCalibrating ? "opacity-80" : "opacity-0"
        }`}
      />

      {/* ==================== 3 Unified Floating Monitor Windows (Initial Width 280px Each) ==================== */}

      <FloatingWindow
        title="1. Camera Live"
        winState={winVideo}
        setWinState={setWinVideo}
        isNight={isNight}
      >
        <div
          className={`relative w-full h-full rounded-xl overflow-hidden border ${
            isNight ? "border-stone-700/80 bg-stone-950" : "border-stone-300/80 bg-stone-200/60"
          }`}
        >
          <video
            ref={videoRef}
            playsInline
            muted
            className="w-full h-full object-cover -scale-x-100"
          />
          {noCameraMode && (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center text-xs opacity-75">
              <span>No-Camera Mode Active</span>
              <span className="text-[10px] mt-1">Re-enable camera in the Sensing panel</span>
            </div>
          )}
          <div
            className={`absolute bottom-2 left-2 right-2 px-2.5 py-1 rounded-lg border backdrop-blur-md flex items-center justify-between text-[11px] font-mono tabular-nums ${unifiedSubtleBoxClass}`}
          >
            <span>{cameraStatus === "Active" ? `Live · ${fps} FPS` : cameraStatus}</span>
            <span>Jaw {mouthScore}%</span>
          </div>
        </div>
      </FloatingWindow>

      <FloatingWindow
        title="2. Face & Eye Topology"
        winState={winMesh}
        setWinState={setWinMesh}
        isNight={isNight}
        headerExtra={
          <button
            type="button"
            onClick={() => setMeshShowVideoBg((v) => !v)}
            className={`px-2 py-0.5 text-[10px] rounded-full border transition ${unifiedSubtleBoxClass}`}
          >
            {meshShowVideoBg ? "Grid Bg" : "Video Bg"}
          </button>
        }
      >
        <div
          className={`w-full h-full rounded-xl overflow-hidden border ${
            isNight ? "border-stone-700/80" : "border-stone-300/80"
          }`}
        >
          <canvas
            ref={meshCanvasRef}
            width={320}
            height={240}
            className="w-full h-full block object-contain"
          />
        </div>
      </FloatingWindow>

      <FloatingWindow
        title="3. Gaze Heatmap Monitor"
        winState={winHeatmap}
        setWinState={setWinHeatmap}
        isNight={isNight}
        headerExtra={
          <button
            type="button"
            onClick={() => {
              heatGridRef.current.fill(0);
              showToast("Heatmap Cleared");
            }}
            className={`px-2 py-0.5 text-[10px] rounded-full border transition hover:border-rose-400 ${unifiedSubtleBoxClass}`}
          >
            Clear
          </button>
        }
      >
        <div
          className={`w-full h-full rounded-xl overflow-hidden border flex flex-col ${
            isNight ? "border-stone-700/80 bg-[#181a1e]" : "border-stone-300/80 bg-[#f5f3ef]"
          }`}
        >
          <div className="flex-1 relative min-h-0">
            <canvas
              ref={miniHeatmapCanvasRef}
              width={280}
              height={160}
              className="w-full h-full block"
            />
            {!isCalibrated && (
              <div className="absolute inset-0 flex items-center justify-center px-4 text-center text-xs opacity-65">
                Complete 9-point calibration to visualize real-time gaze heatmap
              </div>
            )}
          </div>
          <div
            className={`h-8 px-2.5 border-t flex items-center justify-between text-[11px] shrink-0 ${unifiedSubtleBoxClass}`}
          >
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={showPageHeatmap}
                onChange={(e) => setShowPageHeatmap(e.target.checked)}
                className="accent-stone-900"
              />
              <span>Overlay</span>
            </label>
            <button
              type="button"
              onClick={() => setHeatmapDecayMode((m) => !m)}
              className="px-2 py-0.5 rounded border border-stone-300/60 text-[10px]"
            >
              {heatmapDecayMode ? "Decay" : "Accumulate"}
            </button>
            <button
              type="button"
              onClick={() => setHeatmapUseRawY((r) => !r)}
              className="px-2 py-0.5 rounded border border-stone-300/60 text-[10px]"
            >
              {heatmapUseRawY ? "Raw Y" : "Snapped Y"}
            </button>
          </div>
        </div>
      </FloatingWindow>

      {/* ==================== Top Navigation Bar ==================== */}
      <header
        onPointerEnter={() => {
          uiInteractingRef.current = true;
        }}
        onPointerLeave={() => {
          if (!isDraggingSliderRef.current) uiInteractingRef.current = false;
        }}
        className="h-14 px-8 pt-2 flex items-center justify-between z-20 shrink-0"
      >
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setLeftSidebarOpen((v) => !v)}
            className={`w-10 h-8 rounded-full border flex items-center justify-center transition ${unifiedSurfaceClass}`}
            title="Contents & Bookmarks"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="4" y="4" width="16" height="16" rx="2" />
              <line x1="9" y1="4" x2="9" y2="20" />
            </svg>
          </button>

          <div
            className={`text-xs px-3.5 py-1 rounded-full border backdrop-blur-sm flex items-center gap-2 tabular-nums whitespace-nowrap ${unifiedSubtleBoxClass}`}
          >
            <span>Row {readingStats.currentLineIdx + 1}</span>
            <span className="opacity-40">|</span>
            <span>{readingStats.wpm} WPM</span>
            <span className="opacity-40">|</span>
            <span>
              {formatTime(readingSeconds)}
              {isOffScreenPaused ? " (Paused)" : ""}
            </span>
            <span className="opacity-40">|</span>
            <span className={clauseMenuOpen ? "font-semibold underline underline-offset-2" : "opacity-80"}>
              {clauseMenuOpen ? "Selection Active" : "Gaze Sentence · Mouth Select"}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {!isCalibrated && !noCameraMode && (
            <button
              type="button"
              disabled={!modelReady}
              onClick={startCalibration}
              className="px-3.5 py-1.5 rounded-full bg-stone-900 text-white text-xs font-medium shadow-sm hover:bg-stone-800 disabled:opacity-40 transition whitespace-nowrap"
            >
              {modelReady ? "Calibrate Gaze (9-Pt)" : "Loading Model..."}
            </button>
          )}

          <button
            type="button"
            onClick={() => setBuyModalOpen(true)}
            className={`px-3 h-8 rounded-full text-xs font-medium border transition flex items-center gap-1 whitespace-nowrap ${
              isPurchased
                ? "bg-emerald-50/90 text-emerald-800 border-emerald-300"
                : unifiedSurfaceClass
            }`}
            title="Purchase Full Book"
          >
            <span>{isPurchased ? "✓ Purchased" : "Buy"}</span>
          </button>

          <button
            type="button"
            onClick={() => toggleTtsReading(false)}
            className={`w-10 h-8 rounded-full border flex items-center justify-center transition ${
              isSpeaking
                ? "bg-amber-600 text-white border-amber-600"
                : unifiedSurfaceClass
            }`}
            title="Audiobook Read Aloud (TTS)"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 18v-6a9 9 0 0 1 18 0v6" />
              <path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z" />
            </svg>
          </button>

          <button
            type="button"
            onClick={() => setNotesModalOpen((v) => !v)}
            className={`w-10 h-8 rounded-full border flex items-center justify-center transition ${unifiedSurfaceClass}`}
            title="Reading Notes, Highlights & TXT Import"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M4 7V5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2" />
              <path d="M10 12h7" />
              <path d="M10 16h4" />
            </svg>
          </button>

          <button
            type="button"
            onClick={() => setRightSidebarOpen((v) => !v)}
            className={`w-10 h-8 rounded-full border flex items-center justify-center transition ${
              rightSidebarOpen
                ? "bg-stone-900 text-white border-stone-900"
                : unifiedSurfaceClass
            }`}
            title="Reading Settings & Multimodal Sensing"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="3" />
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
            </svg>
          </button>

          <button
            type="button"
            onClick={toggleMicrophone}
            className={`w-14 h-8 rounded-full p-0.5 flex items-center border transition-colors ${
              micActive
                ? "bg-emerald-700 border-emerald-600 justify-end"
                : "bg-stone-900 border-stone-800 justify-start"
            }`}
            title="Live Microphone Toggle"
          >
            <span className="w-7 h-7 rounded-full bg-white flex items-center justify-center text-stone-900 shadow">
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
                <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
                <line x1="12" y1="19" x2="12" y2="23" />
              </svg>
            </span>
          </button>
        </div>
      </header>

      {/* Backdrop when sidebars are open */}
      {dimBackdropActive && (
        <div
          onClick={() => {
            setLeftSidebarOpen(false);
            setRightSidebarOpen(false);
          }}
          className="fixed inset-0 bg-black/25 z-20 transition-opacity"
        />
      )}

      {/* ==================== Widened Left Sidebar (Contents & Bookmarks ONLY) ==================== */}
      <aside
        onPointerEnter={() => {
          uiInteractingRef.current = true;
        }}
        onPointerLeave={() => {
          if (!isDraggingSliderRef.current) uiInteractingRef.current = false;
        }}
        className={`fixed top-4 bottom-4 left-4 w-80 rounded-2xl border z-30 flex flex-col justify-between p-6 transition-transform duration-300 ${unifiedSurfaceClass} ${
          leftSidebarOpen ? "translate-x-0" : "-translate-x-[120%]"
        }`}
      >
        <div className="overflow-y-auto space-y-6 pr-1">
          <div>
            <h2 className="text-lg font-serif font-medium mb-3">Contents</h2>
            <ul className="space-y-2 text-xs">
              {BOOK_CHAPTERS.map((chap, idx) => (
                <li
                  key={idx}
                  onClick={() => {
                    setCustomTitle(null);
                    setChapterIdx(idx);
                    setRawText(chap.content);
                    setLeftSidebarOpen(false);
                    showToast("Chapter Switched", chap.title);
                  }}
                  className={`flex items-center gap-2.5 cursor-pointer py-1.5 px-2.5 rounded-lg transition ${
                    chapterIdx === idx && !customTitle
                      ? isNight
                        ? "bg-stone-800 text-white font-semibold"
                        : "bg-stone-200/75 text-stone-950 font-semibold"
                      : "opacity-65 hover:opacity-100"
                  }`}
                >
                  <span className="opacity-50 font-mono">{idx + 1}</span>
                  <span className="truncate">{chap.title}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="border-t border-dashed border-stone-400/50" />

          <div>
            <h2 className="text-lg font-serif font-medium mb-3">
              Bookmarks ({bookmarks.length})
            </h2>
            <ul className="space-y-2 text-xs">
              {bookmarks.map((bm, i) => (
                <li
                  key={`${bm.id}-${i}`}
                  onClick={() => {
                    const safeP = Math.max(0, Math.min(bm.page, pages.length - 1));
                    const safeL = Math.max(0, Math.min(bm.line, (pages[safeP]?.length ?? 1) - 1));
                    const rowSegs = pages[safeP]?.[safeL]?.segments ?? [];
                    const validCid = rowSegs.some((s) => s.clauseId === bm.id)
                      ? bm.id
                      : rowSegs[0]?.clauseId ?? 0;

                    setPageIdx(safeP);
                    setActiveLineIdx(safeL);
                    setActiveClauseId(validCid);
                    setClauseMenuOpen(false);
                    stateRef.current.currentLine = safeL;
                    stateRef.current.currentClauseId = validCid;
                    setLeftSidebarOpen(false);
                    showToast("Jumped to Bookmark", `Page ${safeP + 1} · Row ${safeL + 1}`);
                  }}
                  className="flex items-center justify-between gap-2 cursor-pointer py-1.5 px-2 rounded-lg opacity-75 hover:opacity-100 hover:bg-stone-500/10 group"
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className="opacity-50 font-mono">{i + 1}</span>
                    <span className="truncate group-hover:font-medium">{bm.text}</span>
                  </div>
                  <span className="opacity-50 group-hover:opacity-100">‹</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </aside>

      {/* ==================== Subtle Transparent Bottom-Left Vertical Sliders Bar ==================== */}
      {/* Expand button is ABOVE the slider(s), borderless, with no dismissible 'X' item when expanded */}
      {showBottomLeftBar && (
        <div
          onPointerEnter={() => {
            uiInteractingRef.current = true;
          }}
          onPointerLeave={() => {
            if (!isDraggingSliderRef.current) uiInteractingRef.current = false;
          }}
          className={`fixed left-6 bottom-4 z-20 flex flex-col items-center transition-all duration-200 ${
            bottomLeftExpanded
              ? isNight
                ? "px-4 py-3 rounded-2xl bg-stone-900/45 backdrop-blur-md"
                : "px-4 py-3 rounded-2xl bg-white/40 backdrop-blur-md"
              : "p-1 bg-transparent"
          }`}
        >
          {/* Borderless Expand/Collapse Button placed ABOVE the vertical slider(s) */}
          <button
            type="button"
            onClick={() => setBottomLeftExpanded((v) => !v)}
            className="bg-transparent border-0 p-1 mb-1.5 text-xs opacity-55 hover:opacity-100 transition leading-none"
            title={bottomLeftExpanded ? "Collapse" : "Expand"}
          >
            {bottomLeftExpanded ? "<" : ">"}
          </button>

          {/* Vertical sliders row */}
          <div className="flex items-center gap-4">
            {(bottomLeftExpanded
              ? [
                  { label: "Next", val: nextLineSlider, min: 15, max: 95, set: setNextLineSlider },
                  { label: "Prev", val: prevLineSlider, min: 5, max: 90, set: setPrevLineSlider },
                  { label: "Skip", val: skipLinesSlider, min: 5, max: 90, set: setSkipLinesSlider },
                ]
              : [{ label: "Next", val: nextLineSlider, min: 15, max: 95, set: setNextLineSlider }]
            ).map((sl) => (
              <div key={sl.label} className="flex flex-col items-center gap-1.5">
                {bottomLeftExpanded && (
                  <span className="text-[11px] font-mono tabular-nums opacity-70 leading-none">
                    {sl.val}
                  </span>
                )}
                <div className="w-5 h-24 flex items-center justify-center">
                  <input
                    type="range"
                    min={sl.min}
                    max={sl.max}
                    value={sl.val}
                    onPointerDown={() => {
                      isDraggingSliderRef.current = true;
                      uiInteractingRef.current = true;
                    }}
                    onChange={(e) => sl.set(Number(e.target.value))}
                    title={`${sl.label} Line Sensitivity: ${sl.val}`}
                    className="w-24 h-1 -rotate-90 accent-stone-700/70 bg-stone-400/25 rounded-lg cursor-pointer opacity-65 hover:opacity-100 transition-opacity shrink-0"
                  />
                </div>
                {bottomLeftExpanded && (
                  <span className="text-[10px] font-medium tracking-wide opacity-60 leading-none">
                    {sl.label}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==================== Widened Right Sidebar (Draggable Cards) ==================== */}
      <aside
        onPointerEnter={() => {
          uiInteractingRef.current = true;
        }}
        onPointerLeave={() => {
          if (!isDraggingSliderRef.current && !draggingCardId) uiInteractingRef.current = false;
        }}
        className={`fixed top-4 bottom-4 right-4 w-96 z-30 overflow-y-auto space-y-3 pr-1 transition-transform duration-300 ${
          rightSidebarOpen ? "translate-x-0" : "translate-x-[120%]"
        }`}
      >
        {rightCardOrder.map((cardId) => renderRightSidebarCard(cardId))}
      </aside>

      {/* ==================== Main Reading Viewport (60% Default Width, Single-Row Contiguous Highlight) ==================== */}
      <main
        onPointerMove={(e) => {
          if (noCameraMode || !isCalibrated) {
            setGazePoint((prev) => ({
              ...prev,
              x: e.clientX,
              y: e.clientY,
            }));
          }
        }}
        className="flex-1 w-full flex flex-col items-center justify-center py-2 relative z-10"
      >
        <div
          style={{ width: `${readingWidthPct}%` }}
          className="relative transition-all duration-150"
        >
          <div className="flex items-center justify-between mb-3">
            <h1
              className="font-serif opacity-65 tracking-tight truncate"
              style={{
                fontSize: Math.round(fontSize * 1.7),
                fontFamily: fontFamily === "Inter" ? "Inter, sans-serif" : "Georgia, serif",
              }}
            >
              {currentChapterTitle}
            </h1>
          </div>

          <div
            ref={rowsContainerRef}
            style={{ minHeight: ROWS_PER_PAGE * lineHeightPx }}
            className="w-full relative"
          >
            {currentLines.map((line, idx) => {
              const distFromActive = idx - activeLineIdx;
              const lineOpacity =
                distFromActive === 0
                  ? 1
                  : distFromActive < 0
                  ? Math.max(0.32, 0.76 + distFromActive * 0.12)
                  : distFromActive <= 2
                  ? 0.9
                  : Math.max(0.36, 0.86 - (distFromActive - 2) * 0.1);

              const rowBlurFilter =
                bgBlur && Math.abs(distFromActive) > 1 ? "blur(2.2px)" : "none";

              return (
                <div
                  key={idx}
                  style={{
                    height: lineHeightPx,
                    opacity: lineOpacity,
                    filter: rowBlurFilter,
                  }}
                  className="relative flex items-center transition-all duration-200"
                >
                  {/* Spatial Visual Reticle */}
                  {showReticle && idx === activeLineIdx && (
                    <span
                      className="absolute -left-5 w-3.5 h-3.5 rounded-full border border-sky-500/70 flex items-center justify-center pointer-events-none"
                      title="Spatial Visual Reticle"
                    >
                      <span className="w-1 h-1 rounded-full bg-sky-500" />
                    </span>
                  )}

                  <div
                    className="flex items-center whitespace-pre relative"
                    style={{ font: getFontCssString(fontSize) }}
                  >
                    {line.segments.map((seg, sIdx) => {
                      // Strictly single-row highlight: prevents split selection across upper & lower rows
                      const isSentenceHighlighted =
                        idx === activeLineIdx && seg.clauseId === activeClauseId;

                      // Mouth-open (or double-click) summons selection box + quick action bar on this single active unit
                      const isMouthSelected = clauseMenuOpen && isSentenceHighlighted;

                      const isPersistentHighlighted = highlightedClauses.has(seg.clauseId);
                      const isUnderlined = underlinedClauses.has(seg.clauseId);

                      const words = seg.text.split(" ");
                      const focusStartWord = Math.max(0, Math.floor(words.length * 0.25));
                      const focusEndWord = Math.min(words.length - 1, focusStartWord + 3);

                      return (
                        <React.Fragment key={sIdx}>
                          <span
                            onClick={() => {
                              stateRef.current.currentLine = idx;
                              stateRef.current.currentClauseId = seg.clauseId;
                              stateRef.current.lineEnterTime = performance.now();
                              stateRef.current.reachedRightZone = false;
                              stateRef.current.maxLineX = 0;
                              setActiveLineIdx(idx);
                              setActiveClauseId(seg.clauseId);
                              setClauseMenuOpen(false);
                            }}
                            onDoubleClick={() => {
                              stateRef.current.currentLine = idx;
                              stateRef.current.currentClauseId = seg.clauseId;
                              setActiveLineIdx(idx);
                              setActiveClauseId(seg.clauseId);
                              setClauseMenuOpen((v) => !v);
                            }}
                            className={`relative inline-flex items-center rounded-md px-1 -mx-1 py-0.5 transition-colors duration-150 cursor-pointer ${
                              isSentenceHighlighted
                                ? isNight
                                  ? "bg-indigo-500/30 text-white border-b border-indigo-400 shadow-[0_0_10px_rgba(99,102,241,0.25)] z-10"
                                  : "bg-white/85 text-stone-950 border-b border-stone-400 shadow-[0_0_16px_rgba(255,255,255,0.95)] z-10"
                                : isPersistentHighlighted
                                ? isNight
                                  ? "bg-amber-500/25 text-amber-100"
                                  : "bg-amber-200/60 text-stone-900"
                                : ""
                            } ${isUnderlined ? "underline decoration-2 underline-offset-4" : ""}`}
                          >
                            {isMouthSelected
                              ? words.map((w, wIdx) => {
                                  const inSelectionBox =
                                    wIdx >= focusStartWord && wIdx <= focusEndWord;
                                  return (
                                    <span
                                      key={wIdx}
                                      className={
                                        inSelectionBox
                                          ? "bg-[#7ba3bd]/65 text-stone-950 rounded-sm px-0.5 -mx-0.5"
                                          : ""
                                      }
                                    >
                                      {w}
                                      {wIdx < words.length - 1 ? " " : ""}
                                    </span>
                                  );
                                })
                              : seg.text}

                            {/* Quick Action Menu summoned together with selection box on mouth open */}
                            {isMouthSelected && (
                              <span
                                onClick={(e) => e.stopPropagation()}
                                className={`absolute left-1/2 -translate-x-1/2 top-full mt-1.5 z-30 h-8 px-3.5 rounded-full border shadow-lg backdrop-blur-md flex items-center gap-4 whitespace-nowrap ${unifiedSurfaceClass}`}
                              >
                                {menuShowBookmark && (
                                  <button
                                    type="button"
                                    onClick={addBookmarkForActiveClause}
                                    className="opacity-80 hover:opacity-100 transition flex items-center gap-1 text-xs"
                                    title="Bookmark Sentence"
                                  >
                                    <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                      <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
                                    </svg>
                                    <span>Bookmark</span>
                                  </button>
                                )}

                                {menuShowHighlight && (
                                  <>
                                    <button
                                      type="button"
                                      onClick={toggleHighlightActiveClause}
                                      className="opacity-80 hover:opacity-100 transition text-xs font-semibold"
                                      title="Highlight Sentence"
                                    >
                                      Highlight
                                    </button>
                                    <button
                                      type="button"
                                      onClick={toggleUnderlineActiveClause}
                                      className="opacity-80 hover:opacity-100 transition font-serif font-bold text-xs underline underline-offset-2"
                                      title="Underline Sentence"
                                    >
                                      U
                                    </button>
                                  </>
                                )}

                                {menuShowNotes && (
                                  <button
                                    type="button"
                                    onClick={addActiveSentenceToNotes}
                                    className="opacity-80 hover:opacity-100 transition text-xs"
                                    title="Add Sentence to Notes"
                                  >
                                    Note
                                  </button>
                                )}

                                <button
                                  type="button"
                                  onClick={copyActiveClause}
                                  className="opacity-80 hover:opacity-100 transition"
                                  title="Copy Sentence"
                                >
                                  <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                                  </svg>
                                </button>
                              </span>
                            )}
                          </span>
                          {seg.isClauseEnd && <span style={{ width: CLAUSE_GAP_PX }} />}
                        </React.Fragment>
                      );
                    })}
                  </div>

                  {/* Weak-contrast row stats badge (hidden by default) */}
                  {showRowMeta && (
                    <span
                      className={`absolute left-full ml-2.5 whitespace-nowrap text-[10px] font-mono tabular-nums px-2 py-0.5 rounded border pointer-events-none ${rowBadgeWeakContrastClass}`}
                    >
                      {line.clauseCount} sent · {line.wordCount} w | {Math.round(line.widthRatio * 100)}%
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </main>

      {/* Direct Gaze-Following Cursor */}
      {showGazeCursor && !isCalibrating && (isCalibrated || noCameraMode) && (
        <div className="pointer-events-none fixed inset-0 z-30">
          <div
            className="w-4 h-4 -ml-2 -mt-2 rounded-full bg-indigo-500/75 border border-white/90 shadow-[0_0_12px_rgba(99,102,241,0.85)] transition-transform duration-75"
            style={{ transform: `translate3d(${gazePoint.x}px, ${gazePoint.y}px, 0)` }}
          />
        </div>
      )}

      {/* ==================== Bottom Toasts & Return Confirmation Sheet ==================== */}

      {statusToast && (
        <div
          className={`fixed bottom-11 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl border backdrop-blur-md flex items-center gap-2.5 text-xs transition-all whitespace-nowrap ${unifiedSurfaceClass}`}
        >
          <span className="w-2 h-2 rounded-full bg-stone-800 shrink-0" />
          <span className="font-medium">{statusToast.title}</span>
          {statusToast.detail && (
            <span className="opacity-70 border-l border-stone-400/40 pl-2.5 max-w-md truncate">
              {statusToast.detail}
            </span>
          )}
        </div>
      )}

      {showReturnConfirm && (
        <div
          className={`fixed bottom-11 left-1/2 -translate-x-1/2 z-50 w-full max-w-xl p-4 rounded-2xl border backdrop-blur-md flex items-center justify-between gap-4 ${unifiedSurfaceClass}`}
        >
          <div className="space-y-1">
            <div className="text-xs font-semibold flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              <span>Welcome Back · Reading Timer Paused</span>
            </div>
            <p className="text-[11px] opacity-75 leading-relaxed">
              Paused at Page {pageIdx + 1}, Row {activeLineIdx + 1} ({formatTime(readingSeconds)} recorded). Click Resume or nod/open mouth to continue timing.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setShowReturnConfirm(false)}
              className={`px-3 py-1.5 rounded-xl border text-xs transition ${unifiedSubtleBoxClass}`}
            >
              Stay Paused
            </button>
            <button
              type="button"
              onClick={() => {
                setIsOffScreenPaused(false);
                setShowReturnConfirm(false);
                setMultimodalTriggerState("Timer Resumed");
              }}
              className="px-3.5 py-1.5 rounded-xl bg-stone-900 text-white text-xs font-medium hover:bg-stone-800 transition"
            >
              Resume Timer
            </button>
          </div>
        </div>
      )}

      {!isCalibrated && !isCalibrating && !showReturnConfirm && !statusToast && !dismissGuideBanner && (
        <div
          className={`fixed bottom-10 left-1/2 -translate-x-1/2 z-20 px-4 py-1.5 rounded-full border backdrop-blur-sm flex items-center gap-3 text-[11px] whitespace-nowrap ${unifiedSubtleBoxClass}`}
        >
          <span>
            {noCameraMode
              ? "No-Camera Mode: Click any sentence to focus, or double-click to summon the selection box and quick menu."
              : "Tip: Gaze highlights sentences on the active row; open your mouth (or double-click) to summon the selection box and quick menu."}
          </span>
          <button
            type="button"
            onClick={() => setDismissGuideBanner(true)}
            className="opacity-50 hover:opacity-100 px-1"
            title="Dismiss"
          >
            ✕
          </button>
        </div>
      )}

      {/* ==================== Minimal Footer Pagination ==================== */}
      <footer className="h-10 flex items-center justify-center gap-6 text-xs z-10 shrink-0 tabular-nums">
        <button
          type="button"
          disabled={pageIdx <= 0}
          onClick={() => {
            const prevP = Math.max(0, pageIdx - 1);
            const firstCid = pages[prevP]?.[0]?.segments?.[0]?.clauseId ?? 0;
            setPageIdx(prevP);
            setActiveLineIdx(0);
            setActiveClauseId(firstCid);
            setClauseMenuOpen(false);
            stateRef.current.currentLine = 0;
            stateRef.current.currentClauseId = firstCid;
            stateRef.current.reachedRightZone = false;
            stateRef.current.maxLineX = 0;
          }}
          className="opacity-50 hover:opacity-100 disabled:opacity-20 px-2"
        >
          ‹
        </button>
        <span className="font-serif text-sm opacity-80">
          {pageIdx + 1} / {Math.max(1, pages.length)}
        </span>
        <button
          type="button"
          disabled={pageIdx >= pages.length - 1}
          onClick={() => {
            const nextP = Math.min(pages.length - 1, pageIdx + 1);
            const firstCid = pages[nextP]?.[0]?.segments?.[0]?.clauseId ?? 0;
            setPageIdx(nextP);
            setActiveLineIdx(0);
            setActiveClauseId(firstCid);
            setClauseMenuOpen(false);
            stateRef.current.currentLine = 0;
            stateRef.current.currentClauseId = firstCid;
            stateRef.current.reachedRightZone = false;
            stateRef.current.maxLineX = 0;
          }}
          className="opacity-50 hover:opacity-100 disabled:opacity-20 px-2"
        >
          ›
        </button>
      </footer>

      {/* ==================== Modals ==================== */}

      {buyModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/35 backdrop-blur-[2px] flex items-center justify-center p-4">
          <div className={`rounded-2xl max-w-md w-full p-6 border space-y-4 ${unifiedSurfaceClass}`}>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[11px] opacity-55">Single Book Edition</div>
                <h3 className="text-lg font-serif font-medium">Purchase Full Digital Edition</h3>
              </div>
              <button type="button" onClick={() => setBuyModalOpen(false)} className="opacity-50 hover:opacity-100">
                ✕
              </button>
            </div>

            <div className={`p-3.5 rounded-xl border text-xs space-y-1.5 ${unifiedSubtleBoxClass}`}>
              <div className="font-medium">Book: &ldquo;{currentChapterTitle}&rdquo;</div>
              <ul className="space-y-1 opacity-80 list-disc list-inside text-[11px]">
                <li>Full access to all chapters and unlimited local TXT imports</li>
                <li>Real-time WPM/CPM analytics and gaze heatmap overlays</li>
                <li>Sentence highlights, notes export, and TTS audio</li>
              </ul>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div>
                <span className="text-xl font-serif font-semibold">$4.99</span>
                <span className="text-[11px] opacity-55 ml-1.5">One-time purchase</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setBuyModalOpen(false)}
                  className={`px-3.5 py-1.5 rounded-xl border text-xs ${unifiedSubtleBoxClass}`}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsPurchased(true);
                    setBuyModalOpen(false);
                    showToast("Purchase Complete", `Unlocked full edition of "${currentChapterTitle}"`);
                  }}
                  className="px-4 py-1.5 rounded-xl bg-stone-900 text-white text-xs font-medium hover:bg-stone-800"
                >
                  {isPurchased ? "✓ Unlocked" : "Buy Now"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {notesModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/35 backdrop-blur-[2px] flex items-center justify-center p-4">
          <div className={`rounded-2xl max-w-lg w-full p-6 border space-y-4 ${unifiedSurfaceClass}`}>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[11px] opacity-55">Notes, Highlights & Local TXT</div>
                <h3 className="text-lg font-serif font-medium">Reading Notes & Highlights</h3>
              </div>
              <button type="button" onClick={() => setNotesModalOpen(false)} className="opacity-50 hover:opacity-100">
                ✕
              </button>
            </div>

            <div className="space-y-1.5">
              <div className="text-xs font-medium opacity-75">
                Highlighted Sentences ({highlightedClauses.size})
              </div>
              <div className="max-h-28 overflow-y-auto space-y-1.5 pr-1">
                {highlightedClauses.size === 0 ? (
                  <div className={`p-2.5 rounded-xl border text-[11px] opacity-60 ${unifiedSubtleBoxClass}`}>
                    No highlighted sentences yet. Open your mouth (or double-click a sentence) and click &ldquo;Highlight&rdquo;.
                  </div>
                ) : (
                  Array.from(highlightedClauses).map((cid) => {
                    const sentText = getSentenceTextById(cid) || `Sentence #${cid + 1}`;
                    return (
                      <div
                        key={cid}
                        className={`p-2 rounded-xl border text-xs flex items-center justify-between gap-2 ${unifiedSubtleBoxClass}`}
                      >
                        <span className="truncate">{sentText}</span>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard?.writeText(sentText);
                              showToast("Highlight Copied");
                            }}
                            className="text-[10px] opacity-65 hover:opacity-100 px-1"
                          >
                            Copy
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setHighlightedClauses((prev) => {
                                const next = new Set(prev);
                                next.delete(cid);
                                return next;
                              });
                            }}
                            className="text-[10px] text-rose-500 hover:underline px-1"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="text-xs font-medium opacity-75">Add or Paste Reading Note</div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={noteInputText}
                  onChange={(e) => setNoteInputText(e.target.value)}
                  placeholder="Type a note or click Paste..."
                  className={`flex-1 px-3 py-1.5 rounded-xl border text-xs focus:outline-none ${unifiedSubtleBoxClass}`}
                />
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      const clip = await navigator.clipboard.readText();
                      if (clip) {
                        setNoteInputText((prev) => prev + clip);
                        showToast("Pasted from Clipboard");
                      }
                    } catch {
                      showToast("Use Ctrl+V to paste");
                    }
                  }}
                  className={`px-2.5 py-1.5 rounded-xl border text-xs ${unifiedSubtleBoxClass}`}
                >
                  Paste
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (!noteInputText.trim()) return;
                    setNotesList((prev) => [noteInputText.trim(), ...prev]);
                    setNoteInputText("");
                    showToast("Note Saved");
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-stone-900 text-white text-xs font-medium"
                >
                  Save
                </button>
              </div>
            </div>

            <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1 text-xs">
              {notesList.map((n, i) => (
                <div
                  key={i}
                  className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 ${unifiedSubtleBoxClass}`}
                >
                  <span className="leading-relaxed">{n}</span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText(n);
                      showToast("Note Copied");
                    }}
                    className="text-[10px] opacity-60 hover:opacity-100 shrink-0 px-1.5 py-0.5 rounded border border-stone-400/30"
                  >
                    Copy
                  </button>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-stone-300/40 flex items-center justify-between">
              <label className="px-3.5 py-2 rounded-xl bg-stone-900 text-white text-xs font-medium cursor-pointer hover:bg-stone-800 transition">
                Import Local TXT File
                <input type="file" accept=".txt" onChange={handleFileUpload} className="hidden" />
              </label>
              <button
                type="button"
                onClick={() => setNotesModalOpen(false)}
                className={`px-4 py-2 rounded-xl border text-xs ${unifiedSubtleBoxClass}`}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 9-Point Full-Screen Calibration Overlay: Always Dark (bg-slate-950/95) */}
      {isCalibrating && (
        <div className="fixed inset-0 z-50 bg-slate-950/95 text-slate-100 flex flex-col items-center justify-center">
          <p className="text-slate-300 text-lg mb-2">
            Keep a natural reading posture — <strong>look at and click</strong> the glowing target ({calibStep + 1} / 9)
          </p>
          <p className="text-slate-500 text-sm mb-4">
            Hold your gaze steady on the target for ~0.5s after clicking ({calibSampleProgress}%)
          </p>
          <button
            type="button"
            onClick={() => {
              collectingPointRef.current = null;
              setCalibSampleProgress(0);
              setIsCalibrating(false);
            }}
            className="px-3.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700"
          >
            Exit Calibration
          </button>
          {CALIBRATION_POINTS.map(([rx, ry], idx) => {
            if (idx !== calibStep) return null;
            const px = typeof window !== "undefined" ? Math.round(rx * window.innerWidth) : 0;
            const py = typeof window !== "undefined" ? Math.round(ry * window.innerHeight) : 0;
            return (
              <button
                type="button"
                key={idx}
                onClick={() => handleCalibPointClick(px, py)}
                style={{ left: `${rx * 100}%`, top: `${ry * 100}%` }}
                className="fixed -ml-6 -mt-6 w-12 h-12 rounded-full bg-indigo-500/30 border-2 border-indigo-400 flex items-center justify-center animate-pulse cursor-crosshair"
              >
                <span className="w-3.5 h-3.5 rounded-full bg-amber-400" />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}