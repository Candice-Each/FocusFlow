"use client";

import React, { useEffect, useRef, useState, useCallback } from "react";
import { FaceLandmarker, FilesetResolver, FaceLandmarkerResult } from "@mediapipe/tasks-vision";

// ==================== 0. 模块顶层拦截 WASM INFO 日志 ====================
// 必须在模块顶层执行且永不卸载，防止 React Strict Mode 卸载间隙被 Emscripten 绑定原始 console.error
if (typeof window !== "undefined" && !(window as unknown as { __mpErrFiltered?: boolean }).__mpErrFiltered) {
  (window as unknown as { __mpErrFiltered?: boolean }).__mpErrFiltered = true;
  const origError = window.console.error.bind(window.console);
  window.console.error = (...args: unknown[]) => {
    const msg = args.map((a) => (typeof a === "string" ? a : "")).join(" ");
    if (
      msg.includes("INFO:") ||
      msg.includes("WARNING:") ||
      msg.includes("XNNPACK") ||
      msg.includes("Created TensorFlow Lite") ||
      msg.includes("gl_context")
    ) {
      return;
    }
    origError(...args);
  };
}

// ==================== 1. 信号滤波、岭回归与热力图 LUT ====================

class OneEuroFilter {
  private xPrev: number | null = null;
  private dxPrev = 0;
  private tPrev: number | null = null;

  constructor(private minCutoff = 0.8, private beta = 0.015, private dCutoff = 1.0) {}

  private alpha(cutoff: number, dt: number): number {
    const tau = 1.0 / (2 * Math.PI * cutoff);
    return 1.0 / (1.0 + tau / dt);
  }

  filter(x: number, tMs: number): number {
    if (this.tPrev === null || this.xPrev === null) {
      this.xPrev = x;
      this.tPrev = tMs;
      return x;
    }
    const dt = Math.max((tMs - this.tPrev) / 1000, 1e-4);
    this.tPrev = tMs;

    const dx = (x - this.xPrev) / dt;
    const edx = this.dxPrev + this.alpha(this.dCutoff, dt) * (dx - this.dxPrev);
    this.dxPrev = edx;

    const cutoff = this.minCutoff + this.beta * Math.abs(edx);
    const filtered = this.xPrev + this.alpha(cutoff, dt) * (x - this.xPrev);
    this.xPrev = filtered;
    return filtered;
  }
}

function solveRidgeRegression(X: number[][], Y: number[][], lambda = 0.05): number[][] {
  const n = X.length;
  const d = X[0].length;
  const outDim = Y[0].length;

  const A = Array.from({ length: d }, (_, i) =>
    Array.from({ length: d }, (_, j) => {
      let sum = 0;
      for (let k = 0; k < n; k++) sum += X[k][i] * X[k][j];
      if (i === j) sum += i === 0 ? 1e-7 : lambda;
      return sum;
    })
  );

  const B = Array.from({ length: d }, (_, i) =>
    Array.from({ length: outDim }, (_, j) => {
      let sum = 0;
      for (let k = 0; k < n; k++) sum += X[k][i] * Y[k][j];
      return sum;
    })
  );

  const aug = A.map((row, i) => [...row, ...B[i]]);
  for (let col = 0; col < d; col++) {
    let pivot = col;
    for (let row = col + 1; row < d; row++) {
      if (Math.abs(aug[row][col]) > Math.abs(aug[pivot][col])) pivot = row;
    }
    [aug[col], aug[pivot]] = [aug[pivot], aug[col]];

    const div = aug[col][col] || 1e-8;
    for (let j = col; j < d + outDim; j++) aug[col][j] /= div;

    for (let row = 0; row < d; row++) {
      if (row !== col) {
        const factor = aug[row][col];
        for (let j = col; j < d + outDim; j++) aug[row][j] -= factor * aug[col][j];
      }
    }
  }
  return aug.map((row) => row.slice(d));
}

// 预计算 256 阶伪彩色热力查找表 (Little-Endian ABGR)
const HEAT_W = 240;
const HEAT_H = 135;
const HEATMAP_LUT = (() => {
  const lut = new Uint32Array(256);
  for (let v = 0; v < 256; v++) {
    if (v < 3) {
      lut[v] = 0;
      continue;
    }
    let r = 0, g = 0, b = 0;
    if (v < 64) {
      b = 255;
      g = v * 4;
    } else if (v < 128) {
      g = 255;
      b = 255 - (v - 64) * 4;
    } else if (v < 192) {
      g = 255;
      r = (v - 128) * 4;
    } else {
      r = 255;
      g = Math.max(0, 255 - (v - 192) * 4);
    }
    const a = Math.min(215, Math.round(v * 0.92));
    lut[v] = (a << 24) | (b << 16) | (g << 8) | r;
  }
  return lut;
})();

// ==================== 2. 眼动+面部3D姿态提取与点线拓扑绘制 ====================

function projectEyeLocal(lm: { x: number; y: number }[], outer: number, inner: number, iris: number) {
  const dx = lm[inner].x - lm[outer].x;
  const dy = lm[inner].y - lm[outer].y;
  const len = Math.hypot(dx, dy) || 1e-5;
  const ux = dx / len;
  const uy = dy / len;
  const ix = lm[iris].x - lm[outer].x;
  const iy = lm[iris].y - lm[outer].y;
  return {
    u: (ix * ux + iy * uy) / len,
    v: (-ix * uy + iy * ux) / len,
  };
}

interface GazeTelemetry {
  features: number[];
  yawDeg: number;
  pitchDeg: number;
  rollDeg: number;
  blink: number;
  rU: number;
  rV: number;
  lU: number;
  lV: number;
  lookH: number;
  lookV: number;
}

function extractGazeTelemetry(res: FaceLandmarkerResult): GazeTelemetry | null {
  const lm = res.faceLandmarks?.[0];
  const bs = res.faceBlendshapes?.[0]?.categories;
  const mat = res.facialTransformationMatrixes?.[0]?.data;
  if (!lm || lm.length < 478 || !bs || !mat) return null;

  const getBs = (name: string) => bs.find((c) => c.categoryName === name)?.score ?? 0;
  const blink = Math.max(getBs("eyeBlinkLeft"), getBs("eyeBlinkRight"));

  const rEye = projectEyeLocal(lm, 33, 133, 468);
  const lEye = projectEyeLocal(lm, 362, 263, 473);

  const lookHoriz =
    getBs("eyeLookOutLeft") - getBs("eyeLookInLeft") +
    (getBs("eyeLookInRight") - getBs("eyeLookOutRight"));
  const lookVert =
    getBs("eyeLookDownLeft") + getBs("eyeLookDownRight") -
    (getBs("eyeLookUpLeft") + getBs("eyeLookUpRight"));

  const pitch = Math.asin(Math.max(-1, Math.min(1, -mat[6])));
  const yaw = Math.atan2(mat[2], mat[10]);
  const roll = Math.atan2(mat[4], mat[5]);
  const tx = mat[12] * 0.05;
  const ty = mat[13] * 0.05;
  const tz = (mat[14] + 50) * 0.02;

  const uMean = (rEye.u + lEye.u) * 0.5;
  return {
    features: [
      1,
      rEye.u, rEye.v,
      lEye.u, lEye.v,
      lookHoriz, lookVert,
      yaw, pitch, roll,
      tx, ty, tz,
      uMean * yaw,
    ],
    yawDeg: Math.round((yaw * 180) / Math.PI),
    pitchDeg: Math.round((pitch * 180) / Math.PI),
    rollDeg: Math.round((roll * 180) / Math.PI),
    blink,
    rU: rEye.u,
    rV: rEye.v,
    lU: lEye.u,
    lV: lEye.v,
    lookH: lookHoriz,
    lookV: lookVert,
  };
}

// 面部关键拓扑轮廓索引集
const FACE_OVAL = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109, 10];
const RIGHT_EYE_LOOP = [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246, 33];
const LEFT_EYE_LOOP = [362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398, 362];
const RIGHT_EYEBROW = [46, 53, 52, 65, 55, 70, 63, 105, 66, 107];
const LEFT_EYEBROW = [276, 283, 282, 295, 285, 300, 293, 334, 296, 336];
const NOSE_BRIDGE = [168, 6, 197, 195, 5, 4, 1];
const LIPS_OUTER = [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185, 61];

function drawFaceAndEyeMesh(
  canvas: HTMLCanvasElement,
  res: FaceLandmarkerResult,
  tel: GazeTelemetry | null,
  video: HTMLVideoElement,
  showVideoBg: boolean
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const W = canvas.width;
  const H = canvas.height;
  ctx.clearRect(0, 0, W, H);

  // 背景：可选叠加半透明镜像视频或纯黑科技网格
  if (showVideoBg) {
    ctx.save();
    ctx.translate(W, 0);
    ctx.scale(-1, 1);
    ctx.globalAlpha = 0.35;
    ctx.drawImage(video, 0, 0, W, H);
    ctx.restore();
  } else {
    ctx.strokeStyle = "rgba(30, 41, 59, 0.55)";
    ctx.lineWidth = 1;
    for (let x = 0; x < W; x += 24) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
    for (let y = 0; y < H; y += 24) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }
  }

  const lm = res.faceLandmarks?.[0];
  if (!lm) {
    ctx.fillStyle = "#f43f5e";
    ctx.font = "12px monospace";
    ctx.fillText("未检测到面部特征点", 12, 22);
    return;
  }

  // 镜像映射坐标 (与真人照镜子方向一致)
  const px = (idx: number) => (1 - lm[idx].x) * W;
  const py = (idx: number) => lm[idx].y * H;

  const strokePath = (indices: number[], color: string, width = 1.2) => {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.beginPath();
    indices.forEach((id, i) => {
      if (i === 0) ctx.moveTo(px(id), py(id));
      else ctx.lineTo(px(id), py(id));
    });
    ctx.stroke();
  };

  // 1. 绘制全脸 468 个基础特征微点
  ctx.fillStyle = "rgba(148, 163, 184, 0.35)";
  for (let i = 0; i < 468; i += 2) {
    ctx.fillRect(px(i) - 0.7, py(i) - 0.7, 1.4, 1.4);
  }

  // 2. 绘制面部结构连线
  strokePath(FACE_OVAL, "rgba(99, 102, 241, 0.55)", 1.2);
  strokePath(RIGHT_EYEBROW, "rgba(148, 163, 184, 0.6)", 1.2);
  strokePath(LEFT_EYEBROW, "rgba(148, 163, 184, 0.6)", 1.2);
  strokePath(NOSE_BRIDGE, "rgba(56, 189, 248, 0.65)", 1.3);
  strokePath(LIPS_OUTER, "rgba(148, 163, 184, 0.5)", 1.1);

  // 3. 绘制左右眼眶轮廓与内外眼角刚性基准轴（青色）
  strokePath(RIGHT_EYE_LOOP, "#38bdf8", 1.4);
  strokePath(LEFT_EYE_LOOP, "#38bdf8", 1.4);
  strokePath([33, 133], "rgba(34, 211, 238, 0.85)", 1.5);
  strokePath([362, 263], "rgba(34, 211, 238, 0.85)", 1.5);

  // 4. 绘制左右虹膜环 (469~472, 474~477) 与瞳孔中心十字准星 (468, 473)
  strokePath([469, 470, 471, 472, 469], "#f59e0b", 1.6);
  strokePath([474, 475, 476, 477, 474], "#f59e0b", 1.6);

  [468, 473].forEach((irisIdx) => {
    const cx = px(irisIdx);
    const cy = py(irisIdx);
    ctx.fillStyle = "#fbbf24";
    ctx.beginPath();
    ctx.arc(cx, cy, 2.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#fde047";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx - 6, cy); ctx.lineTo(cx + 6, cy);
    ctx.moveTo(cx, cy - 6); ctx.lineTo(cx, cy + 6);
    ctx.stroke();
  });

  // 5. 绘制 3D 头部姿态向量（洋红色）与双眼视线方向向量射线（亮绿色）
  if (tel) {
    const noseX = px(168);
    const noseY = py(168);
    const headEndX = noseX - Math.sin((tel.yawDeg * Math.PI) / 180) * 55;
    const headEndY = noseY + Math.sin((tel.pitchDeg * Math.PI) / 180) * 55;
    ctx.strokeStyle = "#f43f5e";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(noseX, noseY);
    ctx.lineTo(headEndX, headEndY);
    ctx.stroke();

    // 左右瞳孔投射视线向量射线
    const rayDx = -tel.lookH * 42 - Math.sin((tel.yawDeg * Math.PI) / 180) * 35;
    const rayDy = tel.lookV * 48 + Math.sin((tel.pitchDeg * Math.PI) / 180) * 35;
    ctx.strokeStyle = "#10b981";
    ctx.lineWidth = 2;
    [468, 473].forEach((id) => {
      ctx.beginPath();
      ctx.moveTo(px(id), py(id));
      ctx.lineTo(px(id) + rayDx, py(id) + rayDy);
      ctx.stroke();
    });

    // 顶部实时遥测 HUD
    ctx.fillStyle = "rgba(2, 6, 23, 0.78)";
    ctx.fillRect(6, 6, 206, 52);
    ctx.fillStyle = "#e2e8f0";
    ctx.font = "11px monospace";
    ctx.fillText(`Head Y/P/R: ${tel.yawDeg}° / ${tel.pitchDeg}° / ${tel.rollDeg}°`, 12, 22);
    ctx.fillStyle = "#38bdf8";
    ctx.fillText(`Iris U/V  : ${tel.rU.toFixed(2)}, ${tel.rV.toFixed(2)}`, 12, 37);
    ctx.fillStyle = tel.blink > 0.5 ? "#f43f5e" : "#10b981";
    ctx.fillText(`Blink Score: ${tel.blink.toFixed(2)} ${tel.blink > 0.5 ? "[眨眼拦截]" : "[正常]"}`, 12, 52);
  }
}

// ==================== 3. 通用可自由拖拽与缩放浮动小窗组件 ====================

interface WinState {
  visible: boolean;
  x: number;
  y: number;
  w: number;
  h: number;
}

function FloatingWindow({
  title,
  winState,
  setWinState,
  minW = 200,
  minH = 150,
  headerExtra,
  children,
}: {
  title: string;
  winState: WinState;
  setWinState: React.Dispatch<React.SetStateAction<WinState>>;
  minW?: number;
  minH?: number;
  headerExtra?: React.ReactNode;
  children: React.ReactNode;
}) {
  const startDrag = (e: React.PointerEvent) => {
    e.preventDefault();
    const startX = e.clientX - winState.x;
    const startY = e.clientY - winState.y;
    const onMove = (ev: PointerEvent) => {
      setWinState((prev) => ({
        ...prev,
        x: Math.max(0, Math.min(window.innerWidth - 80, ev.clientX - startX)),
        y: Math.max(0, Math.min(window.innerHeight - 40, ev.clientY - startY)),
      }));
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };

  const startResize = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startY = e.clientY;
    const origW = winState.w;
    const origH = winState.h;
    const onMove = (ev: PointerEvent) => {
      setWinState((prev) => ({
        ...prev,
        w: Math.max(minW, origW + (ev.clientX - startX)),
        h: Math.max(minH, origH + (ev.clientY - startY)),
      }));
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };

  return (
    <div
      style={
        winState.visible
          ? { left: winState.x, top: winState.y, width: winState.w, height: winState.h }
          : { left: -9999, top: -9999, width: 1, height: 1, opacity: 0, pointerEvents: "none" }
      }
      className="fixed z-40 bg-slate-900/95 border border-slate-700/90 rounded-lg shadow-2xl flex flex-col overflow-hidden backdrop-blur"
    >
      {/* 可拖拽标题栏 */}
      <div
        onPointerDown={startDrag}
        className="h-7 px-2.5 bg-slate-800/90 border-b border-slate-700/80 flex items-center justify-between cursor-move select-none shrink-0"
      >
        <span className="text-xs font-medium text-slate-200 truncate">{title}</span>
        <div className="flex items-center gap-1.5" onPointerDown={(e) => e.stopPropagation()}>
          {headerExtra}
          <button
            onClick={() => setWinState((p) => ({ ...p, visible: false }))}
            className="text-slate-400 hover:text-rose-400 px-1 text-xs"
            title="隐藏小窗"
          >
            ✕
          </button>
        </div>
      </div>

      {/* 内容区 */}
      <div className="flex-1 relative min-h-0 overflow-hidden">{children}</div>

      {/* 右下角无极缩放手柄 */}
      <div
        onPointerDown={startResize}
        className="w-4 h-4 absolute right-0 bottom-0 cursor-nwse-resize z-20 flex items-end justify-end p-0.5 text-slate-400 hover:text-indigo-400"
        title="拖拽自由缩放大小"
      >
        <svg viewBox="0 0 10 10" className="w-2.5 h-2.5 fill-current">
          <path d="M9 1v8H1L9 1z" />
        </svg>
      </div>
    </div>
  );
}

// ==================== 4. 阅读器类型与常量 ====================

interface VisualLine {
  text: string;
  widthRatio: number;
}

const ROWS_PER_PAGE = 12;
const LINE_HEIGHT_PX = 54;
const CALIBRATION_POINTS = [
  [0.12, 0.14], [0.5, 0.14], [0.88, 0.14],
  [0.12, 0.50], [0.5, 0.50], [0.88, 0.50],
  [0.12, 0.86], [0.5, 0.86], [0.88, 0.86],
];

const DEFAULT_TXT = `在普通摄像头（RGB Webcam）无外设条件下实现精确到排的文档阅读追踪，核心不在于追求亚毫米级的二维空间绝对坐标回归，而在于充分耦合人类阅读的“时序运动先验”与网页端的可控排版结构。
当人眼阅读一整排文字时，视线会沿着水平方向从左向右发生一系列短促的眼跳与注视；当读到行尾时，眼球会在约一百毫秒内执行一次横跨整个文本宽度的快速斜向反向运动，精准落回下一排的行首。这一生理机制在眼动学中被称为回车扫视（Return Sweep）。
由于普通摄像头在水平方向的信噪比远高于垂直方向（垂直方向不仅眼球物理转角小，且往下看时上眼睑会自然下垂遮挡虹膜上半部），检测横跨屏幕的水平负向阶跃跳变，其可靠性比直接测量几毫米的垂直位移高出数倍。
因此，本阅读器将每一排文字预切分为具有确定垂直高度的独立视觉行。当你在行内阅读时，即使摄像头原始垂直预测存在百余像素的噪点，只要未超出锁定阈值，垂直落点就会被强制吸附在当前排的中心线上。
一旦滑动时间窗捕捉到视线抵达当前行有效行尾并迅速回撤至左侧行首，状态机便立即触发换行进位，同时利用这一百分之百确定的真实行坐标，在后台静默修正因坐姿缓慢下滑产生的垂直漂移。
这是一行短尾测试。
通过为每个视觉行记录真实的文字像素宽度占比，系统能够自动识别像上面那样不足行宽三分之一的自然段末尾短行，自动将换行条件降低并启用短行停留推进机制，彻底消除传统回车扫视算法在短行处卡死的工程缺陷。
你可以点击右上角上传本地任意 TXT 小说或技术文档。完成九点校准后，只需保持自然阅读习惯逐行扫视，蓝色光标与高亮条便会实时跟随你的视线逐排推进，读完最后一行再次扫回左侧即可自动翻入下一页。`;

// ==================== 5. Next.js 主页面组件 ====================

export default function GazeTxtReaderPage() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const readerBoxRef = useRef<HTMLDivElement | null>(null);
  const meshCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const miniHeatmapCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const fullHeatmapCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [modelReady, setModelReady] = useState(false);
  const [fps, setFps] = useState(0);
  const [rawText, setRawText] = useState(DEFAULT_TXT);
  const [pages, setPages] = useState<VisualLine[][]>([]);
  const [pageIdx, setPageIdx] = useState(0);
  const [activeLine, setActiveLine] = useState(0);

  // 校准与落点状态
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [calibStep, setCalibStep] = useState(0);
  const [isCalibrated, setIsCalibrated] = useState(false);
  const [gazePoint, setGazePoint] = useState({ x: 0, y: 0, rawY: 0, biasY: 0 });

  // 三个可拖拽缩放小窗的状态
  const [winVideo, setWinVideo] = useState<WinState>({ visible: true, x: 18, y: 70, w: 250, h: 195 });
  const [winMesh, setWinMesh] = useState<WinState>({ visible: true, x: 18, y: 280, w: 280, h: 225 });
  const [winHeatmap, setWinHeatmap] = useState<WinState>({ visible: true, x: 18, y: 520, w: 280, h: 215 });

  // 小窗与热力图控制开关
  const [meshShowVideoBg, setMeshShowVideoBg] = useState(false);
  const [showPageHeatmap, setShowPageHeatmap] = useState(true);
  const [heatmapDecayMode, setHeatmapDecayMode] = useState(true); // true=实时消散, false=持久累积
  const [heatmapUseRawY, setHeatmapUseRawY] = useState(false);

  const uiConfigRef = useRef({ meshShowVideoBg: false, heatmapDecayMode: true, heatmapUseRawY: false });
  useEffect(() => {
    uiConfigRef.current = { meshShowVideoBg, heatmapDecayMode, heatmapUseRawY };
  }, [meshShowVideoBg, heatmapDecayMode, heatmapUseRawY]);

  const layoutRef = useRef<{ pages: VisualLine[][]; pageIdx: number }>({ pages: [], pageIdx: 0 });
  useEffect(() => {
    layoutRef.current = { pages, pageIdx };
  }, [pages, pageIdx]);

  // 热力图浮点缓冲区与离屏 ImageData
  const heatGridRef = useRef<Float32Array>(new Float32Array(HEAT_W * HEAT_H));
  const offscreenHeatCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const weightsRef = useRef<number[][] | null>(null);
  const calibSamplesRef = useRef<{ X: number[][]; Y: number[][] }>({ X: [], Y: [] });
  const collectingPointRef = useRef<{ targetX: number; targetY: number; remaining: number } | null>(null);

  const filterXRef = useRef(new OneEuroFilter(0.9, 0.02, 1.0));
  const filterYRef = useRef(new OneEuroFilter(0.6, 0.01, 1.0));

  const stateRef = useRef({
    currentLine: 0,
    biasY: 0,
    xWindow: [] as { t: number; x: number }[],
    lastSweepTime: 0,
    lineEnterTime: 0,
    jumpOutStartTime: 0,
  });

  // 1. 文本按实际渲染宽度预切分为独立视觉行
  const paginateText = useCallback((text: string, containerWidth: number) => {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.font = "21px system-ui, -apple-system, sans-serif";

    const maxTextWidth = Math.max(containerWidth - 64, 320);
    const visualLines: VisualLine[] = [];

    for (const para of text.split(/\r?\n/)) {
      const trimmed = para.trim();
      if (!trimmed) continue;
      let current = "  ";
      for (const char of trimmed) {
        const testLine = current + char;
        const w = ctx.measureText(testLine).width;
        if (w > maxTextWidth && current.length > 0) {
          visualLines.push({
            text: current,
            widthRatio: Math.min(1, ctx.measureText(current).width / maxTextWidth),
          });
          current = char;
        } else {
          current = testLine;
        }
      }
      if (current) {
        visualLines.push({
          text: current,
          widthRatio: Math.min(1, ctx.measureText(current).width / maxTextWidth),
        });
      }
    }

    const paged: VisualLine[][] = [];
    for (let i = 0; i < visualLines.length; i += ROWS_PER_PAGE) {
      paged.push(visualLines.slice(i, i + ROWS_PER_PAGE));
    }
    setPages(paged.length ? paged : [[{ text: "（空文档）", widthRatio: 0.2 }]]);
    setPageIdx(0);
    setActiveLine(0);
    stateRef.current.currentLine = 0;
  }, []);

  useEffect(() => {
    const updateLayout = () => {
      const w = readerBoxRef.current?.clientWidth ?? 860;
      paginateText(rawText, w);
    };
    updateLayout();
    window.addEventListener("resize", updateLayout);
    return () => window.removeEventListener("resize", updateLayout);
  }, [rawText, paginateText]);

  // 2. 更新浮点热力场并同步渲染至「全页叠加层」与「热力监控小窗」
  const updateAndRenderHeatmaps = useCallback((gx: number, gy: number, rect: DOMRect, curLine: number, lineCount: number) => {
    const grid = heatGridRef.current;
    const { heatmapDecayMode: decayMode } = uiConfigRef.current;

    // 衰减更新
    const decay = decayMode ? 0.965 : 0.999;
    for (let i = 0; i < grid.length; i++) {
      grid[i] *= decay;
    }

    // 注入当前视点高斯热力核
    const cx = Math.round((gx / Math.max(1, window.innerWidth)) * (HEAT_W - 1));
    const cy = Math.round((gy / Math.max(1, window.innerHeight)) * (HEAT_H - 1));
    const radius = 13;
    const r2 = radius * radius;

    const yMin = Math.max(0, cy - radius);
    const yMax = Math.min(HEAT_H - 1, cy + radius);
    const xMin = Math.max(0, cx - radius);
    const xMax = Math.min(HEAT_W - 1, cx + radius);

    for (let y = yMin; y <= yMax; y++) {
      const dy2 = (y - cy) * (y - cy);
      const rowOffset = y * HEAT_W;
      for (let x = xMin; x <= xMax; x++) {
        const d2 = (x - cx) * (x - cx) + dy2;
        if (d2 <= r2) {
          const boost = Math.exp(-d2 / (2 * 30)) * 22;
          grid[rowOffset + x] = Math.min(255, grid[rowOffset + x] + boost);
        }
      }
    }

    // 将浮点场通过 LUT 转换为离屏彩色图
    if (!offscreenHeatCanvasRef.current) {
      const c = document.createElement("canvas");
      c.width = HEAT_W;
      c.height = HEAT_H;
      offscreenHeatCanvasRef.current = c;
    }
    const offCtx = offscreenHeatCanvasRef.current.getContext("2d");
    if (!offCtx) return;

    const imgData = offCtx.createImageData(HEAT_W, HEAT_H);
    const buf32 = new Uint32Array(imgData.data.buffer);
    for (let i = 0; i < grid.length; i++) {
      buf32[i] = HEATMAP_LUT[Math.min(255, grid[i] | 0)];
    }
    offCtx.putImageData(imgData, 0, 0);

    // A. 绘制到全页面叠加 Canvas
    if (fullHeatmapCanvasRef.current) {
      const fCtx = fullHeatmapCanvasRef.current.getContext("2d");
      if (fCtx) {
        fCtx.clearRect(0, 0, HEAT_W, HEAT_H);
        fCtx.drawImage(offscreenHeatCanvasRef.current, 0, 0, HEAT_W, HEAT_H);
      }
    }

    // B. 绘制到小窗鸟瞰 Canvas（含阅读器行骨架与实时落点准星）
    if (miniHeatmapCanvasRef.current) {
      const mCanvas = miniHeatmapCanvasRef.current;
      const mCtx = mCanvas.getContext("2d");
      if (mCtx) {
        const mw = mCanvas.width;
        const mh = mCanvas.height;
        mCtx.clearRect(0, 0, mw, mh);

        // 绘制页面阅读框与每一排文字的缩略骨架
        const scaleX = mw / Math.max(1, window.innerWidth);
        const scaleY = mh / Math.max(1, window.innerHeight);
        mCtx.strokeStyle = "rgba(71, 85, 105, 0.5)";
        mCtx.strokeRect(rect.left * scaleX, rect.top * scaleY, rect.width * scaleX, rect.height * scaleY);

        for (let i = 0; i < lineCount; i++) {
          const ly = (rect.top + 24 + i * LINE_HEIGHT_PX) * scaleY;
          const lh = (LINE_HEIGHT_PX - 6) * scaleY;
          mCtx.fillStyle = i === curLine ? "rgba(99, 102, 241, 0.28)" : "rgba(30, 41, 59, 0.45)";
          mCtx.fillRect((rect.left + 24) * scaleX, ly, (rect.width - 48) * scaleX, lh);
        }

        // 叠加平滑热力图层
        mCtx.drawImage(offscreenHeatCanvasRef.current, 0, 0, mw, mh);

        // 绘制当前实时视点十字标
        const mx = gx * scaleX;
        const my = gy * scaleY;
        mCtx.strokeStyle = "#ffffff";
        mCtx.lineWidth = 1.2;
        mCtx.beginPath();
        mCtx.arc(mx, my, 4, 0, Math.PI * 2);
        mCtx.stroke();
      }
    }
  }, []);

  // 3. 初始化摄像头与 MediaPipe FaceLandmarker + 30FPS 追踪循环
  useEffect(() => {
    let landmarker: FaceLandmarker | null = null;
    let rafId = 0;
    let lastInferMs = -1;
    let frameCounter = 0;
    let fpsTimer = performance.now();
    let active = true;

    async function setup() {
      const vision = await FilesetResolver.forVisionTasks(
        "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm"
      );
      if (!active) return;
      landmarker = await FaceLandmarker.createFromOptions(vision, {
        baseOptions: {
          modelAssetPath:
            "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task",
          delegate: "GPU",
        },
        outputFaceBlendshapes: true,
        outputFacialTransformationMatrixes: true,
        runningMode: "VIDEO",
        numFaces: 1,
      });

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, frameRate: { ideal: 30 } },
      });
      if (!active) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setModelReady(true);
      }

      const loop = () => {
        if (!active) return;
        rafId = requestAnimationFrame(loop);

        const video = videoRef.current;
        if (!video || video.readyState < 2 || video.videoWidth === 0 || !landmarker) return;

        const now = performance.now();
        if (now - lastInferMs < 32) return;
        const timestampMs = Math.max(Math.floor(now), lastInferMs + 1);
        lastInferMs = timestampMs;

        // 计算实时推理 FPS
        frameCounter++;
        if (now - fpsTimer >= 1000) {
          setFps(frameCounter);
          frameCounter = 0;
          fpsTimer = now;
        }

        const res = landmarker.detectForVideo(video, timestampMs);
        const tel = extractGazeTelemetry(res);

        // 实时绘制「小窗 2：眼动与面部点线拓扑」
        if (meshCanvasRef.current) {
          drawFaceAndEyeMesh(
            meshCanvasRef.current,
            res,
            tel,
            video,
            uiConfigRef.current.meshShowVideoBg
          );
        }

        // 若眨眼或未检测到人脸，跳过坐标回归更新
        if (!tel || tel.blink > 0.5) return;
        const feat = tel.features;

        // 分支 A: 采样校准点特征
        if (collectingPointRef.current && collectingPointRef.current.remaining > 0) {
          calibSamplesRef.current.X.push(feat);
          calibSamplesRef.current.Y.push([
            collectingPointRef.current.targetX,
            collectingPointRef.current.targetY,
          ]);
          collectingPointRef.current.remaining -= 1;
          return;
        }

        // 分支 B: 实时视线预测与行锁定状态机
        const W = weightsRef.current;
        if (!W || !readerBoxRef.current) return;

        let rawX = 0;
        let rawY = 0;
        for (let i = 0; i < feat.length; i++) {
          rawX += feat[i] * W[i][0];
          rawY += feat[i] * W[i][1];
        }

        const filtX = filterXRef.current.filter(rawX, timestampMs);
        const filtY = filterYRef.current.filter(rawY, timestampMs) + stateRef.current.biasY;

        const rect = readerBoxRef.current.getBoundingClientRect();
        const { pages: curPages, pageIdx: curPageIdx } = layoutRef.current;
        const lineCount = curPages[curPageIdx]?.length ?? 1;
        const st = stateRef.current;
        if (st.lineEnterTime === 0) st.lineEnterTime = timestampMs;

        const getLineCenterY = (idx: number) => rect.top + 24 + (idx + 0.5) * LINE_HEIGHT_PX;
        const currentLineObj = curPages[curPageIdx]?.[st.currentLine] ?? { text: "", widthRatio: 1 };

        st.xWindow.push({ t: timestampMs, x: filtX });
        st.xWindow = st.xWindow.filter((item) => timestampMs - item.t <= 380);

        const maxWindowX = Math.max(...st.xWindow.map((item) => item.x));
        const textWidthPx = rect.width - 64;
        const lineStartX = rect.left + 32;

        const effectiveRatio = Math.max(0.28, currentLineObj.widthRatio * 0.65);
        const rightThresholdX = lineStartX + textWidthPx * effectiveRatio;
        const leftReturnX = lineStartX + textWidthPx * Math.min(0.35, effectiveRatio * 0.65);

        const isNormalSweep =
          timestampMs - st.lastSweepTime > 420 &&
          maxWindowX >= rightThresholdX &&
          filtX <= leftReturnX &&
          maxWindowX - filtX >= textWidthPx * Math.max(0.18, currentLineObj.widthRatio * 0.35);

        const isShortLineAdvance =
          currentLineObj.widthRatio < 0.32 &&
          timestampMs - st.lineEnterTime > 750 &&
          timestampMs - st.lastSweepTime > 650 &&
          filtY - getLineCenterY(st.currentLine) > LINE_HEIGHT_PX * 0.45 &&
          filtX < lineStartX + textWidthPx * 0.38;

        if (isNormalSweep || isShortLineAdvance) {
          st.lastSweepTime = timestampMs;
          st.xWindow = [];
          if (st.currentLine < lineCount - 1) {
            st.currentLine += 1;
            st.lineEnterTime = timestampMs;
            setActiveLine(st.currentLine);

            const trueY = getLineCenterY(st.currentLine);
            const residualY = trueY - filtY;
            if (Math.abs(residualY) < LINE_HEIGHT_PX * 3.5) {
              st.biasY += 0.08 * residualY;
            }
          } else if (curPageIdx < curPages.length - 1) {
            st.currentLine = 0;
            st.lineEnterTime = timestampMs;
            setActiveLine(0);
            setPageIdx(curPageIdx + 1);
          }
        } else {
          const distY = Math.abs(filtY - getLineCenterY(st.currentLine));
          if (distY > LINE_HEIGHT_PX * 2.2) {
            if (st.jumpOutStartTime === 0) st.jumpOutStartTime = timestampMs;
            else if (timestampMs - st.jumpOutStartTime > 350) {
              let bestIdx = 0;
              let minDiff = Infinity;
              for (let i = 0; i < lineCount; i++) {
                const d = Math.abs(filtY - getLineCenterY(i));
                if (d < minDiff) {
                  minDiff = d;
                  bestIdx = i;
                }
              }
              st.currentLine = bestIdx;
              st.lineEnterTime = timestampMs;
              st.jumpOutStartTime = 0;
              setActiveLine(bestIdx);
            }
          } else {
            st.jumpOutStartTime = 0;
          }
        }

        const snappedY = getLineCenterY(st.currentLine);
        const clampedX = Math.max(lineStartX, Math.min(rect.right - 32, filtX));
        setGazePoint({ x: clampedX, y: snappedY, rawY: filtY, biasY: Math.round(st.biasY) });

        // 更新并渲染全页面视线热力层与小窗3热力鸟瞰图
        const targetHeatY = uiConfigRef.current.heatmapUseRawY ? filtY : snappedY;
        updateAndRenderHeatmaps(clampedX, targetHeatY, rect, st.currentLine, lineCount);
      };

      rafId = requestAnimationFrame(loop);
    }

    setup();
    return () => {
      active = false;
      cancelAnimationFrame(rafId);
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach((t) => t.stop());
      }
      landmarker?.close();
    };
  }, [updateAndRenderHeatmaps]);

  // 4. 触发 9 点校准采样
  const startCalibration = () => {
    calibSamplesRef.current = { X: [], Y: [] };
    setCalibStep(0);
    setIsCalibrating(true);
  };

  const handleCalibPointClick = (tx: number, ty: number) => {
    if (collectingPointRef.current && collectingPointRef.current.remaining > 0) return;
    collectingPointRef.current = { targetX: tx, targetY: ty, remaining: 22 };

    const checkTimer = setInterval(() => {
      if (collectingPointRef.current && collectingPointRef.current.remaining <= 0) {
        clearInterval(checkTimer);
        if (calibStep < CALIBRATION_POINTS.length - 1) {
          setCalibStep((s) => s + 1);
        } else {
          const { X, Y } = calibSamplesRef.current;
          weightsRef.current = solveRidgeRegression(X, Y, 0.05);
          stateRef.current.biasY = 0;
          stateRef.current.currentLine = 0;
          heatGridRef.current.fill(0);
          setActiveLine(0);
          setIsCalibrating(false);
          setIsCalibrated(true);
        }
      }
    }, 30);
  };

  // 5. 本地 TXT 文件导入
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const buffer = await file.arrayBuffer();
    let decoded = new TextDecoder("utf-8", { fatal: false }).decode(buffer);
    if (decoded.includes("\uFFFD")) {
      decoded = new TextDecoder("gbk").decode(buffer);
    }
    setRawText(decoded);
  };

  const currentLines = pages[pageIdx] ?? [];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col select-none">
      {/* 全页面实时视线热力叠加层（指针穿透，不阻挡任何交互） */}
      <canvas
        ref={fullHeatmapCanvasRef}
        width={HEAT_W}
        height={HEAT_H}
        className={`pointer-events-none fixed inset-0 w-full h-full z-30 transition-opacity duration-200 ${
          showPageHeatmap && isCalibrated && !isCalibrating ? "opacity-80" : "opacity-0"
        }`}
      />

      {/* ==================== 三个可自由拖拽与缩放的浮动小窗 ==================== */}

      {/* 小窗 1：原始摄像头视频流 */}
      <FloatingWindow title="1. 摄像头实时画面" winState={winVideo} setWinState={setWinVideo}>
        <div className="relative w-full h-full bg-black overflow-hidden">
          <video
            ref={videoRef}
            playsInline
            muted
            className="w-full h-full object-cover -scale-x-100"
          />
          <div className="absolute bottom-1.5 left-2 text-[11px] font-mono bg-slate-950/75 px-1.5 py-0.5 rounded text-emerald-400 border border-slate-800">
            {fps} FPS | 640×480
          </div>
        </div>
      </FloatingWindow>

      {/* 小窗 2：眼动与面部识别点线叠加 */}
      <FloatingWindow
        title="2. 眼动与面部点线拓扑"
        winState={winMesh}
        setWinState={setWinMesh}
        headerExtra={
          <button
            onClick={() => setMeshShowVideoBg((v) => !v)}
            className="px-1.5 py-0.5 text-[10px] rounded bg-slate-700 hover:bg-slate-600 text-slate-200"
          >
            {meshShowVideoBg ? "纯网格底" : "叠视频底"}
          </button>
        }
      >
        <canvas
          ref={meshCanvasRef}
          width={320}
          height={240}
          className="w-full h-full bg-slate-950 block object-contain"
        />
      </FloatingWindow>

      {/* 小窗 3：全页面视线热力鸟瞰与控制小窗 */}
      <FloatingWindow
        title="3. 视线热力监控"
        winState={winHeatmap}
        setWinState={setWinHeatmap}
        minW={240}
        minH={185}
        headerExtra={
          <button
            onClick={() => heatGridRef.current.fill(0)}
            className="px-1.5 py-0.5 text-[10px] rounded bg-slate-700 hover:bg-rose-600 text-slate-200 transition"
          >
            清空热力
          </button>
        }
      >
        <div className="w-full h-full flex flex-col bg-slate-950">
          <div className="flex-1 relative min-h-0">
            <canvas
              ref={miniHeatmapCanvasRef}
              width={280}
              height={160}
              className="w-full h-full block"
            />
            {!isCalibrated && (
              <div className="absolute inset-0 flex items-center justify-center text-xs text-slate-500">
                完成 9 点校准后显示实时热力轨迹
              </div>
            )}
          </div>
          <div className="h-8 px-2 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-[11px] shrink-0">
            <label className="flex items-center gap-1 cursor-pointer text-slate-300">
              <input
                type="checkbox"
                checked={showPageHeatmap}
                onChange={(e) => setShowPageHeatmap(e.target.checked)}
                className="accent-indigo-500"
              />
              全页热力叠加
            </label>
            <button
              onClick={() => setHeatmapDecayMode((m) => !m)}
              className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-indigo-300"
            >
              {heatmapDecayMode ? "模式: 实时消散" : "模式: 持久累积"}
            </button>
            <button
              onClick={() => setHeatmapUseRawY((r) => !r)}
              className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
            >
              {heatmapUseRawY ? "源: 原始Y" : "源: 行吸附Y"}
            </button>
          </div>
        </div>
      </FloatingWindow>

      {/* ==================== 顶部主导航栏 ==================== */}
      <header className="h-14 border-b border-slate-800 px-5 flex items-center justify-between bg-slate-900/80 backdrop-blur z-30">
        <div className="flex items-center gap-3">
          <span className="font-semibold tracking-wide text-slate-200">
            WebEye TXT 行级眼动阅读器
          </span>
          <span className="text-xs px-2.5 py-1 rounded bg-slate-800 text-slate-400">
            {!modelReady
              ? "正在加载 MediaPipe GPU 模型..."
              : isCalibrated
              ? `追踪中 | 漂移补偿: ${gazePoint.biasY > 0 ? `+${gazePoint.biasY}` : gazePoint.biasY}px`
              : "模型就绪，请先执行 9 点校准"}
          </span>
        </div>

        {/* 浮动小窗显隐快捷开关组 */}
        <div className="flex items-center gap-2 text-xs">
          <button
            onClick={() => setWinVideo((p) => ({ ...p, visible: !p.visible }))}
            className={`px-2.5 py-1 rounded border transition ${
              winVideo.visible
                ? "bg-indigo-600/25 border-indigo-500 text-indigo-200"
                : "bg-slate-800 border-slate-700 text-slate-400"
            }`}
          >
            视频窗
          </button>
          <button
            onClick={() => setWinMesh((p) => ({ ...p, visible: !p.visible }))}
            className={`px-2.5 py-1 rounded border transition ${
              winMesh.visible
                ? "bg-indigo-600/25 border-indigo-500 text-indigo-200"
                : "bg-slate-800 border-slate-700 text-slate-400"
            }`}
          >
            点线拓扑窗
          </button>
          <button
            onClick={() => setWinHeatmap((p) => ({ ...p, visible: !p.visible }))}
            className={`px-2.5 py-1 rounded border transition ${
              winHeatmap.visible
                ? "bg-indigo-600/25 border-indigo-500 text-indigo-200"
                : "bg-slate-800 border-slate-700 text-slate-400"
            }`}
          >
            热力监控窗
          </button>

          <div className="h-4 w-[1px] bg-slate-800 mx-1" />

          <label className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 cursor-pointer transition text-slate-200">
            导入 TXT
            <input type="file" accept=".txt" onChange={handleFileUpload} className="hidden" />
          </label>
          <button
            disabled={!modelReady}
            onClick={startCalibration}
            className="px-3 py-1.5 rounded bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 font-medium text-white transition"
          >
            {isCalibrated ? "重新 9 点校准" : "开始 9 点校准"}
          </button>

          <div className="flex items-center gap-1 ml-1">
            <button
              onClick={() => {
                setPageIdx((p) => Math.max(0, p - 1));
                stateRef.current.currentLine = 0;
                setActiveLine(0);
              }}
              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700"
            >
              上一页
            </button>
            <span className="px-1.5 text-slate-400 font-mono">
              {pageIdx + 1}/{Math.max(1, pages.length)}
            </span>
            <button
              onClick={() => {
                setPageIdx((p) => Math.min(pages.length - 1, p + 1));
                stateRef.current.currentLine = 0;
                setActiveLine(0);
              }}
              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700"
            >
              下一页
            </button>
          </div>
        </div>
      </header>

      {/* ==================== 阅读器主视口 ==================== */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-6">
        <div
          ref={readerBoxRef}
          className="w-full max-w-4xl bg-slate-900/70 border border-slate-800/90 rounded-xl py-6 px-8 relative shadow-2xl"
          style={{ minHeight: ROWS_PER_PAGE * LINE_HEIGHT_PX + 48 }}
        >
          {currentLines.map((line, idx) => {
            const isActive = idx === activeLine;
            return (
              <div
                key={idx}
                onClick={() => {
                  stateRef.current.currentLine = idx;
                  stateRef.current.lineEnterTime = performance.now();
                  setActiveLine(idx);
                }}
                style={{ height: LINE_HEIGHT_PX }}
                className={`flex items-center px-3 rounded-lg transition-colors duration-150 cursor-pointer ${
                  isActive
                    ? "bg-indigo-500/15 text-white font-medium border-l-4 border-indigo-400"
                    : "text-slate-400 hover:bg-slate-800/40"
                }`}
              >
                <span className="w-7 text-xs font-mono text-slate-600 select-none">
                  {String(idx + 1).padStart(2, "0")}
                </span>
                <span className="text-[21px] tracking-wide whitespace-pre">{line.text}</span>
              </div>
            );
          })}
        </div>
      </main>

      {/* 实时眼动行内平滑跟随光标 & 原始垂直预测参考点 */}
      {isCalibrated && !isCalibrating && (
        <div className="pointer-events-none fixed inset-0 z-30">
          <div
            className="w-5 h-5 -ml-2.5 -mt-2.5 rounded-full bg-indigo-400/80 shadow-[0_0_16px_rgba(99,102,241,0.9)] transition-transform duration-75"
            style={{ transform: `translate3d(${gazePoint.x}px, ${gazePoint.y}px, 0)` }}
          />
          <div
            className="w-2 h-2 -ml-1 -mt-1 rounded-full bg-rose-400/60"
            style={{ transform: `translate3d(${gazePoint.x}px, ${gazePoint.rawY}px, 0)` }}
          />
        </div>
      )}

      {/* 9点全屏校准遮罩 */}
      {isCalibrating && (
        <div className="fixed inset-0 z-50 bg-slate-950/95 flex flex-col items-center justify-center">
          <p className="text-slate-300 text-lg mb-2">
            请保持自然阅读坐姿，<strong>注视并点击</strong>高亮圆点（{calibStep + 1} / 9）
          </p>
          <p className="text-slate-500 text-sm">
            点击后请保持视线停留在该点约 0.5 秒以采集头眼耦合特征
          </p>
          {CALIBRATION_POINTS.map(([rx, ry], idx) => {
            if (idx !== calibStep) return null;
            const px = typeof window !== "undefined" ? Math.round(rx * window.innerWidth) : 0;
            const py = typeof window !== "undefined" ? Math.round(ry * window.innerHeight) : 0;
            return (
              <button
                key={idx}
                onClick={() => handleCalibPointClick(px, py)}
                style={{ left: `${rx * 100}%`, top: `${ry * 100}%` }}
                className="fixed -ml-6 -mt-6 w-12 h-12 rounded-full bg-indigo-500/30 border-2 border-indigo-400 flex items-center justify-center animate-pulse cursor-crosshair"
              >
                <span className="w-3.5 h-3.5 rounded-full bg-amber-400" />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}